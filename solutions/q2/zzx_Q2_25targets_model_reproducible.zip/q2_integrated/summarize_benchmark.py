import json,csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parent
BENCH=ROOT/'results/node_benchmark.json'
bench=json.load(open(BENCH))
def summarize(mode):
 a=[q for q in bench if q['mode']==mode]
 return dict(cases=len(a),wall_seconds=sum(v['wall_seconds'] for v in a),
    nonlinear_calls=sum(v['optimized'] for v in a),valid_edges=sum(v['valid_before_cap'] for v in a),
    distinct_next_targets_summed=sum(v['distinct_targets'] for v in a))
old=summarize('legacy');new=summarize('events')
replay=json.load(open(ROOT/'results/verified_schedule.json'))
base=json.load(open(ROOT/'results/baseline_21_verified_schedule.json'))
ck=json.load(open(ROOT/'results/event_warm16.json'))
continuation=ck['stats']
sumr=dict(scenario='r1_4_sign_flip_trial_not_raw_workbook',new_N_verified=replay['verified_completed_targets'],
 new_J_m_s=replay['total_delta_v_m_s'],new_mission_end_day=replay['mission_end_day'],
 new_burns=replay['total_burns'],baseline_N=base['verified_completed_targets'],
 baseline_J_m_s=base['total_delta_v_m_s'],old_paired=old,new_paired=new,
 wall_reduction_pct=100*(1-new['wall_seconds']/old['wall_seconds']),
 nonlinear_call_reduction_pct=100*(1-new['nonlinear_calls']/old['nonlinear_calls']),
 incumbent_prefix_length=16,continuation_nonlinear_calls=sum(r['nonlinear_optimizations'] for r in continuation),
 continuation_elapsed_seconds=sum(r['elapsed_seconds'] for r in continuation),
 continuation_failed_timeout_calls=sum(r.get('optimization_timeouts',0) for r in continuation),
 global_optimum_certified=False,method_note='Paired benchmark compares fixed historical states and heuristic candidate sets; new 22 route warm-started from first 16 previously verified tasks.')
json.dump(sumr,open(ROOT/'results/summary.json','w'),ensure_ascii=False,indent=2)

# Performance chart, English labels by design.
levels=sorted(set(q['depth'] for q in bench))
xs=np.arange(len(levels));width=.36
for metric,name,filename in [('wall_seconds','CPU wall time (s)','figures/paired_wall_time.png'),
                             ('optimized','Nonlinear optimization calls','figures/paired_solver_calls.png')]:
    fig,ax=plt.subplots(figsize=(8.3,4.5))
    y0=[next(q[metric] for q in bench if q['depth']==k and q['mode']=='legacy') for k in levels]
    y1=[next(q[metric] for q in bench if q['depth']==k and q['mode']=='events') for k in levels]
    ax.bar(xs-width/2,y0,width,label='Legacy grid screen')
    ax.bar(xs+width/2,y1,width,label='Event + analytic distance')
    ax.set_xticks(xs,[f'{k} targets' for k in levels]);ax.set_ylabel(name);ax.legend();ax.grid(axis='y',alpha=.2)
    fig.tight_layout();fig.savefig(ROOT/filename,dpi=160);plt.close(fig)

fig,ax=plt.subplots(figsize=(8.4,4.7))
for dataset,label in [(base,'Baseline (21 targets)'),(replay,'Event continuation (22 targets)')]:
    d=[0.]+[z['obs_end_s']/86400 for z in dataset['lines']]
    f=[0.]+[z['cumulative_delta_v_m_s'] for z in dataset['lines']]
    ax.step(d,f,where='post',label=label,linewidth=1.8)
ax.axhline(300,linestyle='--',linewidth=1,label='Fuel budget (300 m/s)')
ax.set(xlabel='Days since 2027-01-01',ylabel='Cumulative delta-V (m/s)',xlim=(0,30))
ax.grid(alpha=.2);ax.legend();fig.tight_layout()
fig.savefig(ROOT/'figures/22_targets_fuel.png',dpi=160);plt.close(fig)
print(json.dumps(sumr,ensure_ascii=False,indent=2))
