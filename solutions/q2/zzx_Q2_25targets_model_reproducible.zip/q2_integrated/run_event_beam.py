"""Event-driven trajectory-state beam search (original Q2 dynamics + verifier).

This heuristic is NOT a globally complete branch-and-bound algorithm.
Edges are verified before admission; labels preserve exact terminal six-state.
Run without the historical Q2 solution -- it starts solely from Q1's b1 prefix.
"""
import argparse,json,time,sys
from pathlib import Path
import numpy as np
from q2lib.catalog import Catalog,DEADLINE,DAY
from q2lib.planner import Node,advance,load_q1_prefix
from q2lib.events import candidates_for_node_events,solar_visibility_windows,screen_events

ROOT=Path(__file__).resolve().parent

def rank(n):return float(n.time/DAY + .13*n.fuel)

def select_labels(nodes,width,cat=None,windows=None,lookahead=False):
    uniq={}
    # The visited set, recent maneuver and terminal phase are state variables;
    # the bucket is heuristic, not a proof of exact state dominance.
    for n in nodes:
        a=np.linalg.norm(n.observer[:3]);
        key=(tuple(sorted(n.visited)),int(n.time/3600),int(a/50),n.visited[-1])
        if key not in uniq or rank(n)<rank(uniq[key]):uniq[key]=n
    nodes=list(uniq.values())
    diversity=[]
    for by in [lambda n:rank(n),lambda n:n.time/DAY,lambda n:n.fuel]:
        for n in sorted(nodes,key=by):
            if all(n is not z for z in diversity):
                if len(diversity)<min(width,max(3,width//2)):
                    # Try different last-target to sample distinct terminal orbit classes.
                    if any(z.visited[-1]==n.visited[-1] for z in diversity):continue
                diversity.append(n)
            if len(diversity)>=width:break
        if len(diversity)>=width:break
    return diversity[:width]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--width',type=int,default=6)
    p.add_argument('--depth',type=int,default=21)
    p.add_argument('--max-calls',type=int,default=16)
    p.add_argument('--per-target',type=int,default=4)
    p.add_argument('--max-days',type=float,default=10)
    p.add_argument('--max-edge',type=int,default=12)
    p.add_argument('--cap',type=float,default=32)
    p.add_argument('--save',default='results/event_beam_checkpoint.json')
    p.add_argument('--warm-prefix',type=int,default=0,help='Reuse this many verified Q2 incumbent tasks as a warm-start; 0 starts only with Q1')
    p.add_argument('--resume',action='store_true')
    a=p.parse_args()
    cat=Catalog(ROOT/'data.xlsx',dt=1200)
    windows=solar_visibility_windows(cat)
    start=load_q1_prefix(cat,ROOT/'q1_baseline.json')
    if a.warm_prefix>0:
        incumbent=json.load(open(ROOT/'results/baseline_21_checkpoint.json',encoding='utf8'))['best']
        if not 1<=a.warm_prefix<=len(incumbent['history']):raise ValueError('Bad prefix length')
        pref=incumbent['history'][:a.warm_prefix]
        last=pref[-1]
        start=Node(float(last['observation_end_s']),np.array(last['terminal_observer_state'],float),
                   sum(float(h['cost_m_s']) for h in pref),float(last['last_burn_s']),
                   tuple(h['target_id'] for h in pref),pref)
    beam=[start];best=start;stats=[]
    dest=ROOT/a.save;dest.parent.mkdir(parents=True,exist_ok=True)
    if a.resume and dest.exists():
        checkpoint=json.load(open(dest))
        def load(n):return Node(float(n['time_s']),np.array(n['observer_state'],float),
                     float(n['used_m_s']),n['last_burn_s'],tuple(n['visited']),n['history'])
        beam=[load(q) for q in checkpoint['beam']];best=load(checkpoint['best']);stats=checkpoint['stats']
    t0=time.perf_counter()
    for depth in range(len(start.visited)+len(stats),a.depth+1):
        st=time.perf_counter();out=[];ncall=0;nvalid=0;scanned=0;events=0;timeouts=0
        for ix,n in enumerate(beam):
            tnode=time.perf_counter()
            edges,stt=candidates_for_node_events(cat,n,windows,
                         max_days_ahead=a.max_days,max_events_per_target=a.per_target,
                         max_optimizations=a.max_calls,max_candidates=a.max_edge,
                         low_margin=.12,step=.05,cap=a.cap)
            ncall+=stt.nonlinear_optimizations;nvalid+=stt.verified_edges;timeouts+=stt.optimization_timeouts
            scanned+=stt.considered_grid_points;events+=stt.event_count
            print("NODE",depth,ix+1,"of",len(beam),"last",n.visited[-1],"t",round(n.time/DAY,2),"calls",stt.nonlinear_optimizations,"valid",stt.verified_edges,"elapsed",round(time.perf_counter()-tnode,2),flush=True)
            for edge in edges:
                child=advance(n,edge)
                if child.fuel>300 or child.time>DEADLINE:continue
                out.append(child)
                if (len(child.visited)>len(best.visited) or
                   (len(child.visited)==len(best.visited) and child.fuel<best.fuel)):
                    best=child
        if not out:
            print('STOP',depth,'NO MORE CHILDREN',flush=True);break
        beam=select_labels(out,a.width,cat,windows)
        dt=time.perf_counter()-st
        stats.append(dict(depth=depth,parents=len(beam),children=len(out),nonlinear_optimizations=ncall,
                      verified_edges=nvalid,screen_grid_pairs=scanned,event_candidates=events,optimization_timeouts=timeouts,
                      elapsed_seconds=dt,best_verified_count=len(best.visited)))
        info=dict(scenario='r1_xy_vy_vz_sign_flip_trial',algorithm='event_geo+analytic_distance+state_label_beam',
            certified_global_optimum=False,best=best.serial(),beam=[n.serial() for n in beam],stats=stats,
            total_wall_seconds=time.perf_counter()-t0,config=vars(a))
        json.dump(info,open(dest,'w',encoding='utf8'),indent=2,ensure_ascii=False)
        print('DEPTH',depth,'s',round(dt,2),'calls',ncall,'timeouts',timeouts,'edges',nvalid,'children',len(out),
            'beam',[(z.visited[-1],round(z.time/DAY,2),round(z.fuel,2)) for z in beam],
            'BEST',len(best.visited),'day',round(best.time/DAY,2),'fuel',round(best.fuel,2),flush=True)
    print('FINAL BEST',len(best.visited),best.visited,best.fuel,best.time/DAY,
          'wall',time.perf_counter()-t0,flush=True)

if __name__=='__main__':main()
