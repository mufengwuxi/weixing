"""Goal-oriented 2-impulse insertion after 24 verified targets, candidate b30.
This is a local nonlinear solver, never proof of optimality.
"""
from pathlib import Path
import json,time
import numpy as np
from scipy.optimize import minimize
from q2lib.catalog import Catalog,DAY,DEADLINE
from q1_core.dynamics import propagate
from q1_core.kepler_fast import ellipse,propagate_ellipse
from q1_core.geometry import sun_position
from q1_core.transfer import TransferRequest,evaluate_transfer
ROOT=Path(__file__).resolve().parent
B=json.load(open(ROOT/'results/strategy_24.json'))['best'];last=B['history'][-1]
ct=last['observation_end_s'];node=np.array(last['terminal_observer_state'])
cat=Catalog(ROOT/'data.xlsx',dt=1200)
name='b30'

def position(u, xb1,t1,t2, dt):
 x=xb1.copy();x[3:]+=u[:3]/1000
 r,v=propagate_ellipse(ellipse(x),t2-t1)
 xt=np.r_[r,v];xt[3:]+=u[3:]/1000
 return propagate_ellipse(ellipse(xt),dt)[0]

def initial_guess(center,t1,t2):
 xb=propagate(node,t1-ct)
 x2=propagate(xb,t2-t1)
 r0=propagate_ellipse(ellipse(x2),center-t2)[0]
 rt=cat.target_at(name,center)
 ss=sun_position(center)-rt;ss/=np.linalg.norm(ss)
 ee=-rt/np.linalg.norm(rt)
 q=ss+ee;q/=np.linalg.norm(q)
 h=2e-5;H=np.empty((3,6))
 for j in range(6):
  u=np.zeros(6);u[j]=h
  pp=position(u,xb,t1,t2,center-t2)
  mm=position(-u,xb,t1,t2,center-t2)
  H[:,j]=(pp-mm)/(2*h)
 P=np.linalg.pinv(H,rcond=1e-9)
 U0=P@(rt-r0);Ud=P@q
 dd=np.clip(-U0@Ud/max(1e-12,Ud@Ud),10.5,49.5)
 return U0+dd*Ud,dd

def run(center,t1,t2,burn_cap=30.,angle_deg=44.87,dmax=49.75):
 t0=time.perf_counter()
 xb1=propagate(node,t1-ct)
 obs=center-30+np.linspace(0,60,9)
 rt=cat.target_at(name,obs)
 ss=np.array([sun_position(t) for t in obs])-rt;ss/=np.linalg.norm(ss,axis=1)[:,None]
 ee=-rt/np.linalg.norm(rt,axis=1)[:,None]
 ca=np.cos(np.deg2rad(angle_deg))
 seed,dd=initial_guess(center,t1,t2)
 def constr(u):
  try:
   rr=position(u,xb1,t1,t2,obs-t2)
   p=rr-rt;d=np.linalg.norm(p,axis=1);p/=d[:,None]
   return np.r_[d-10.25,dmax-d,40*(np.sum(p*ss,axis=1)-ca),40*(np.sum(p*ee,axis=1)-ca),burn_cap-np.linalg.norm(u[:3]),burn_cap-np.linalg.norm(u[3:]),300-B['used_m_s']-np.linalg.norm(u[:3])-np.linalg.norm(u[3:])]
  except (ValueError,FloatingPointError,OverflowError):return np.full(39,-1e6)
 def fuel(u):return np.linalg.norm(u[:3])+np.linalg.norm(u[3:])
 def opt_one(x):
  return minimize(fuel,x,method='SLSQP',bounds=[(-30,30)]*6,constraints=[{'type':'ineq','fun':constr}],options={'ftol':1e-8,'maxiter':250})
 sols=[]
 for fac in (1.,.95,1.05):
  so=opt_one(seed*fac)
  gap=min(constr(so.x))
  if gap>=-5e-6 and np.isfinite(so.x).all():
   req=TransferRequest(node,cat.targets[name],ct,DEADLINE,300-B['used_m_s'],last['last_burn_s'],name)
   try:
    res=evaluate_transfer(req,(t1,t2),(so.x[:3],so.x[3:]),center-30,step=.005)
   except (RuntimeError,ValueError) as e:
    print('ERROR',e,flush=True);continue
   sols.append((so.fun,gap,res.verified,so.x,res))
  else:print('failed NLP center',center/DAY,'gap',gap,'SLSQP',so.message, 'fuel',fuel(so.x),flush=True)
 if not sols:
  print('none center',round(center/DAY,5),'gap',round((t2-t1)/3600,2),'initfuel',round(fuel(seed),2),'time',round(time.perf_counter()-t0,2),flush=True)
  return None
 sols.sort(key=lambda k:k[0])
 for val,g,valid,u,res in sols[:1]:
  print('center',round(center/DAY,5),'gap_hours',(t2-t1)/3600,'initial',round(fuel(seed),3),'opt',round(val,4),'valid',valid,
        'marg',round(g,5),'u',np.round(u,4),'d',res.min_distance_km,res.max_distance_km,'ang',res.max_solar_deg,res.max_detect_deg,
         'wall',round(time.perf_counter()-t0,2),flush=True)
 return sols[0]

if __name__=='__main__':
 best=None
 t1=ct+3600
 for gap_hours in [1,1.5,2,3]:
  t2=t1+gap_hours*3600
  for day in [29.72,29.73,29.7396,29.75,29.76,29.77,29.78]:
   center=day*DAY
   if center-30<=t2:continue
   x=run(center,t1,t2)
   if x is not None and x[2] and (best is None or x[0]<best[0]):best=x
 if best is not None:
  val,g,valid,u,res=best
  output={'source':'two_burn_tail_insert_heuristic','cost':val,'verified':bool(valid), 'transfer':res.to_dict()}
  (ROOT/'results/attempt_b30_twoburn.json').write_text(json.dumps(output,indent=2,ensure_ascii=False),encoding='utf8')
  plan={'best':B.copy()}
  plan['best']['history']=B['history']+[res.to_dict()]
  plan['best']['visited']=list(B['visited'])+[name]
  plan['best']['time_s']=res.observation_end_s
  plan['best']['used_m_s']=B['used_m_s']+res.cost_m_s
  plan['best']['observer_state']=res.terminal_observer_state.tolist()
  plan['best']['last_burn_s']=res.last_burn_s
  (ROOT/'results/strategy_25_candidate.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False),encoding='utf8')
  print('BEST',val,res.observation_end_s/DAY,res.verified,flush=True)
 else:print('NONE FOUND',flush=True)
