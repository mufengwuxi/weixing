"""Remove extra non-required 1h wait after observation, optimize robust b30 tail."""
import json,time
import numpy as np
from pathlib import Path
from attempt_b30_twoburn import B,last,ct,run,ROOT
from q2lib.catalog import DAY
best=None
for off in (60.,600.,1800.,3600.):
 for gap in (3600.,5400.,7200.):
  t1=ct+off;t2=t1+gap
  for day in (29.72,29.73,29.7396,29.75):
   if day*DAY-30<=t2:continue
   x=run(day*DAY,t1,t2)
   if x is None or not x[2]:continue
   val,g,valid,u,res=x
   if best is None or val<best[0]:best=x
   # save improved candidate now
   plan={'best':B.copy()}
   plan['best']['history']=B['history']+[res.to_dict()]
   plan['best']['visited']=list(B['visited'])+['b30']
   plan['best']['time_s']=res.observation_end_s
   plan['best']['used_m_s']=B['used_m_s']+res.cost_m_s
   plan['best']['observer_state']=res.terminal_observer_state.tolist()
   plan['best']['last_burn_s']=res.last_burn_s
   if abs(val-best[0])<1e-10:
    (ROOT/'results/strategy_25_refined.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False),encoding='utf8')
 if best is not None:print('BEST SO FAR',off,best[0],flush=True)
print('FINAL BEST',best[0],best[4].observation_end_s/DAY, [np.linalg.norm(best[3][:3]),np.linalg.norm(best[3][3:])],flush=True)
