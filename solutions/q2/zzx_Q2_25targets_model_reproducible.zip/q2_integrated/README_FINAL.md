# Q2: 25 verified targets, hierarchical physical model

**Source scenario**: Trial only. Observer r1 is derived by flipping x,y,vy,vz in the source Excel; every target remains the original Excel 6-D state. Raw observer data is physically Earth-crossing in two-body propagation, and the trial must not be described as an official correction.

**Best known feasible schedule**: 25 targets, total delta-V 188.28476464958416 m/s, mission end day 29.73994722222222. Exact burns and terminal states: `results/strategy_25_refined.json`.

**Alternative with improved terminal maneuver margin**: 25 targets, total delta-V 188.43374636470259 m/s, terminal b30 first impulse limited to 29 m/s and angles to 44.75 degrees. See `results/strategy_25_robust.json`.

**Optimality**: Coverage certified by numerical replay, but global optimality is **not** established: 25 <= N* <= 30 (strict inequality bounds on coverage, modulo ideal input/model). Candidate generation and future opportunity scores are heuristic. No claim that total delta-V is minimal among 25-target plans.

**Full Chinese modeling report**: `Q2_INTEGRATED_PAPER_CN.md`.

## Quick start

```bash
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python -m pytest tests -q
OPENBLAS_NUM_THREADS=1 python validate_solution.py --plan results/strategy_25_refined.json
OPENBLAS_NUM_THREADS=1 python make_integrated_figures.py
```

## Re-run structural search

```bash
OPENBLAS_NUM_THREADS=1 python run_strategic_beam.py --warm-prefix 13 --width 9 --max-calls 11 --max-days 8 --depth 23 --save results/reproduced_23.json
OPENBLAS_NUM_THREADS=1 python extend_strategic_beam.py --infile results/reproduced_23.json --depth 25 --width 9 --max-calls 22 --save results/reproduced_24.json
```

For the difficult final b30 edge, `attempt_b30_twoburn.py` and `refine_tail.py` show the two-impulse optimization and correction of an unnecessary 1-hour post-observation waiting restriction.

For controlled tests of exact-time fuel non-monotonicity, run `run_time_fuel_profile.py`. Source files `q2lib/` and `q1_core/` hold the state-continuous transfer and physical trajectory logic.

**Scientific caveats**: Numerical DOP853 replay with inter-sample motion envelopes is not validated interval integration. Global coverage and fuel optimality are not certified; unmodified source input is not solved here. Search reruns may vary with SciPy/BLAS versions.
