"""Paired benchmark of same start states, same dynamics and verifier.
Calls to the nonlinear optimizer and wall time counted; results reproducible.
"""
import argparse,sys,time,json
from pathlib import Path
import numpy as np
from q2lib.catalog import Catalog
from q2lib.planner import Node,load_q1_prefix,candidates_for_node
from q2lib.events import candidates_for_node_events,solar_visibility_windows
ROOT=Path(__file__).resolve().parent

def prefix_nodes(checkpoint,steps):
    q=json.load(open(checkpoint,encoding='utf8'))['best']
    out=[]
    for p in steps:
        h=q['history'][:p]
        if p==0:
            out.append(Node(0.,np.asarray(q['history'][0]['terminal_observer_state'])*0,visited=()))
            continue
        b=h[-1]
        out.append(Node(float(b['observation_end_s']),np.array(b['terminal_observer_state'],float),
          sum(float(a['cost_m_s']) for a in h),float(b['last_burn_s']),
          tuple(x['target_id'] for x in h),h))
    return out

if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('--steps',default='1,6,12,18')
    a.add_argument('--max-calls',type=int,default=24)
    a.add_argument('--max-per-target',type=int,default=5)
    a.add_argument('--max-days',type=float,default=18.)
    a.add_argument('--step',type=float,default=.05)
    args=a.parse_args()
    cat=Catalog(ROOT/'data.xlsx',dt=1200)
    windows=solar_visibility_windows(cat)
    nodes=prefix_nodes(ROOT/'results/baseline_21_checkpoint.json',list(map(int,args.steps.split(','))))
    records=[]
    for ni,n in enumerate(nodes):
        for mode in ['legacy','events']:
            t0=time.perf_counter()
            if mode=='legacy':
                edges,tested,nvalid=candidates_for_node(cat,n,args.max_days,args.max_per_target,12,
                      cap=85.,low_margin=.12,step=args.step)
                ns=int(tested);valid=int(nvalid)
                screen=None
            else:
                edges,stats=candidates_for_node_events(cat,n,windows,args.max_days,
                     max_events_per_target=4,max_optimizations=args.max_calls,
                     max_candidates=12,step=args.step)
                ns=int(stats.nonlinear_optimizations);valid=int(stats.verified_edges)
                screen=stats.__dict__
            elapsed=time.perf_counter()-t0
            targets={e.target for e in edges}
            r=dict(depth=len(n.visited),mode=mode,optimized=ns,valid_before_cap=valid,
                   returned=len(edges),distinct_targets=len(targets),wall_seconds=elapsed,
                   best_edge_fuel=min((x.J for x in edges),default=None),
                   earliest_edge_day=min((x.verified.observation_end_s/86400 for x in edges),default=None),
                   targets=sorted(targets),screen_stats=screen)
            records.append(r)
            print('BENCH',r['depth'],mode,'wall',round(elapsed,3),'calls',ns,'valid',valid,'targets',len(targets),
                  'edge names',r['targets'],flush=True)
    out=ROOT/'results/node_benchmark.json'
    json.dump(records,open(out,'w',encoding='utf8'),indent=2,ensure_ascii=False)
    print('OUTPUT',out,flush=True)
