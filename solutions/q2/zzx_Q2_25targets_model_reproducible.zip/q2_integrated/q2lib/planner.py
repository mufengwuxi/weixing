"""One-impulse candidate enumeration + SLSQP nonlinear refinement + DOP853 replay.
Search is heuristic. Every counted success is verified under the original nonlinear constraints.
"""
from __future__ import annotations
from dataclasses import dataclass,field
import numpy as np
from scipy.optimize import minimize
from q1_core.dynamics import propagate
from q1_core.kepler_fast import ellipse,propagate_ellipse
from q1_core.transfer import TransferRequest,evaluate_transfer
from q1_core.geometry import sun_position
from .catalog import Catalog,DEADLINE

@dataclass
class Node:
    time: float
    observer: np.ndarray
    fuel: float=0.
    last_burn: float|None=None
    visited: tuple=()
    history: list=field(default_factory=list)
    def serial(self):
        return dict(time_s=float(self.time),observer_state=self.observer.tolist(),
                    used_m_s=float(self.fuel),remaining_m_s=float(300-self.fuel),
                    last_burn_s=self.last_burn,visited=list(self.visited),history=self.history)

@dataclass
class Candidate:
    target: str
    center: float
    burn_time: float
    delta_v: np.ndarray
    J: float
    verified: object
    source: str='single_burn'
    def serialize(self):
        d=self.verified.to_dict()
        d['source']=self.source
        return d


def estimate_oneburn(catalog:Catalog,node:Node,max_days_ahead=18.,cap=90.,max_per_target=6,
                     burn_delay=3600.,return_all=False):
    """For each target and candidate observation center, linearized minimum-impulse
    shooting toward 3 selected points in the double cone. This is a screen only,
    not an admissible lower bound and NOT a physical trajectory.
    """
    tb=max(node.time+burn_delay,(node.last_burn+3600) if node.last_burn is not None else 0)
    if tb+3600>=DEADLINE:return {}
    xb=propagate(node.observer,tb-node.time)
    sel=(catalog.grid>=tb+3600)&(catalog.grid<=min(DEADLINE-30.,node.time+max_days_ahead*86400))
    ts=catalog.grid[sel]
    if not len(ts):return {}
    tau=ts-tb
    R0=propagate_ellipse(ellipse(xb),tau)[0]
    h=1e-5   # perturb 0.01 m/s; centered finite difference; H [km/(m/s)]
    H=np.empty((len(ts),3,3))
    for j in range(3):
        xp=xb.copy();xm=xb.copy()
        xp[3+j]+=h;xm[3+j]-=h
        H[:,:,j]=(propagate_ellipse(ellipse(xp),tau)[0]-propagate_ellipse(ellipse(xm),tau)[0])/(2*h*1000)
    # Ill-conditioning is allowed in the coarse screen; final nonlinear replay gates acceptance.
    good=np.linalg.cond(H)<2e5
    sun=catalog.sun_grid[sel]
    out={}
    for name in catalog.targets:
        if name in node.visited:continue
        rt=catalog.target_grid[name][sel]
        ee=-rt/np.linalg.norm(rt,axis=1)[:,None]
        ss=sun-rt;ss/=np.linalg.norm(ss,axis=1)[:,None]
        gamma=(ss*ee).sum(axis=1)
        mask=(gamma>=np.cos(np.deg2rad(89.2))) & good
        if not mask.any():continue
        q=ss+ee;q/=np.linalg.norm(q,axis=1)[:,None]
        seeds=[]
        for d in [12.,27.,44.]:
            shift=rt+d*q-R0
            u=np.einsum('nij,nj->ni',np.linalg.pinv(H,rcond=1e-10),shift)
            cost=np.linalg.norm(u,axis=1)
            cost[~mask]=np.inf
            hits=np.where(cost<cap)[0]
            for idx in hits:
                seeds.append((float(cost[idx]),float(ts[idx]),float(d),u[idx]))
        if not seeds:continue
        # Keep a mixture of early and fuel-efficient times to avoid a myopic cheapest-route-only policy.
        seeds.sort(key=lambda z:z[0])
        selected=[]
        def add(item):
            if all(abs(item[1]-s[1])>=8*3600 for s in selected):selected.append(item)
        for item in seeds[:max_per_target*3]:add(item)
        # Also retain earliest possible centers under 30 m/s screening.
        early=sorted((q for q in seeds if q[0]<=min(30.,300-node.fuel)),key=lambda z:z[1])
        for item in early[:max_per_target*3]:add(item)
        out[name]=sorted(selected,key=lambda z:z[1])[:max_per_target] if not return_all else selected
    return out


def optimize_fixed_oneburn(catalog:Catalog,node:Node,target:str,burn_time:float,center:float,seed,
                           budget=300.,margin_deg=.12,margin_km=.3,step=.05,maxiter=140):
    """SLSQP minimizes 3D impulse with all 60s interval constraints on 9 nodes,
    then independently verifies the complete trajectory with DOP853 and intersample bounds.
    """
    if target in node.visited:return None
    if center-30<burn_time or center+30>DEADLINE:return None
    if node.last_burn is not None and burn_time-node.last_burn<3600:return None
    if burn_time<node.time:return None
    available=budget-node.fuel
    if available<=0:return None
    xb=propagate(node.observer,burn_time-node.time)
    t_obs=center+np.linspace(-30,30,9)
    rt=catalog.target_at(target,t_obs)
    suns=np.array([sun_position(t) for t in t_obs])-rt;suns/=np.linalg.norm(suns,axis=1)[:,None]
    earth=-rt/np.linalg.norm(rt,axis=1)[:,None]
    c=np.cos(np.deg2rad(45-margin_deg))
    def constraints(u):
        x=xb.copy();x[3:]+=np.asarray(u)*.001
        try:
            ro=propagate_ellipse(ellipse(x),t_obs-burn_time)[0]
            dr=ro-rt;d=np.linalg.norm(dr,axis=1)
            look=dr/d[:,None]
            return np.r_[d-(10+margin_km),50-margin_km-d,
                    40*(np.sum(look*suns,axis=1)-c),
                    40*(np.sum(look*earth,axis=1)-c),
                    30-np.linalg.norm(u), available-np.linalg.norm(u)]
        except (ValueError,FloatingPointError):return np.full(4*len(t_obs)+2,-1e6)
    seeds=[np.asarray(seed,float)]
    if np.linalg.norm(seeds[0])>30:seeds[0]=seeds[0]*29.95/np.linalg.norm(seeds[0])
    opt=minimize(lambda u:np.linalg.norm(u),seeds[0],method='SLSQP',
          bounds=[(-30.,30.)]*3, constraints=[{'type':'ineq','fun':constraints}],
          options={'maxiter':maxiter,'ftol':5e-10})
    if not np.isfinite(opt.x).all() or min(constraints(opt.x))< -1e-5:return None
    req=TransferRequest(node.observer,catalog.targets[target],node.time,DEADLINE,
          available,node.last_burn,target)
    try:r=evaluate_transfer(req,(burn_time,),(opt.x,),center-30,step=step)
    except (RuntimeError,ValueError):return None
    if not r.verified:return None
    return Candidate(target,center,burn_time,opt.x,np.linalg.norm(opt.x),r)


def candidates_for_node(catalog,node,max_days_ahead=18.,max_per_target=5,max_candidates=15,
                        budget=300.,cap=90.,low_margin=.12,step=.05):
    seeds=estimate_oneburn(catalog,node,max_days_ahead,cap,max_per_target)
    feasible=[];tested=0
    for target,v in seeds.items():
        for score,tc,dist,u in v:
            if score>min(80.,budget-node.fuel+20):continue
            tested+=1
            ans=optimize_fixed_oneburn(catalog,node,target,max(node.time+3600,(node.last_burn+3600) if node.last_burn is not None else 0),tc,u,
                              budget=budget,margin_deg=low_margin,step=step)
            if ans:
                feasible.append(ans)
                # One early and one cheap feasible transfer per target generally enough at this stage.
                if sum(c.target==target for c in feasible)>=2:break
    # Diversity across targets; do not rank only by fuel.
    feasible.sort(key=lambda c:(c.center,c.J))
    seen={};eligible=[]
    for c in feasible:
        n=seen.get(c.target,0)
        if n>=2:continue
        eligible.append(c);seen[c.target]=n+1
    eligible.sort(key=lambda c:(c.J+5*(c.center-node.time)/86400,c.center))
    if max_candidates:return eligible[:max_candidates],tested,len(feasible)
    return eligible,tested,len(feasible)


def advance(node,candidate):
    v=candidate.verified
    if not v.verified:raise ValueError('Cannot advance on unverified edge')
    if candidate.target in node.visited:raise ValueError('Duplicate target')
    return Node(time=v.observation_end_s,observer=v.terminal_observer_state.copy(),
          fuel=node.fuel+candidate.J,last_burn=v.last_burn_s,
          visited=node.visited+(candidate.target,),history=node.history+[candidate.serialize()])


def load_q1_prefix(catalog,baseline_json):
    import json
    from q1_core.transfer import TransferRequest,evaluate_transfer
    raw=json.load(open(baseline_json,encoding='utf8'))
    burns=raw['burns']
    req=TransferRequest(catalog.observer,catalog.targets['b1'],0,DEADLINE,300,None,'b1')
    result=evaluate_transfer(req,tuple(b['elapsed_s'] for b in burns),
               tuple(b['delta_v_m_s'] for b in burns),raw['observation_start_s'],step=.0001)
    if not result.verified:raise ValueError('Q1 baseline did not replay')
    a=Candidate('b1',raw['observation_start_s']+30,burns[0]['elapsed_s'],
                np.r_[burns[0]['delta_v_m_s'],burns[1]['delta_v_m_s']],result.cost_m_s,result,'q1_two_burn_seed')
    init=Node(0,catalog.observer.copy())
    out=advance(init,a)
    return out
