"""Verified competition input; target epoch 2027-01-01 00:00 UTC.
No numerical state is fabricated. All 30 target states come from the full workbook.
The observer sign-flipped trial is a separate, explicitly labeled scenario.
"""
from pathlib import Path
import numpy as np
from openpyxl import load_workbook
from q1_core.kepler_fast import ellipse, propagate_ellipse
from q1_core.geometry import sun_position

EPOCH='2027-01-01T00:00:00Z'
DAY=86400.
DEADLINE=30*DAY

class Catalog:
    def __init__(self,path,observer_trial=True,dt=1200.):
        self.path=str(Path(path).resolve());self.observer_trial=bool(observer_trial)
        wb=load_workbook(self.path,read_only=True,data_only=True)
        try:
            ws=wb['Sheet1'];ws.reset_dimensions()
            data={}
            for row in ws.iter_rows(values_only=True):
                if row and isinstance(row[0],str):
                    key=row[0].strip()
                    if key=='r1' or key in [f'b{i}' for i in range(1,31)]:
                        vals=row[1:7]
                        if len(vals)!=6 or any(not isinstance(a,(int,float)) for a in vals):
                            raise ValueError(f'Incomplete orbital state for {key}')
                        data[key]=np.array(vals,float)
        finally:wb.close()
        expected={'r1'}|{f'b{i}' for i in range(1,31)}
        if set(data)!=expected: raise ValueError(f'Unknown/missing IDs: {expected-set(data)}')
        self.raw_observer=data['r1'].copy()
        self.observer=data['r1'].copy()
        if observer_trial:self.observer[[0,1,4,5]]*=-1
        self.targets={f'b{i}':data[f'b{i}'] for i in range(1,31)}
        self.elements={name:ellipse(x) for name,x in self.targets.items()}
        self.grid=np.arange(0,DEADLINE+1,dt)
        self.target_grid={name:propagate_ellipse(self.elements[name],self.grid)[0] for name in self.targets}
        self.sun_grid=np.array([sun_position(t) for t in self.grid])
        self.dt=float(dt)

    def target_at(self,name,t):
        return propagate_ellipse(self.elements[name],np.asarray(t))[0]

    def sun_at(self,t):
        t=np.atleast_1d(t)
        return np.stack([np.interp(t,self.grid,self.sun_grid[:,j]) for j in range(3)],axis=-1)
