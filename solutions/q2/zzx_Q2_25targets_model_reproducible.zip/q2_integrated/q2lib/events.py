"""Event-driven reachability screening for the 30-target problem.

The screen is a fast heuristic *not a lower bound*. Geometric visibility
(Sun/Earth cone intersection) is necessary; finite-difference STM and the
analytic optimum along a cone bisector only rank candidate transfers.
Everything counted as a successful observation is subsequently re-optimized
with the nonlinear Kepler model and verified with independent DOP853.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from time import perf_counter
import signal
from contextlib import contextmanager
import numpy as np
from scipy.optimize import brentq
from q1_core.dynamics import propagate
from q1_core.kepler_fast import ellipse,propagate_ellipse
from q1_core.geometry import sun_position
from .catalog import Catalog, DEADLINE, DAY
from .planner import Node, optimize_fixed_oneburn, Candidate

@dataclass
class EventCounters:
    visible_grid_points: int = 0
    considered_grid_points: int = 0
    event_count: int = 0
    screened_seeds: int = 0
    nonlinear_optimizations: int = 0
    verified_edges: int = 0
    event_seconds: float = 0.
    optimize_seconds: float = 0.
    optimization_timeouts: int = 0


@contextmanager
def _per_edge_limit(seconds):
    """Unix runtime guard for ill-conditioned heuristic starts, never proof pruning."""
    if seconds is None or not hasattr(signal,'setitimer'):
        yield;return
    def abort(signum,frame):raise TimeoutError('Candidate local NLP runtime limit')
    old=signal.signal(signal.SIGALRM,abort)
    signal.setitimer(signal.ITIMER_REAL,float(seconds))
    try:yield
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGALRM,old)


def solar_visibility_windows(cat: Catalog, threshold_deg=90., exact_boundary=True):
    """Target-only angular visibility windows. Shared over all beam states.

    At boundary use geocentric target -> Sun and target -> Earth direction.
    A 60-s observation must lie entirely in one such interval. Input target
    positions and solar ephemerides are interpolated only for broad screening;
    optional root refinement evaluates exact target Kepler and Sun ephemeris.
    """
    result={}
    c=np.cos(np.deg2rad(threshold_deg))
    for name in cat.targets:
        rt=cat.target_grid[name]
        e=-rt/np.linalg.norm(rt,axis=1)[:,None]
        s=cat.sun_grid-rt;s/=np.linalg.norm(s,axis=1)[:,None]
        val=np.sum(s*e,axis=1)-c
        visible=val>=0
        edges=[]
        elems=cat.elements[name]
        def phi(t):
            r=propagate_ellipse(elems,t)[0]
            u=sun_position(t)-r
            return float(np.dot(u,-r)/(np.linalg.norm(u)*np.linalg.norm(r)) - c)
        for j in range(len(val)-1):
            if visible[j]!=visible[j+1]:
                a,b=float(cat.grid[j]),float(cat.grid[j+1])
                if exact_boundary:
                    try:t=brentq(phi,a,b,xtol=1e-5)
                    except ValueError: t=a+(b-a)*abs(val[j])/(abs(val[j])+abs(val[j+1]))
                else:t=a+(b-a)*abs(val[j])/(abs(val[j])+abs(val[j+1]))
                edges.append(float(t))
        bounds=np.r_[0.,edges,DEADLINE]
        result[name]=[(float(a),float(b)) for a,b in zip(bounds[:-1],bounds[1:])
                      if b-a>=60 and phi((a+b)*.5)>=0]
    return result


def analytic_distance_minimum(u0,ud,low=10.3,high=49.7):
    """Minimize ||u0 + d*ud||_2 for d in [low,high], pointwise.

    For each time, u0=H^+(target-pos_uncontrolled) and
    ud=H^+(cone-bisector); this exactly minimizes the linear model along
    the chosen ray, replacing three hand-picked distances in the old screen.
    """
    den=np.einsum('...i,...i->...',ud,ud)
    numer=np.einsum('...i,...i->...',u0,ud)
    return np.clip(-numer/np.maximum(den,1e-24),low,high)


def _event_indices(ts,score,good,max_events=8):
    """Pareto-oriented event selection: explicitly preserve *early* opportunities.

    A very cheap observation on day 18 must NOT suppress a somewhat more
    expensive but mission-enabling opportunity on day 4. Time is a resource.
    """
    viable=np.where(good & np.isfinite(score))[0]
    if not len(viable):return []
    budget_early=viable[score[viable]<=30.5]
    if not len(budget_early):budget_early=viable
    local=[int(i) for i in viable if
           (i==0 or score[i]<=score[i-1]) and
           (i==len(score)-1 or score[i]<=score[i+1])]
    selected=[]
    def add(source,n):
        count=0
        for i in source:
            if all(abs(ts[i]-ts[j])>=6*3600 for j in selected):
                selected.append(int(i));count+=1
            if count>=n or len(selected)>=max_events:break
    add(budget_early,max(2,max_events//2))
    add(sorted(viable,key=lambda i:score[i]),max(1,max_events//3))
    add(sorted(local,key=lambda i:score[i]),max_events)
    add(sorted(viable,key=lambda i:score[i]),max_events)
    return selected[:max_events]


def screen_events(cat:Catalog,node:Node,windows=None,max_days_ahead=18.,
                  cap=45.,max_events_per_target=4,burn_delay=3600.):
    """State-aware vectorized event screening; returns cheap seeds per target.

    Fixed trial burn time at next allowed time + one hour; a later burn can
    only help and requires separate optimization. Nonlinear transfer solver
    is always the arbiter of feasibility.
    """
    tstart=max(node.time+burn_delay,
               node.last_burn+3600 if node.last_burn is not None else 0.)
    tmax=min(DEADLINE-30.,node.time+max_days_ahead*DAY)
    mask=(cat.grid>=tstart+3600)&(cat.grid<=tmax)
    ts=cat.grid[mask]
    counter=EventCounters(considered_grid_points=int(len(ts))*sum(name not in node.visited for name in cat.targets))
    if not len(ts):return {},counter
    xb=propagate(node.observer,tstart-node.time)
    tau=ts-tstart
    base=propagate_ellipse(ellipse(xb),tau)[0]
    # Finite-difference STM, in km/(m/s) unit; only a screening approximation.
    h=1e-5
    H=np.empty((len(ts),3,3))
    for j in range(3):
        xp=xb.copy();xm=xb.copy()
        xp[3+j]+=h;xm[3+j]-=h
        H[:,:,j]=(propagate_ellipse(ellipse(xp),tau)[0]-propagate_ellipse(ellipse(xm),tau)[0])/(2*h*1000)
    pinv=np.linalg.pinv(H,rcond=1e-10)
    well=np.linalg.cond(H)<2e5
    sun=cat.sun_grid[mask]
    out={}
    for name in cat.targets:
        if name in node.visited:continue
        rt=cat.target_grid[name][mask]
        e=-rt/np.linalg.norm(rt,axis=1)[:,None]
        s=sun-rt;s/=np.linalg.norm(s,axis=1)[:,None]
        cosgamma=np.sum(s*e,axis=1)
        # Conservative inner angle margin for viable seed selection: heuristic!
        visible=(cosgamma>=np.cos(np.deg2rad(89.2))) & well
        if windows is not None:
            inside=np.zeros(len(ts),dtype=bool)
            for a,b in windows[name]:inside|=(ts-30>=a)&(ts+30<=b)
            visible&=inside
        counter.visible_grid_points+=int(visible.sum())
        if not visible.any():continue
        q=s+e;q/=np.linalg.norm(q,axis=1)[:,None]
        u0=np.einsum('nij,nj->ni',pinv,rt-base)
        ud=np.einsum('nij,nj->ni',pinv,q)
        ds=analytic_distance_minimum(u0,ud)
        u=u0+ds[:,None]*ud
        score=np.linalg.norm(u,axis=1)
        score[~visible]=np.inf
        good=score<min(cap,max(0.,300-node.fuel+8))
        events=_event_indices(ts,score,good,max_events=max_events_per_target)
        if not events:continue
        counter.event_count+=len(events)
        out[name]=[(float(score[i]),float(ts[i]),float(ds[i]),u[i]) for i in events]
    counter.screened_seeds=sum(map(len,out.values()))
    return out,counter


def candidates_for_node_events(cat,node,windows=None,max_days_ahead=18.,
                               max_events_per_target=4,max_optimizations=24,
                               max_candidates=12,step=.05,low_margin=.12,
                               cap=45.,max_edge_seconds=2.0):
    """One nonlinear solve per chosen event, target-diverse priority.
    No claim that screened-out events are globally infeasible.
    """
    start=perf_counter()
    seeds,stats=screen_events(cat,node,windows,max_days_ahead,
                 cap=cap,max_events_per_target=max_events_per_target)
    stats.event_seconds=perf_counter()-start
    # First candidate of every target, then remaining candidates as needed.
    # Allows Pareto diversity in time & fuel instead of only cheapest edge.
    pool=[]
    for name,rows in seeds.items():
        for rank,(j,tc,d,u) in enumerate(rows):
            # Natural prioritization: value an earlier observability window
            # with small fuel; slight penalty for repeated same target.
            priority=j+4*(tc-node.time)/DAY + 1.5*rank
            pool.append((priority,rank,name,tc,j,d,u))
    pool.sort(key=lambda z:z[0])
    feasible=[];counts={};t0=perf_counter()
    t_burn=max(node.time+3600.,node.last_burn+3600 if node.last_burn is not None else 0.)
    for priority,rank,name,tc,j,d,u in pool:
        if stats.nonlinear_optimizations>=max_optimizations:break
        if counts.get(name,0)>=2:continue
        stats.nonlinear_optimizations+=1
        try:
            with _per_edge_limit(max_edge_seconds):
                result=optimize_fixed_oneburn(cat,node,name,t_burn,tc,u,
                           margin_deg=low_margin,step=step,maxiter=140)
        except (TimeoutError,OverflowError,ValueError):
            stats.optimization_timeouts+=1
            continue
        if result is None:continue
        feasible.append(result);counts[name]=counts.get(name,0)+1
    stats.optimize_seconds=perf_counter()-t0
    stats.verified_edges=len(feasible)
    feasible.sort(key=lambda c:(c.J+5*(c.center-node.time)/DAY,c.center))
    return feasible[:max_candidates],stats
