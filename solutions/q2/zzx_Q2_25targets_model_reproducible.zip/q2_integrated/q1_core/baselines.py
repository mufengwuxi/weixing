"""No-burn reference trajectory, to distinguish physical opportunity from optimization."""
import numpy as np
from scipy.optimize import minimize_scalar
from .dynamics import propagate

def no_burn_min_distance(scenario,end=172800,grid_s=300):
    o=propagate(scenario.observer,end,dense=True)
    t=propagate(scenario.target,end,dense=True)
    def d(sec):return float(np.linalg.norm(o(sec)[:3]-t(sec)[:3]))
    ts=np.arange(0,end,grid_s)
    ts=np.r_[ts,end] if ts[-1]!=end else ts
    v=np.array([d(tt) for tt in ts])
    candidates=[(float(v[0]),float(ts[0])),(float(v[-1]),float(ts[-1]))]
    for i in range(1,len(ts)-1):
        if v[i]<=v[i-1] and v[i]<=v[i+1]:
            sol=minimize_scalar(d,bounds=(ts[i-1],ts[i+1]),method='bounded',options={'xatol':1e-5})
            candidates.append((float(sol.fun),float(sol.x)))
    best=min(candidates)
    return {'closest_distance_km':best[0],'closest_time_s':best[1],'coarse_grid_s':grid_s}
