"""Sharper rigorous calculus constant inside Phase-8 *conditional* phase bound.

This ONLY tightens the q(e,f)=M-f eccentricity-vector gradient estimate.
The Earth-clear assumptions, orbit-envelope bootstrap, solar ephemeris and
floating/interval limitations of Phase 8 remain unchanged.
"""
import math
from .phase_reachability import PhaseReachabilityBound


def tight_q_gradient_bound(e_upper):
    """Bound ||gradient_{eccentricity vector} q|| at fixed true longitude.

    For q=M-f, D=1+e*cos(f), eccentricity e:
      q_e = -sqrt(1-e^2)*sin(f)*(2+e*cos(f))/D^2,
      q_f = (1-e^2)^(3/2)/D^2 - 1.
    The gradient in the two Cartesian components of the eccentricity vector
    has norm sqrt(q_e^2+(q_f/e)^2). The e->0 extension exists and is 2.

    Relative to (-2sin(f),-2cos(f)), the first component error is at most
      a(e)=(3e+4e^2+e^3)/(1-e)^2,
    the second component error is at most
      b(e)=(4.5e+2e^2)/(1-e)^2.
    Therefore K_e(e) <= 2 + hypot(a(e),b(e)).
    These functions are monotone on [0,.01].
    """
    e=float(e_upper)
    if not 0<=e<=0.01:
        raise ValueError('e envelope must be in [0, 0.01]')
    denom=(1.-e)**2
    a=(3*e+4*e*e+e**3)/denom
    b=(4.5*e+2*e*e)/denom
    k_e=(2+math.hypot(a,b))*(1+1e-11)
    # Original safe bound for angle sensitivity: |q_f| / e <= 2.03 for e<=.01
    k_f=2.03*e*(1+1e-11)
    return k_e,k_f

class TightPhaseReachabilityBound(PhaseReachabilityBound):
    """Phase-8 geometry with a justified, tighter eccentricity derivative K_e."""
    def eccentricity_gradient_bound(self,e_max):
        return tight_q_gradient_bound(e_max)
