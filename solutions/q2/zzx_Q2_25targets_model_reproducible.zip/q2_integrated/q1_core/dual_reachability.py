"""A reproducible *linearized-reference-only* impulsive-reachability dual.

WARNING: The output is not a lower bound for the nonlinear two-body model.
This module explicitly exposes the unproved nonlinear correction required
before any value could be used in an optimality certificate for Q1.

The continuous impulse-time supremum for the LTV reference model is bounded by
  |h(tau)| <= |h(tau_c)| cosh(k*h/2)
              + |g(tau_c)| sinh(k*h/2)/k,
where h=Phi_rv(t,tau)^T lambda, g=Phi_rr(t,tau)^T lambda,
k=sqrt(2mu/r_ref_min^3), and |tau-tau_c|<=h/2.
This follows from h'=-g, g'=-A_rr h, ||A_rr||<=k^2.
Only floating-point integrated reference STM nodes are used, not validated ODE
integration. A small numerical guard cannot replace a rigorous STM enclosure.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize
from .model import load_scenario, MU, orbital_elements
from .dynamics import rhs_aug,propagate
from .geometry import sun_position
from .kepler_fast import ellipse,propagate_ellipse

ROOT=Path(__file__).resolve().parents[1]
C45=np.sqrt(.5)
B=np.r_[np.zeros((3,3)),np.eye(3)]
D=np.r_[np.eye(3),np.zeros((3,3))]


def cap_dot_lower(lam_hat,axis,c=C45):
    """True inf_{|u|=1, axis·u>=c} lam_hat·u (both unit)."""
    a=float(lam_hat@axis)
    return -1.0 if a<=-c else a*c-np.sqrt(max(0.,1.-a*a))*np.sqrt(1-c*c)


def cone_scalar_lower(lam,solar,earth,rmin=10.,rmax=50.):
    """Valid lower bound for lambda dot rho for two pointing cones and shell.

    Intersection is a subset of either single cap; max of their individual
    dot-product lower bounds is conservative for the intersection.
    """
    norm=np.linalg.norm(lam)
    if norm<=1e-16:return 0.
    lam=lam/norm
    m=max(cap_dot_lower(lam,solar),cap_dot_lower(lam,earth))
    return float(norm*(rmax*m if m<0 else rmin*m))

class DualStudy:
    def __init__(self,scenario,tlimit=172800,grid_dt=30):
        self.scenario=scenario
        self.grid_dt=grid_dt
        y0=np.r_[scenario.observer,np.eye(6).ravel()]
        sol=solve_ivp(rhs_aug,(0,tlimit),y0,method='DOP853',rtol=2e-12,atol=2e-12,dense_output=True)
        if not sol.success: raise RuntimeError(sol.message)
        self.sol=sol.sol
        self.el_target=ellipse(scenario.target)
        self.ref_min=orbital_elements(scenario.observer)['rp_km']-1
        self.k=np.sqrt(2*MU/self.ref_min**3)
        # Stores inverse at each uniform half-cell midpoint, for all future t.
        cells=np.arange(0,tlimit,grid_dt)
        self.cell_starts=cells
        tmid=cells+grid_dt/2
        full=sol.sol(tmid)
        self.phi_inv=np.linalg.inv(full[6:].T.reshape(-1,6,6))

    def station(self,t):
        y=self.sol(t)
        r0=y[:3]
        phit=y[6:].reshape(6,6)
        target=propagate_ellipse(self.el_target,t)[0]
        s=sun_position(t)-target;s/=np.linalg.norm(s)
        e=-target/np.linalg.norm(target)
        return r0,phit,target,s,e

    def impulse_operator(self,t,coarse=300.):
        # approximate sampled H for optimizing lambda, not used as proof
        xx=np.r_[np.arange(0,t,coarse),t]
        vals=self.sol(xx)
        phis=vals[6:].T.reshape(-1,6,6)
        inv=np.linalg.inv(phis)
        phit=self.sol(t)[6:].reshape(6,6)
        H=(phit[:3,:]@(inv@B)).reshape(-1,3,3)
        return H

    def denominator_sampled(self,H,lam):
        return float(np.linalg.norm(np.einsum('nji,j->ni',H,lam),axis=1).max())

    def denom_continuum_upper(self,t,lam):
        """Continuous-time upper from segment-center STM and variational comparison.

        It is a mathematical bound on the ideal reference LTV equation if center
        STMs were exact; using floating center samples is not interval certified.
        """
        dt=self.grid_dt
        count=int(np.floor(t/dt))
        # covers each full interval [kdt,(k+1)dt], plus one partial interval
        mid=self.cell_starts[:count]+dt/2
        invs=self.phi_inv[:count]
        radii=np.full(count,dt/2.)
        leftover=t-count*dt
        if leftover>1e-10:
            lastmid=count*dt+leftover/2
            yy=self.sol(lastmid)
            inv_last=np.linalg.inv(yy[6:].reshape(6,6))
            mid=np.r_[mid,lastmid]
            invs=np.concatenate([invs,inv_last[None,:,:]],axis=0)
            radii=np.r_[radii,leftover/2]
        phit=self.sol(t)[6:].reshape(6,6)
        M=(phit[:3,:]@invs).reshape(-1,3,6)
        H=np.einsum('mij,jk->mik',M,B)
        G=np.einsum('mij,jk->mik',M,D)
        hh=np.linalg.norm(np.einsum('mji,j->mi',H,lam),axis=-1)
        gg=np.linalg.norm(np.einsum('mji,j->mi',G,lam),axis=-1)
        K=self.k
        den=np.max(hh*np.cosh(K*radii)+gg*np.sinh(K*radii)/K)
        return float(den*1.00000001),float(np.max(hh)),float(np.max(gg))

    def evaluate(self,t,old_guess=None,restarts=4):
        r0,_,target,s,e=self.station(t)
        delta=target-r0
        H=self.impulse_operator(t,coarse=240.)
        def objective(w):
            z=np.linalg.norm(w)
            if z<1e-12:return -1e99
            lam=w/z
            numerator=lam@delta+cone_scalar_lower(lam,s,e)
            return float(numerator*1000./self.denominator_sampled(H,lam))
        starts=[delta/np.linalg.norm(delta)]
        if old_guess is not None:starts.append(np.array(old_guess))
        rng=np.random.default_rng(round(t))
        for _ in range(restarts): starts.append(starts[0]+0.4*rng.normal(size=3))
        best=(-np.inf,None)
        for seed in starts:
            res=minimize(lambda z:-objective(z),seed,method='BFGS',options={'maxiter':75,'gtol':1e-7})
            if objective(res.x)>best[0]:best=(objective(res.x),res.x/np.linalg.norm(res.x))
        lam=best[1]
        num=float(lam@delta+cone_scalar_lower(lam,s,e))
        den,den_grid,Gmax=self.denom_continuum_upper(t,lam)
        # This is for LTV model ONLY. It is not valid for finite nonlinear DV.
        return {
            'common_instant_s':float(t),
            'linearized_dual_lower_bound_m_s':float(num*1000./den),
            'optimized_sampled_ratio_m_s':float(best[0]),
            'numerator_km':num,
            'denominator_km_per_m_s':float(den/1000.),
            'max_grid_impulse_gain_km_per_m_s':float(den_grid/1000.),
            'max_position_stm_gain':Gmax,
            'dual_direction':lam.tolist(),
            'linearized_reference_only':True,
            'nonlinear_error_bound_available':False,
            'required_residual_upper_km_for_true_lb_4p5_m_s':float(num-4.5*den/1000),
            'required_residual_upper_km_for_true_lb_5p0_m_s':float(num-5.0*den/1000)
        }

