"""Select any target b1..b30 without changing the Excel source."""
import numpy as np
from openpyxl import load_workbook

def load_target_state(path,target_id):
    wb=load_workbook(path,read_only=True,data_only=True)
    try:
        ws=wb['Sheet1'];ws.reset_dimensions()
        for row in ws.iter_rows():
            if row and str(row[0].value).strip()==str(target_id):
                arr=np.array([c.value for c in row[1:7]],dtype=float)
                if arr.shape!=(6,) or not np.isfinite(arr).all():
                    raise ValueError('Incomplete target state for '+str(target_id))
                return arr
    finally:
        wb.close()
    raise KeyError('Unknown target ID: '+str(target_id))
