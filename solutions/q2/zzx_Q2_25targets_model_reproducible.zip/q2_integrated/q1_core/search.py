"""Outer maneuver-time search with STM-informed warm starts.
This remains a local, heuristic search, not an interval global-optimality certificate.
"""
import numpy as np
from scipy.optimize import minimize
from .scp import scp_fixed_times,cost,point_metrics,feasible,NODES
from .geometry import angular_windows


def _restore_times(scenario,old,trial,margin,range_margin):
    """Least-squares STM compensation for time changes + nonlinear feasibility restoration.
    Does NOT assume the same six burn components are feasible at changed times.
    """
    t1,t2,tc=trial[:3]; u0=np.array(old[3:],dtype=float)
    _,rho_want,_,_,_=point_metrics(scenario,*old[:3],old[3:],return_linear=True)
    m,rho,H,su,er=point_metrics(scenario,t1,t2,tc,u0,return_linear=True)
    mat=H.reshape(-1,6)
    correction=np.linalg.lstsq(mat,(rho_want-rho).ravel(),rcond=1e-8)[0]
    u=np.clip(u0+correction,-29.99,29.99)
    if feasible(point_metrics(scenario,t1,t2,tc,u),margin,range_margin): return u,'STM warm-start'
    # Nonlinear feasibility restoration: use small movable slack, no invalid solution accepted.
    def cineq(v):
        met=point_metrics(scenario,t1,t2,tc,v)
        return np.r_[met[:,0]-(10+range_margin),50-range_margin-met[:,0],
                    45-margin-met[:,1],45-margin-met[:,2],
                    30-np.linalg.norm(v[:3]),30-np.linalg.norm(v[3:])]
    def objective(v):return .5*(v-u)@(v-u)
    fit=minimize(objective,u,method='SLSQP',bounds=[(-29.99,29.99)]*6,
                 constraints=[{'type':'ineq','fun':cineq}],
                 options={'maxiter':45,'ftol':1e-8,'disp':False})
    if feasible(point_metrics(scenario,t1,t2,tc,fit.x),margin,range_margin):
        return fit.x,'nonlinear feasibility restoration'
    return fit.x,'failed to restore feasibility'


def search_neighbors(scenario,baseline,margin=.009,range_margin=.03,n_cases=12,seed=2027):
    rng=np.random.default_rng(seed)
    t1,t2,center=baseline[:3]
    windows=angular_windows(scenario)
    history=[];best=np.asarray(baseline,dtype=float).copy()
    schedule=[(0,0,0)]
    for j in range(n_cases):
        step=[30,120,360,900][j%4]
        schedule.append((rng.normal()*step,rng.normal()*step,rng.normal()*min(step,24)))
    for idx,(d1,d2,dc) in enumerate(schedule):
        t1new=t1+d1;t2new=t2+d2;cnew=center+dc
        if not (0<=t1new and t2new-t1new>=3600 and t2new<=cnew-30 and cnew+30<=172800):continue
        if not any(w[0]<=cnew-30 and cnew+30<=w[1] for w in windows):continue
        trial=np.r_[t1new,t2new,cnew,baseline[3:]]
        if idx==0:
            u=np.array(baseline[3:]);restore='original'
        else:
            u,restore=_restore_times(scenario,baseline,trial,margin,range_margin)
        m={'trial':idx,'time_offsets_s':[float(d1),float(d2),float(dc)],'restoration':restore,'status':'not_solved'}
        if feasible(point_metrics(scenario,t1new,t2new,cnew,u),margin,range_margin):
            res=scp_fixed_times(scenario,t1new,t2new,cnew,u,
                          angle_margin=margin,range_margin=range_margin,max_iter=13)
            m.update({'status':res['status'],'J':res['J'],'scp_iterations':len(res['trace'])})
            if res['feasible'] and res['J']<cost(best[3:])-2e-7:
                best=np.r_[t1new,t2new,cnew,res['u']]
                m['improved']=True
        else:m['status']='restoration_failed'
        history.append(m)
    return best,history,windows
