"""Geometry-aware, STM-based necessary-condition screening for Q1.

For each admissible observation center, project the unforced relative position
onto the instantaneous convex look-direction cone intersected with the 50-km
ball.  The distance to this relaxed observable set is a necessary displacement
that a maneuver must create at the observation center.

The displacement is then divided by the largest sampled STM position gain
(max ||C Phi(t, tb) B||, km per m/s) over admissible burn times.  This is a
first-order screening score ONLY: it is not a rigorous lower bound for the
original nonlinear controlled two-body problem.  The nonlinear remainder and
continuous 60-s constraints are not certified here.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from .dynamics import propagate, propagate_with_stm
from .geometry import angular_windows, directions
from .model import T_END

C45 = np.sqrt(0.5)
C = np.hstack([np.eye(3), np.zeros((3, 3))])
B = np.vstack([np.zeros((3, 3)), np.eye(3)])


def project_to_instantaneous_observable_set(rho_free, sun_hat, earth_hat,
                                            dmax_km=50.0):
    """Euclidean projection onto {||rho||<=dmax, s.rho>=c||rho||, e.rho>=c||rho||}.

    The 10-km lower range bound is intentionally omitted, making this a
    relaxation of the instantaneous observable set and hence a necessary
    displacement calculation for the linearized model.
    """
    rho_free = np.asarray(rho_free, float)
    s = np.asarray(sun_hat, float)
    e = np.asarray(earth_hat, float)
    def _constraints(x):
        n = np.linalg.norm(x)
        return np.array([dmax_km-n, np.dot(s,x)-C45*n, np.dot(e,x)-C45*n])
    if np.min(_constraints(rho_free)) >= -1e-10:
        return 0.0, rho_free.copy(), True
    b = s + e
    if np.linalg.norm(b) < 1e-12:
        # This should not occur in a geometrically admissible window.
        return np.inf, np.zeros(3), False
    x0 = 0.5 * dmax_km * b / np.linalg.norm(b)

    def cons(x):
        return _constraints(x)

    def jac(x):
        n = max(np.linalg.norm(x), 1e-12)
        u = x / n
        return np.vstack([-u, s - C45 * u, e - C45 * u])

    fit = minimize(lambda x: 0.5 * np.dot(x-rho_free, x-rho_free), x0,
                   jac=lambda x: x-rho_free,
                   method='SLSQP',
                   constraints=[{'type': 'ineq', 'fun': cons, 'jac': jac}],
                   options={'maxiter': 100, 'ftol': 1e-11, 'disp': False})
    x = np.asarray(fit.x, dtype=float)
    # SLSQP may stop a few 1e-7 km outside an active cone boundary.  Since
    # x0 is strictly feasible inside the cone intersection, move the result
    # by the smallest convex-combination amount needed to restore feasibility.
    if np.min(cons(x)) < 0.0:
        if np.min(cons(x0)) < -1e-10:
            return np.inf, x, False
        lo, hi = 0.0, 1.0
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            trial = (1.0-mid)*x + mid*x0
            if np.min(cons(trial)) >= 1e-10:
                hi = mid
            else:
                lo = mid
        x = (1.0-hi)*x + hi*x0
    ok = bool(np.min(cons(x)) >= -1e-9)
    if not ok:
        return np.inf, x, False
    return float(np.linalg.norm(x-rho_free)), x, True


def screen_observation_centers(scenario, center_step_s=600.0,
                               burn_step_s=1800.0, t_end_s=T_END):
    """Rank all geometric windows by a first-order reachability necessary score."""
    windows = angular_windows(scenario, spacing=120.0, t_start=0.0,
                              t_end=float(t_end_s))
    _, _, obs_dense = propagate_with_stm(scenario.observer, t_end_s,
                                         dt_samples=True)
    target_dense = propagate(scenario.target, t_end_s, dense=True)
    out = []
    centers_scanned = 0
    for widx, (wa, wb) in enumerate(windows):
        centers = np.arange(wa + 30.0, wb - 30.0 + 1e-8, center_step_s)
        for center in centers:
            centers_scanned += 1
            start = float(center - 30.0)
            y = obs_dense(float(center))
            xfree = y[:6]
            phi_center = y[6:].reshape(6, 6)
            xt = target_dense(float(center))
            rho_free = xfree[:3] - xt[:3]
            sun_hat, earth_hat = directions(xt[:3][None, :], [center])
            dist_to_set, projected, proj_ok = project_to_instantaneous_observable_set(
                rho_free, sun_hat[0], earth_hat[0])
            if not proj_ok:
                continue

            burn_times = np.arange(0.0, max(start, 0.0) + 1e-8, burn_step_s)
            if len(burn_times) == 0 or burn_times[-1] < start:
                burn_times = np.r_[burn_times, start]
            gains = []
            for tb in burn_times:
                if tb > start + 1e-9:
                    continue
                if tb <= 1e-12:
                    phi_b = np.eye(6)
                else:
                    phi_b = obs_dense(float(tb))[6:].reshape(6, 6)
                # H is km per m/s; B maps km/s, so multiply by 1e-3.
                H = C @ phi_center @ np.linalg.solve(phi_b, B) * 1e-3
                gains.append(float(np.linalg.norm(H, 2)))
            if not gains:
                continue
            max_gain = max(gains)
            score = dist_to_set / max(max_gain, 1e-12)
            out.append({
                'window_index': int(widx),
                'center_s': float(center),
                'center_h': float(center/3600.0),
                'free_distance_km': float(np.linalg.norm(rho_free)),
                'distance_to_relaxed_observable_set_km': float(dist_to_set),
                'projected_relative_position_km': projected.tolist(),
                'max_sampled_stm_gain_km_per_m_s': float(max_gain),
                'linearized_necessary_cost_score_m_s': float(score),
                'screening_only_not_nonlinear_global_bound': True,
            })
    out.sort(key=lambda x: x['linearized_necessary_cost_score_m_s'])
    return {
        'method': 'projection onto instantaneous observable cone-ball + sampled STM gain',
        'windows_s': [[float(a), float(b)] for a,b in windows],
        'centers_scanned': centers_scanned,
        'burn_time_grid_step_s': float(burn_step_s),
        'center_step_s': float(center_step_s),
        'interpretation': 'heuristic first-order necessary-condition ranking; not a rigorous lower bound for nonlinear dynamics',
        'top_candidates': out[:100],
        'all_candidates': out,
    }
