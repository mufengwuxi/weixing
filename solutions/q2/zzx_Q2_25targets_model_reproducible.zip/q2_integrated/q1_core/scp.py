"""Trust-region Sequential Convex Programming for fixed maneuver/observation times.

The convex inner problem consists of second-order cone (SOC) inequalities, plus
linearized lower range (a conservative inner approximation). If cvxpy is absent,
SciPy SLSQP solves the same convex nonlinear constraint form numerically; its
status is NOT a global conic-solver certificate. Candidate is always repropagated.
"""
import numpy as np
from scipy.optimize import minimize
from .dynamics import observation_state_linearization, propagate_burns,propagate
from .geometry import directions,metrics

NODES=np.linspace(0.,60.,13)

def point_metrics(scenario, t1,t2,center,u,nodes=NODES,return_linear=False):
    s=center-30
    obs,H=observation_state_linearization(scenario,t1,t2,center,u,nodes)
    tar_solution=propagate(scenario.target,s+max(nodes),dense=True)
    tar=tar_solution(s+nodes)[:3].T
    su,er=directions(tar,s+nodes)
    met=metrics(obs[:,:3],tar,su,er)
    if return_linear:
        return met,obs[:,:3]-tar,H,su,er
    return met

def cost(u):
    u=np.asarray(u)
    return np.linalg.norm(u[:3])+np.linalg.norm(u[3:])

def feasible(metrics_arr, angle_margin=.01,range_margin=.02):
    d=metrics_arr[:,0]
    return (d.min()>=10+range_margin-1e-7 and d.max()<=50-range_margin+1e-7
            and metrics_arr[:,1:].max()<=45-angle_margin+1e-7)

def solve_convex_model(rho,H,su,er,u0,angle_margin,range_margin,trust):
    """Conic constraints expressed as smooth convex inequalities solved with SLSQP.
       u is absolute burns in m/s. Differentiable analytical Jacobian provided.
    """
    c=np.cos(np.deg2rad(45-angle_margin))
    nr=np.linalg.norm(rho,axis=1)
    rad=rho/nr[:,None]

    def _core(u):
        r=rho+np.einsum('nik,k->ni',H,u-u0)
        dist=np.linalg.norm(r,axis=1)
        unit=r/dist[:,None]
        return r,dist,unit

    def fun(u):
        return (np.sqrt(np.dot(u[:3],u[:3])+1e-14)+np.sqrt(np.dot(u[3:],u[3:])+1e-14))
    def grad(u):
        return np.r_[u[:3]/np.sqrt(u[:3]@u[:3]+1e-14),u[3:]/np.sqrt(u[3:]@u[3:]+1e-14)]
    # Linearized range lower bound: rho_hat(reference) dot rho_new >= R_min.
    def con(u):
        r,d,unit=_core(u)
        return np.r_[d*0+ np.einsum('ni,ni->n',su,r)-c*d,
                     np.einsum('ni,ni->n',er,r)-c*d,
                     50-range_margin-d,
                     np.einsum('ni,ni->n',rad,r)-(10+range_margin),
                     30-np.linalg.norm(u[:3]),30-np.linalg.norm(u[3:]),
                     trust**2-(u-u0)@(u-u0)]
    def jac(u):
        r,d,unit=_core(u)
        out=[np.einsum('ni,nik->nk',su-c*unit,H),
             np.einsum('ni,nik->nk',er-c*unit,H),
             -np.einsum('ni,nik->nk',unit,H),
             np.einsum('ni,nik->nk',rad,H)]
        n1=np.linalg.norm(u[:3]);n2=np.linalg.norm(u[3:])
        q1=np.r_[-u[:3]/max(n1,1e-10),np.zeros(3)]
        q2=np.r_[np.zeros(3),-u[3:]/max(n2,1e-10)]
        return np.vstack([*out,q1,q2, -2*(u-u0)])
    constraints=[{'type':'ineq','fun':con,'jac':jac}]
    sol=minimize(fun,u0,jac=grad,constraints=constraints,method='SLSQP',
            bounds=[(-30,30)]*6,options={'maxiter':130,'ftol':2e-10,'disp':False})
    return sol, float(np.min(con(sol.x)))

def scp_fixed_times(scenario,t1,t2,center,u0,
                    angle_margin=.01,range_margin=.03,
                    max_iter=18,initial_trust=.6,verbose=False):
    """Feasible SCP with trial acceptance by nonlinear (not linearized) trajectory.
    Starts from a physically feasible burn vector. Returns history and best vector.
    """
    u=np.asarray(u0,dtype=float).copy()
    m=point_metrics(scenario,t1,t2,center,u)
    if not feasible(m,angle_margin,range_margin):
        return {'status':'infeasible_start','u':u,'J':cost(u),'trace':[],'feasible':False}
    best=u.copy();hist=[];trust=float(initial_trust)
    for itr in range(max_iter):
        m,rho,H,su,er=point_metrics(scenario,t1,t2,center,u,return_linear=True)
        sol,conmin=solve_convex_model(rho,H,su,er,u,angle_margin,range_margin,trust)
        delta=sol.x-u
        accept=False
        for factor in [1.,.5,.25,.125,.0625,.03125]:
            proposal=u+factor*delta
            if cost(proposal)>=cost(u)-2e-8:continue
            mm=point_metrics(scenario,t1,t2,center,proposal)
            if feasible(mm,angle_margin,range_margin):
                best=proposal.copy(); accept=True;break
        hist.append({'it':itr+1,'fuel_m_s':float(cost(best if accept else u)),
                     'soc_subproblem_status':str(sol.message),'linear_min_slack':conmin,
                     'trust_m_s':trust,'accepted':accept})
        if verbose: print('SCP',itr+1,'cost',hist[-1]['fuel_m_s'],'accepted',accept,'trust',trust,flush=True)
        if accept:
            reduction=cost(u)-cost(best)
            u=best.copy()
            trust=min(2.,trust*1.25)
            if reduction<1e-6:break
        else:
            trust*=.5
            if trust<5e-5:break
    return {'status':'completed','u':u,'J':float(cost(u)),'trace':hist,'feasible':True}
