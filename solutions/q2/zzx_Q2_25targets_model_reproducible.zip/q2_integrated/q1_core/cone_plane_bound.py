"""Nonlinear, direction-aware angular-momentum necessary cost bound.

For a final observation position r_T+rho, h_f·(r_T+rho)=0. Starting
angular momentum h0, each impulsive change obeys |Delta h|<=R_max|dv|.
Therefore |h0·(r_T+rho)| <= R_max*U*(|r_T|+50), where rho is in the
exact intersection of the two angle cones and the 10-50 km shell. Taking
the least possible absolute value over this geometry gives a necessary
lower bound that uses *both* angle constraints without STM linearization.

R_max must be a genuine global upper bound for all two-burn U<=incumbent
coasts. The certified_invariants module supplies such a bound without
assuming Earth clearance. Using finite-precision target/Sun values here
is a numerical proof prototype, not a formally rounded interval certificate.
"""
from __future__ import annotations
import numpy as np
from .two_time_dual import exact_shell_cone_support


def cone_plane_cost_lower_m_s(observer_state,target_pos,solar_axis,earth_axis,
                              observer_rmax_km=42504.676):
    h=np.cross(observer_state[:3],observer_state[3:]); hnorm=np.linalg.norm(h)
    hn=h/hnorm
    l=exact_shell_cone_support(hn,solar_axis,earth_axis)
    r=exact_shell_cone_support(-hn,solar_axis,earth_axis)
    if l is None or r is None:return None
    val=float(hn@target_pos)
    low=val+l
    high=val-r
    dist= max(0.,low,-high)
    u_kms=hnorm*dist/(observer_rmax_km*(np.linalg.norm(target_pos)+50))
    return {'nonlinear_plane_lower_m_s':max(0.,float(u_kms*1000)),
            'minimal_normal_residual_km':dist,
            'signed_residual_interval_km':[low,high],
            'uses_exact_double_cone_geometry':True,
            'orbit_envelope_proved_independently':True}
