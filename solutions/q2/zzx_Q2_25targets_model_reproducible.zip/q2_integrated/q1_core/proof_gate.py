"""Guard against rebranding an LTV/STM proxy as an exact-Kepler bound.

The exact identity is
  lambda1·delta_r(t1)+lambda2·delta_r(t2)
    <= J*K + lambda1·R(t1)+lambda2·R(t2),
where R is the *nonlinear* finite-impulse remainder.
Only validated interval upper bounds on the right-hand terms can yield an
actual objective lower bound. These functions explicitly reject missing
proof obligations rather than invent a value.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict

@dataclass(frozen=True)
class NonlinearProofObligations:
    reference_STM_validated: bool = False
    reference_target_sun_enclosed: bool = False
    nonlinear_remainder_validated: bool = False
    continuous_burn_time_bound_validated: bool = False
    time_box_covering_validated: bool = False
    all_time_boxes_processed: bool = False
    physical_input_model_confirmed: bool = False

    def check(self):
        failed=[k for k,v in asdict(self).items() if not v]
        if failed:
            raise ValueError('Cannot certify nonlinear Kepler lower bound; '
                             'missing proof obligations: '+', '.join(failed))


def prove_lower_from_dual(numerator_km,denominator_km_per_m_s,
                          nonlinear_remainder_upper_km,obligations):
    """Only returns a certified lower bound if all preconditions are asserted.

    This is a proof checker for numeric *inequalities*, not a validated ODE
    integrator. Callers remain responsible for supplying authentic
    outward-rounded interval evidence supporting each assertion.
    """
    obligations.check()
    if denominator_km_per_m_s<=0 or nonlinear_remainder_upper_km<0:
        raise ValueError('Invalid enclosure bounds')
    return max(0., (numerator_km-nonlinear_remainder_upper_km)/denominator_km_per_m_s)
