"""Fast vectorized Kepler ellipse propagation for candidate search only.
Final solutions MUST be verified by the independent DOP853 propagator.
"""
import numpy as np
from .model import MU

def ellipse(state):
    r=np.asarray(state[:3],dtype=float);v=np.asarray(state[3:],dtype=float)
    R=np.linalg.norm(r);h=np.cross(r,v); hnorm=np.linalg.norm(h)
    evec=np.cross(v,h)/MU-r/R;e=np.linalg.norm(evec)
    energy=v@v/2-MU/R
    if e>=1 or energy>=0: raise ValueError('Elliptic orbit required')
    a=-MU/(2*energy)
    P=evec/e if e>1e-10 else r/R
    Q=np.cross(h/hnorm,P)
    E=np.arctan2(r@Q/(a*np.sqrt(1-e*e)),r@P/a+e)
    M=E-e*np.sin(E)
    n=np.sqrt(MU/a**3)
    return a,e,P,Q,M,n

def propagate_ellipse(elements,t):
    a,e,P,Q,M,n=elements
    t=np.asarray(t,dtype=float);E=np.asarray(M+n*t)
    for _ in range(10):
        delta=(E-e*np.sin(E)-M-n*t)/(1-e*np.cos(E))
        E=E-delta
        if np.max(np.abs(delta))<1e-13:break
    c=np.cos(E);s=np.sin(E)
    r=(a*(c-e))[...,None]*P+(a*np.sqrt(1-e*e)*s)[...,None]*Q
    v=(n*a/(1-e*c))[...,None]*((-s)[...,None]*P+np.sqrt(1-e*e)*c[...,None]*Q)
    return r,v
