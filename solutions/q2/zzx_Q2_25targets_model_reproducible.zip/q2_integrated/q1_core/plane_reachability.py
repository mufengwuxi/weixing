"""Analytical angular-momentum reachability bounds for Q1 observation-time boxes.

This module derives a necessary lower bound on total impulsive delta-v for any
trajectory that can be within d_max of the target at a selected instant.
It is useful for *safe time-box pruning* against a known incumbent, conditional
on the physical no-Earth-intersection constraint.

It is not a complete global-optimality certificate: boxes whose bound is below
the incumbent still require nonlinear optimization, and numerical ephemeris /
propagation errors are not interval-certified here.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import numpy as np
from scipy.optimize import brentq
from mpmath import iv, mp

from .model import MU, R_E, T_END, orbital_elements
from .dynamics import propagate
from .geometry import sun_position
from .interval_kepler import IntervalKeplerOrbit


@dataclass(frozen=True)
class OrbitEnvelope:
    impulse_budget_km_s: float
    energy0_km2_s2: float
    energy_upper_km2_s2: float
    semimajor_axis_upper_km: float
    eccentricity_upper: float
    angular_momentum_lower_km2_s: float
    periapsis_lower_km: float
    apoapsis_upper_km: float
    speed_upper_km_s: float
    iterations: int
    earth_radius_assumption_km: float
    derivation: str = "energy + angular momentum + eccentricity-vector impulse bounds"


def _energy_upper(energy0: float, impulse_budget: float,
                  radius_lower: float) -> float:
    """Solve Ebar=E0+U*sqrt(2(Ebar+mu/rmin))+U^2/2."""
    U = float(impulse_budget)
    def residual(E):
        arg = 2.0 * (E + MU / radius_lower)
        if arg < 0:
            return -np.inf
        return E - energy0 - U * np.sqrt(arg) - 0.5 * U * U
    f0 = residual(0.0)
    if not np.isfinite(f0) or f0 <= 0.0:
        raise ValueError("Impulse budget does not yield a guaranteed bound elliptic envelope")
    root = float(brentq(residual, energy0, 0.0, xtol=1e-14, rtol=1e-13))
    # Outward safety offset: energy upper bounds are shifted toward zero.
    return float(np.nextafter(root + 1e-10, np.inf))


def observer_orbit_envelope(observer_state, impulse_budget_m_s: float,
                             earth_radius_km: float = R_E,
                             max_iter: int = 100) -> OrbitEnvelope:
    """Bound every Kepler arc for all pulse sequences with total |dv| <= U.

    Assumption: the observer never enters the Earth, so r >= earth_radius_km.
    For each impulse, |dE| <= |v|u + u^2/2,
    |dh| <= r_max u, and
    |de_vec| <= (2 r_max v_max u + r_max u^2)/mu.
    A monotone bootstrap tightens the radial and speed bounds.
    """
    x = np.asarray(observer_state, dtype=float)
    U = float(impulse_budget_m_s) * 1e-3
    if U < 0:
        raise ValueError("Impulse budget must be nonnegative")
    el = orbital_elements(x)
    energy0 = -MU / (2.0 * el["a_km"])
    h0 = float(np.linalg.norm(np.cross(x[:3], x[3:])))
    e0 = float(el["e"])
    rmin = float(earth_radius_km)
    # Initially every elliptic orbit has r_a < 2a.
    rmax = 2.0 * el["a_km"]
    iterations = 0
    for iterations in range(1, max_iter + 1):
        Ebar = _energy_upper(energy0, U, rmin)
        if Ebar >= 0:
            raise ValueError("Energy envelope is not guaranteed elliptic")
        amax = -MU / (2.0 * Ebar)
        vmax = np.sqrt(max(0.0, 2.0 * (Ebar + MU / rmin))) * (1.0 + 1e-10)
        hmin = h0 - rmax * U - 1e-8
        emax = e0 + (2.0 * rmax * vmax * U + rmax * U * U) / MU + 1e-12
        if hmin <= 0.0 or emax >= 1.0:
            raise ValueError("Angular-momentum/eccentricity envelope is too weak")
        rmin_new = hmin * hmin / (MU * (1.0 + emax)) * (1.0 - 1e-10)
        rmax_new = amax * (1.0 + emax) * (1.0 + 1e-10)
        # Both updates are conservative improvements from already valid bounds.
        rmin_next = max(rmin, min(rmin_new, rmax_new))
        rmax_next = min(rmax, max(rmax_new, rmin_next))
        if max(abs(rmin_next-rmin), abs(rmax_next-rmax)) < 1e-9:
            rmin, rmax = rmin_next, rmax_next
            break
        rmin, rmax = rmin_next, rmax_next
    # Re-evaluate final bounds at the final radius interval.
    Ebar = _energy_upper(energy0, U, rmin)
    amax = -MU / (2.0 * Ebar)
    vmax = np.sqrt(max(0.0, 2.0 * (Ebar + MU / rmin))) * (1.0 + 1e-10)
    hmin = h0 - rmax * U - 1e-8
    emax = e0 + (2.0 * rmax * vmax * U + rmax * U * U) / MU + 1e-12
    rmin_check = hmin*hmin/(MU*(1.0+emax)) * (1.0 - 1e-10)
    rmax_check = amax*(1.0+emax) * (1.0 + 1e-10)
    if rmin_check < rmin - 1e-7 or rmax_check > rmax + 1e-7:
        raise RuntimeError("Envelope bootstrap did not close conservatively")
    return OrbitEnvelope(
        impulse_budget_km_s=U,
        energy0_km2_s2=float(energy0),
        energy_upper_km2_s2=float(Ebar),
        semimajor_axis_upper_km=float(amax),
        eccentricity_upper=float(emax),
        angular_momentum_lower_km2_s=float(hmin),
        periapsis_lower_km=float(rmin * (1.0 - 1e-8)),
        apoapsis_upper_km=float(rmax * (1.0 + 1e-8)),
        speed_upper_km_s=float(vmax),
        iterations=iterations,
        earth_radius_assumption_km=float(earth_radius_km),
    )


def plane_impulse_lower_bound(observer_state, target_position,
                              observer_apoapsis_upper_km: float,
                              d_max_km: float = 50.0) -> dict:
    """Necessary total-impulse lower bound from orbital-plane geometry.

    At observation time, r_O is within d_max of r_T and the post-last-burn
    angular momentum h_f is perpendicular to r_O. The target direction is
    beta radians out of the initial observer plane. The observer direction can
    differ from r_T by at most asin(d_max/|r_T|), hence h_f must rotate by at
    least max(0, beta-delta). Since |h_f-h_0| <= r_apo,max * sum|dv|,

        sum|dv| >= |h_0| sin(max(0,beta-delta)) / r_apo,max.

    Returned lower bound is in m/s. This is a necessary condition, not a
    sufficient transfer cost.
    """
    x = np.asarray(observer_state, dtype=float)
    rt = np.asarray(target_position, dtype=float)
    rn = float(np.linalg.norm(rt))
    if rn <= d_max_km:
        raise ValueError("Target geocentric radius must exceed d_max")
    h0v = np.cross(x[:3], x[3:])
    h0 = float(np.linalg.norm(h0v))
    hhat = h0v / h0
    beta = float(np.arcsin(np.clip(abs(np.dot(rt / rn, hhat)), 0.0, 1.0)))
    delta = float(np.arcsin(d_max_km / rn))
    required_rotation = max(0.0, beta - delta)
    lower_km_s = h0 * np.sin(required_rotation) / float(observer_apoapsis_upper_km)
    return {
        "target_radius_km": rn,
        "initial_plane_miss_angle_deg": float(np.degrees(beta)),
        "position_tolerance_angle_deg": float(np.degrees(delta)),
        "minimum_plane_rotation_deg": float(np.degrees(required_rotation)),
        "delta_v_lower_bound_m_s": float(1000.0 * lower_km_s),
    }


def _iv_lo(x):
    return mp.mpf(x.a)


def _iv_hi(x):
    return mp.mpf(x.b)


def _iv_abs_lower(x):
    lo, hi = _iv_lo(x), _iv_hi(x)
    if lo > 0:
        return lo
    if hi < 0:
        return -hi
    return mp.mpf('0')


def _interval_plane_lower_bound(observer_state, target_xyz, rmax_upper_km, d_max_km=50.0):
    """Interval-evaluated lower bound using an interval Kepler target position."""
    obs = [iv.mpf(str(float(q))) for q in np.asarray(observer_state, dtype=float)]
    r0, v0 = obs[:3], obs[3:]
    h0v = [r0[1]*v0[2]-r0[2]*v0[1],
           r0[2]*v0[0]-r0[0]*v0[2],
           r0[0]*v0[1]-r0[1]*v0[0]]
    h0n = iv.sqrt(sum((q*q for q in h0v), iv.mpf('0')))
    hhat = [q/h0n for q in h0v]
    rn = iv.sqrt(sum((q*q for q in target_xyz), iv.mpf('0')))
    rhat = [q/rn for q in target_xyz]
    dot = sum((x*y for x,y in zip(rhat,hhat)), iv.mpf('0'))
    absdot_lower = _iv_abs_lower(dot)
    # mpmath's interval context does not expose asin in all supported versions.
    # Avoid inverse trigonometric interval evaluation entirely. For
    # beta=asin(|rhat dot hhat|), delta=asin(d_max/r),
    # sin(beta-delta)=sin(beta)cos(delta)-cos(beta)sin(delta).
    # Use a lower bound on sin(beta) and an upper bound on sin(delta), then
    # outward-rounded interval arithmetic to obtain a conservative lower bound.
    rn_lower = _iv_lo(rn)
    x = iv.mpf([str(absdot_lower), str(absdot_lower)])
    y = iv.mpf([str(d_max_km/rn_lower), str(d_max_km/rn_lower)])
    cos_beta = iv.sqrt(1 - x*x)
    cos_delta = iv.sqrt(1 - y*y)
    sin_difference = x*cos_delta - cos_beta*y
    sin_difference_lower = max(mp.mpf('0'), _iv_lo(sin_difference))
    h0_lower = _iv_lo(h0n)
    lb = h0_lower * sin_difference_lower / mp.mpf(str(rmax_upper_km))
    # Round the reported lower bound down by a tiny relative guard.
    return max(0.0, float(lb * 1000 * (1-mp.mpf('1e-12')))), float(rn_lower), float(absdot_lower)


def _interval_cos_sun_earth(sun_xyz, target_xyz, sun_pad_km=1e-6):
    sun = [iv.mpf([str(float(q)-sun_pad_km),str(float(q)+sun_pad_km)]) for q in sun_xyz]
    qs = [sun[i]-target_xyz[i] for i in range(3)]
    qe = [-target_xyz[i] for i in range(3)]
    dot = sum((qs[i]*qe[i] for i in range(3)), iv.mpf('0'))
    ns = iv.sqrt(sum((q*q for q in qs), iv.mpf('0')))
    ne = iv.sqrt(sum((q*q for q in qe), iv.mpf('0')))
    return dot/(ns*ne)


def screen_center_time_boxes(scenario, incumbent_m_s: float,
                             box_width_s: float = 60.0,
                             d_max_km: float = 50.0,
                             t_end_s: float = T_END) -> dict:
    """Safely prune observation-center time boxes over the *entire* horizon.

    A box [a,b] has width <=60 s. Its midpoint m belongs to every possible
    60-s observation interval generated by a center c in [a,b]. Therefore
    every feasible trajectory in that box must satisfy, at the same instant m:
      (i) the two 45-degree look cones intersect (Sun-Earth angle <=90 deg),
      (ii) the observer is within d_max of the target.

    Condition (i) is checked directly at m. Condition (ii) yields the
    angular-momentum plane-rotation lower bound. If that lower bound exceeds
    the incumbent, the entire box cannot contain a strictly better solution.

    The algebraic bound is conditional on no Earth intersection and on the
    exact states at m. The orbit/ephemeris propagation used to evaluate those
    states is floating-point, not a validated interval integrator. This is a
    rigorous necessary-condition prune at the mathematical level, but not a
    complete machine-certified global-optimality proof.
    """
    if not (0.0 < box_width_s <= 60.0):
        raise ValueError("box_width_s must be in (0,60] so every window shares its midpoint")
    env = observer_orbit_envelope(scenario.observer, incumbent_m_s)
    target_orbit_iv = IntervalKeplerOrbit(scenario.target)
    rows = []
    center_lo, center_hi = 30.0, float(t_end_s)-30.0
    nbox = int(np.ceil((center_hi-center_lo)/box_width_s))
    for k in range(nbox):
        a = center_lo + k*box_width_s
        b = min(center_hi, a+box_width_s)
        mid = 0.5*(a+b)
        target_iv = target_orbit_iv.position_interval(int(round(mid))).xyz
        sun = sun_position(mid)
        cos_gamma = _interval_cos_sun_earth(sun, target_iv)
        cos_lo, cos_hi = float(_iv_lo(cos_gamma)), float(_iv_hi(cos_gamma))
        geom_ok = cos_hi >= -1e-14
        lb_m_s, target_radius_lower_km, plane_sine_lower = _interval_plane_lower_bound(
            scenario.observer, target_iv, env.apoapsis_upper_km, d_max_km)
        plane_ok = lb_m_s <= incumbent_m_s + 1e-10
        if not geom_ok:
            reason = "look_cones_disjoint_at_common_instant"
        elif not plane_ok:
            reason = "angular_momentum_plane_lower_bound_exceeds_incumbent"
        else:
            reason = "retained_for_nonlinear_search"
        rows.append({
            "center_box_start_s": float(a),
            "center_box_end_s": float(b),
            "center_box_mid_s": float(mid),
            "sun_earth_cos_interval": [cos_lo, cos_hi],
            "target_position_interval_km": [[float(_iv_lo(q)), float(_iv_hi(q))] for q in target_iv],
            "target_radius_lower_km": target_radius_lower_km,
            "initial_plane_sine_lower": plane_sine_lower,
            "delta_v_lower_bound_m_s": lb_m_s,
            "look_cones_intersect_at_midpoint": bool(geom_ok),
            "excluded_for_strict_improvement": bool(not (geom_ok and plane_ok)),
            "prune_reason": reason,
        })
    retained = [r for r in rows if not r["excluded_for_strict_improvement"]]
    geom_excluded = [r for r in rows if not r["look_cones_intersect_at_midpoint"]]
    plane_excluded = [r for r in rows if r["look_cones_intersect_at_midpoint"] and
                      r["delta_v_lower_bound_m_s"] > incumbent_m_s + 1e-10]
    # Merge adjacent retained boxes into intervals for compact reporting.
    intervals = []
    for r in retained:
        if intervals and abs(intervals[-1][1]-r["center_box_start_s"]) < 1e-8:
            intervals[-1][1] = r["center_box_end_s"]
        else:
            intervals.append([r["center_box_start_s"], r["center_box_end_s"]])
    return {
        "method": "60-s common-instant time-box pruning with interval Kepler target position + interval Sun/Earth cone test + angular-momentum plane lower bound",
        "incumbent_m_s": float(incumbent_m_s),
        "box_width_s": float(box_width_s),
        "assumption": "observer remains outside Earth: ||r_O(t)|| >= R_E throughout; at most two impulses and total delta-v <= incumbent",
        "observer_envelope": asdict(env),
        "total_center_boxes": len(rows),
        "geometry_excluded_boxes": len(geom_excluded),
        "plane_bound_excluded_boxes": len(plane_excluded),
        "retained_boxes": len(retained),
        "retained_fraction": float(len(retained)/len(rows)),
        "retained_center_intervals_s": intervals,
        "minimum_plane_bound_m_s": float(min(r["delta_v_lower_bound_m_s"] for r in rows)),
        "maximum_plane_bound_m_s": float(max(r["delta_v_lower_bound_m_s"] for r in rows)),
        "target_state_method": "mpmath outward-rounded interval Kepler propagation at each box common instant; initial state decimal strings; Moshier Sun vector padded by 1e-6 km for floating evaluation",
        "boxes": rows,
        "scope": "safe necessary-condition pruning for all center boxes conditional on Earth-clear trajectories; retained boxes remain unresolved; not a complete global-optimality certificate",
    }
