"""Validated interval Kepler propagation for elliptic two-body target orbits.

Uses mpmath's outward-rounded interval arithmetic and the monotonic Kepler
map E - e sin(E) = M. The interval Newton enclosure is iterated from the
rigorous bracket M-e <= E <= M+e. This module returns an interval box for the
Cartesian position at an exact requested time, given interval-enclosed input
state components.

The implementation is intended for narrow input intervals and non-singular
elliptic states (0 < e < 1). It does not model ephemeris uncertainty.
"""
from __future__ import annotations
from dataclasses import dataclass
from mpmath import iv, mp

iv.dps = 50
mp.dps = 50


def _I(x):
    if hasattr(x, '_mpi_'):
        return x
    return iv.mpf(str(x))


def _lo(x):
    return mp.mpf(x.a)


def _hi(x):
    return mp.mpf(x.b)


def _interval(lo, hi):
    return iv.mpf([str(lo), str(hi)])


def _dot(a, b):
    out = iv.mpf('0')
    for x, y in zip(a, b):
        out += x*y
    return out


def _cross(a, b):
    return [a[1]*b[2]-a[2]*b[1],
            a[2]*b[0]-a[0]*b[2],
            a[0]*b[1]-a[1]*b[0]]


def _norm(a):
    return iv.sqrt(_dot(a, a))


@dataclass
class IntervalPosition:
    xyz: tuple
    eccentric_anomaly: object
    mean_anomaly: object
    newton_iterations: int

    def bounds(self):
        return [(float(_lo(x)), float(_hi(x))) for x in self.xyz]

    def midpoint(self):
        return [0.5*(a+b) for a,b in self.bounds()]


class IntervalKeplerOrbit:
    """Precomputed interval orbital elements for one elliptic initial state."""
    def __init__(self, state, mu=398600.4418):
        vals = list(state)
        self.mu = _I(mu)
        r = [_I(x) for x in vals[:3]]
        v = [_I(x) for x in vals[3:]]
        rn = _norm(r)
        h = _cross(r, v)
        hn = _norm(h)
        energy = _dot(v, v)/2 - self.mu/rn
        if _hi(energy) >= 0:
            raise ValueError('Elliptic orbit required')
        self.a = -self.mu/(2*energy)
        evec0 = _cross(v, h)
        evec = [evec0[i]/self.mu-r[i]/rn for i in range(3)]
        self.e = _norm(evec)
        if _lo(self.e) <= 0 or _hi(self.e) >= 1:
            raise ValueError('Interval Kepler parameterization requires 0 < e < 1')
        self.P = [x/self.e for x in evec]
        hhat = [x/hn for x in h]
        self.Q = _cross(hhat, self.P)
        cosE0 = _dot(r, self.P)/self.a + self.e
        sinE0 = _dot(r, self.Q)/(self.a*iv.sqrt(1-self.e*self.e))
        self.E0 = iv.atan2(sinE0, cosE0)
        self.M0 = self.E0-self.e*iv.sin(self.E0)
        self.n = iv.sqrt(self.mu/(self.a*self.a*self.a))

    def eccentric_anomaly_interval(self, t_s, max_iter=40, tol='1e-38'):
        t = _I(t_s)
        M = self.M0+self.n*t
        lo = _lo(M)-_hi(self.e)
        hi = _hi(M)+_hi(self.e)
        E = _interval(lo, hi)
        tol_mp = mp.mpf(tol)
        used = 0
        for used in range(1, max_iter+1):
            lo = _lo(E); hi = _hi(E)
            mid = (lo+hi)/2
            mI = _interval(mid, mid)
            fmid = mI-self.e*iv.sin(mI)-M
            deriv = 1-self.e*iv.cos(E)
            newton = mI-fmid/deriv
            lo_new = max(lo, _lo(newton))
            hi_new = min(hi, _hi(newton))
            if lo_new > hi_new:
                # The interval Newton image can be empty only from rounding or
                # excessive dependency; retain the previous guaranteed bracket.
                break
            E = _interval(lo_new, hi_new)
            if hi_new-lo_new <= tol_mp:
                break
        return M, E, used

    def position_interval(self, t_s) -> IntervalPosition:
        M, E, iters = self.eccentric_anomaly_interval(t_s)
        c = iv.cos(E); s = iv.sin(E)
        root = iv.sqrt(1-self.e*self.e)
        xyz = tuple(self.a*(c-self.e)*self.P[i] + self.a*root*s*self.Q[i]
                    for i in range(3))
        return IntervalPosition(xyz, E, M, iters)
