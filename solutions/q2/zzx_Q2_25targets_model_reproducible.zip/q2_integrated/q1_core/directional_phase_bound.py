"""Direction-aware exact-Kepler phase necessary bound for Q1.

Replaces the generic ±50sin45 transverse line-of-sight tolerance by a
signed solar-cap support bound: the observation line can shift the projected
observer azimuth *toward the nominal reference* by at most
 d_max * max(0, max_{u: s·u>=cos45} q·u).
This does not linearize spacecraft dynamics. The solar cap maximum is
analytic. Solar/source interval arithmetic is used for its input geometry.
The inherited phase-motion upper envelope is the Phase-9 conditional
nonlinear Kepler analytic result; this file does NOT validate that whole proof.
"""
from __future__ import annotations
from math import cos,pi,nextafter,inf
import math
import numpy as np
from scipy.optimize import brentq
from mpmath import iv,mp
from .phase_reachability import _dot,_norm,_lo,_hi,_interval_reference_basis,projected_phase_geometry_lower_bound
from .tight_phase_reachability import TightPhaseReachabilityBound
from .certified_invariants import certified_enclosure

C45=math.sqrt(.5)

def solar_signed_azimuth_tolerance(observer_interval,target_interval,e1,e2,sun_pos_xyz,
                                   t_s,dmax=50.,sun_pad_km=1e-6):
    old=projected_phase_geometry_lower_bound(observer_interval,target_interval,e1,e2,t_s,dmax)
    ro=observer_interval.position_interval(t_s).xyz
    rt=target_interval.position_interval(t_s).xyz
    xo,yo=_dot(ro,e1),_dot(ro,e2)
    xt,yt=_dot(rt,e1),_dot(rt,e2)
    cross=xo*yt-yo*xt
    sigma=1 if _lo(cross)>0 else (-1 if _hi(cross)<0 else 0)
    if sigma==0:
        return {**old,'directional_azimuth_tolerance_upper_rad':old['azimuth_tolerance_upper_rad'],
                'signed_solar_support_tan_max_km':50/math.sqrt(2),
                'directionally_improved':False}

    p=iv.sqrt(xt*xt+yt*yt)
    tangent=[(-yt*e1[i]+xt*e2[i])/p for i in range(3)]
    # q is the direction of LOS tangential displacement *towards* nominal.
    q=[-sigma*x for x in tangent]
    sraw=[iv.mpf([str(float(si)-sun_pad_km),str(float(si)+sun_pad_km)])-ri for si,ri in zip(sun_pos_xyz,rt)]
    s_hat=[z/_norm(sraw) for z in sraw]
    t_upper=min(1.,max(-1.,float(_hi(_dot(q,s_hat)))+3e-15))
    if t_upper>=C45:
        m_upper=1.
    else:
        m_upper=C45*t_upper+math.sqrt(1-C45*C45)*math.sqrt(max(0.,1-t_upper*t_upper))
    # t_upper on [-1,c] -> cap support is monotonically increasing.
    toward_upper=dmax*max(0.,m_upper)
    p_lower=float(_lo(p))
    if p_lower<=dmax:
        tol=math.pi
    else:
        tol=nextafter(math.atan(toward_upper/(p_lower-dmax))+1e-12,inf)
    # 'Old' method gives a valid backup even if finite precision makes
    # our directional formula loose or crosses an interval ambiguity.
    tol=min(old['azimuth_tolerance_upper_rad'],tol)
    req=max(0.,nextafter(old['phase_gap_lower_rad']-tol-2e-12,-inf))
    return {**old,
        'azimuth_tolerance_upper_rad':float(tol),
        'required_phase_lower_rad':float(max(req,old['required_phase_lower_rad'])),
        'directional_azimuth_tolerance_upper_rad':float(tol),
        'signed_solar_support_tan_max_km':float(toward_upper),
        'directionally_improved':True,
        'phase_direction_sign':sigma,
        'normalizing_projected_radius_lower_km':p_lower}

class DirectionalPhaseBound(TightPhaseReachabilityBound):
    def __init__(self,observer_state,incumbent_m_s,interval_invariants=None):
        super().__init__(observer_state,incumbent_m_s)
        proof=interval_invariants or certified_enclosure(observer_state, U_m_s=str(math.ceil(incumbent_m_s*1e6)/1e6))
        stage=proof['after_at_most_two_burns']
        self.r_max=stage['radius_upper_km']
        self.v_max=stage['speed_upper_km_s']
        self.orbit_proof=proof

    def lower_at_time(self,target_interval,sun_xyz,t_s,d_max_km=50):
        g=solar_signed_azimuth_tolerance(self.observer_interval,target_interval,
                                          self.e1,self.e2,sun_xyz,t_s,d_max_km)
        req=g['required_phase_lower_rad']
        if req<=0:return {**g,'phase_delta_v_lower_bound_m_s':0.}
        if self.phase_change_upper(self.incumbent_m_s,t_s)['phase_change_upper_rad']<req:
            return {**g,'phase_delta_v_lower_bound_m_s':self.incumbent_m_s,'excluded_at_incumbent':True}
        def f(U):return self.phase_change_upper(U,t_s)['phase_change_upper_rad']-req
        root=brentq(f,0.,self.incumbent_m_s,xtol=1e-12,rtol=1e-12)
        return {**g,'phase_delta_v_lower_bound_m_s':max(0.,root*(1-2e-8)-1e-9), 'excluded_at_incumbent':False}
