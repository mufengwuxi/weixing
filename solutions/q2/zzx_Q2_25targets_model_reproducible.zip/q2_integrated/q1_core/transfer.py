"""State-continuous observation transfer primitive for the three questions.
State units: km and km/s. Times: seconds from 2027-01-01 UTC.
Burn units: m/s. The target state is at competition epoch, observer state
is supplied at current_time_s (e.g. after a previous target observation).
"""
from dataclasses import dataclass
import numpy as np
from .dynamics import propagate
from .geometry import sun_position
from .model import R_E, orbital_elements

@dataclass(frozen=True)
class TransferRequest:
    observer_state: np.ndarray
    target_epoch_state: np.ndarray
    current_time_s: float
    deadline_s: float
    budget_m_s: float
    last_burn_s: float | None = None
    target_id: str = 'b1'
    duration_s: float = 60.

@dataclass
class TransferResult:
    verified: bool
    cost_m_s: float
    observation_start_s: float
    observation_end_s: float
    burn_times_s: tuple
    burn_vectors_m_s: tuple
    terminal_observer_state: np.ndarray
    terminal_target_state: np.ndarray
    last_burn_s: float | None
    min_distance_km: float
    max_distance_km: float
    max_solar_deg: float
    max_detect_deg: float
    sample_gap_distance_km: float
    sample_gap_angle_deg: float
    target_id: str

    def to_dict(self):
        d=self.__dict__.copy()
        for k in ('terminal_observer_state','terminal_target_state'):
            d[k]=d[k].tolist()
        d['burn_times_s']=list(d['burn_times_s'])
        d['burn_vectors_m_s']=[u.tolist() for u in d['burn_vectors_m_s']]
        return d


def evaluate_transfer(req, burn_times, burn_vectors_m_s, obs_start_s, step=.02):
    """Numerical verification for 0/1/2 impulse trajectories.
    Conservative inter-sample estimate for GEO; NOT interval arithmetic.
    """
    bt=tuple(map(float,burn_times))
    bv=tuple(np.array(v,dtype=float) for v in burn_vectors_m_s)
    if len(bt)!=len(bv) or len(bt)>2: raise ValueError('0..2 burns expected')
    obs_start_s=float(obs_start_s); end=obs_start_s+req.duration_s
    if obs_start_s<req.current_time_s or end>req.deadline_s:
        raise ValueError('Observation outside task horizon')
    if any(t<req.current_time_s or t>obs_start_s for t in bt) or any(
        bt[i+1]-bt[i]<3600 for i in range(len(bt)-1)):
        raise ValueError('Burns out of order or too close')
    if bt and req.last_burn_s is not None and bt[0]-req.last_burn_s<3600:
        raise ValueError('Previous mission burn spacing violated')
    if any(np.linalg.norm(u)>30+1e-8 for u in bv):
        raise ValueError('Burn magnitude > 30 m/s')
    cost=sum(np.linalg.norm(v) for v in bv)
    if cost>req.budget_m_s+1e-8: raise ValueError('Budget exceeded')
    x=np.array(req.observer_state,dtype=float).copy()
    if x.shape!=(6,) or np.asarray(req.target_epoch_state).shape!=(6,):
        raise ValueError('Six-dimensional states required')
    anchor=req.current_time_s
    safe=orbital_elements(x)['rp_km']>=R_E
    for t,u in zip(bt,bv):
        x=propagate(x,t-anchor);x[3:]+=u/1000
        safe=safe and orbital_elements(x)['rp_km']>=R_E
        anchor=t
    x=propagate(x,obs_start_s-anchor)
    observer=propagate(x,req.duration_s,dense=True)
    target=propagate(req.target_epoch_state,end,dense=True)
    n=max(2,int(np.ceil(req.duration_s/step))+1)
    tt=np.linspace(obs_start_s,end,n)
    oo=observer(tt-obs_start_s); tg=target(tt)
    rho=(oo[:3]-tg[:3]).T
    d=np.linalg.norm(rho,axis=1)
    look=rho/d[:,None]
    er=-tg[:3].T/np.linalg.norm(tg[:3].T,axis=1)[:,None]
    ss=np.array([sun_position(t) for t in tt])-tg[:3].T
    ss/=np.linalg.norm(ss,axis=1)[:,None]
    solar=np.degrees(np.arccos(np.clip(np.sum(ss*look,axis=1),-1,1)))
    detect=np.degrees(np.arccos(np.clip(np.sum(er*look,axis=1),-1,1)))
    relvel=np.linalg.norm((oo[3:]-tg[3:]).T,axis=1)
    h=np.max(np.diff(tt))
    d_gap=1.05*relvel.max()*h/2+1e-9
    # GEO-specific upper envelope for reference-ray angular rates: 1e-4 rad/s
    a_gap=(1.05*relvel.max()/max(d.min()-d_gap,1e-8)+1e-4)*180/np.pi*h/2
    valid=bool(safe and d.min()-d_gap>=10 and d.max()+d_gap<=50
               and max(solar.max(),detect.max())+a_gap<=45)
    return TransferResult(valid,float(cost),obs_start_s,end,bt,bv,oo[:,-1],tg[:,-1],
           bt[-1] if bt else req.last_burn_s,float(d.min()),float(d.max()),
           float(solar.max()),float(detect.max()),float(d_gap),float(a_gap),req.target_id)


def request_from_scenario(scenario, current_time_s=0., observer_current=None,
                          deadline_s=172800., budget_m_s=300.,last_burn_s=None,
                          target_id='b1'):
    x=scenario.observer if observer_current is None else observer_current
    return TransferRequest(np.asarray(x).copy(),np.asarray(scenario.target).copy(),
              float(current_time_s),float(deadline_s),float(budget_m_s),last_burn_s,target_id)


def to_epoch_scenario(req):
    """Free-flight back-map to epoch for existing STM/SCP routines.
    Burn times MUST remain after current_time_s. No historical burn is undone.
    """
    from .model import Scenario
    x_epoch=propagate(req.observer_state,-req.current_time_s)
    return Scenario(x_epoch,np.asarray(req.target_epoch_state).copy(),
                    '<dynamic transfer task>',req.target_id)


def scp_refine_transfer(req,t1,t2,obs_start_s,u0,angle_margin=.009,
                        range_margin=.03,max_iter=12,step=.01):
    """Refine a feasible two-burn seed; return SCP report and validated plan."""
    from .scp import scp_fixed_times
    if t1<req.current_time_s or t2-t1<3600 or t2>obs_start_s:
        raise ValueError('Invalid maneuver times')
    if req.last_burn_s is not None and t1-req.last_burn_s<3600:
        raise ValueError('Previous mission separation violated')
    s=to_epoch_scenario(req)
    opt=scp_fixed_times(s,t1,t2,obs_start_s+30,np.asarray(u0,dtype=float),
                        angle_margin=angle_margin,range_margin=range_margin,
                        max_iter=max_iter)
    if not opt['feasible']: return opt,None
    u=opt['u']
    result=evaluate_transfer(req,(t1,t2),(u[:3],u[3:]),obs_start_s,step=step)
    return opt,result
