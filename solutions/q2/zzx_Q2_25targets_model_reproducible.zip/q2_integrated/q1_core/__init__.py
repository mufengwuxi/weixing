"""Two-impulse GEO inspection modeling and optimization. """
