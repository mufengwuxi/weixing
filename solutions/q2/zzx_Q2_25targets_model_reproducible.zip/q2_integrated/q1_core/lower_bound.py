"""First-principles, deliberately loose reachability lower-cost estimate.

Mathematical argument: if the unburned observer trajectory is r0 and a
maneuvered trajectory r, D=||r-r0||, then within D<=R we have a force
Lipschitz factor L=2*MU/(min||r0||-R)^3. For impulses of total magnitude U
(in km/s), the Volterra comparison inequality implies
  D(t) <= U*sinh(sqrt(L)*t)/sqrt(L).
If unforced target distance is always at least d0>50 km, reaching 50 km
requires D>=d0-50. Hence U >= (d0-50)*sqrt(L)/sinh(sqrt(L)*T).
The bootstrap is valid if d0-50<R and U is below that threshold.

Exact certification of d0 from sampled floating-point Kepler trajectories
would require interval enclosures. This module reports the conditional
analytical bound, NOT a formal global-optimality certificate.
"""
import numpy as np
from .model import MU,orbital_elements
from .kepler_fast import ellipse,propagate_ellipse

def conservative_reachability_bound(scenario,T=172800.,grid_s=5.,tube_km=1000.):
    times=np.arange(0.,T,grid_s)
    times=np.r_[times,T] if times[-1]!=T else times
    r1,v1=propagate_ellipse(ellipse(scenario.observer),times)
    r2,v2=propagate_ellipse(ellipse(scenario.target),times)
    d=np.linalg.norm(r1-r2,axis=1)
    o=orbital_elements(scenario.observer);t=orbital_elements(scenario.target)
    vmax=lambda e: np.sqrt(MU*(2/e['rp_km']-1/e['a_km']))
    speed_cap=vmax(o)+vmax(t)
    # Analytical speed bound between sampling times. Do not use computed
    # relative speed at nodes as a global bound.
    sampled_earth_distance_lower=max(0.,d.min()-speed_cap*grid_s/2.)
    nominal_rmin=o['rp_km']
    if tube_km>=nominal_rmin or sampled_earth_distance_lower<=50 or \
       sampled_earth_distance_lower-50>=tube_km:
        raise ValueError('No useful bound with this tube size')
    L=2*MU/(nominal_rmin-tube_km)**3
    rate=np.sqrt(L)
    shift=sampled_earth_distance_lower-50
    lower_m_s=1000*shift*rate/np.sinh(rate*T)
    return {'distance_sample_min_km':float(d.min()),
        'absolute_speed_bound_km_s':float(speed_cap),
        'sample_grid_spacing_s':float(grid_s),
        'estimated_free_distance_lower_km':float(sampled_earth_distance_lower),
        'tube_radius_km':float(tube_km),
        'gravity_lipschitz_s_minus2':float(L),
        'conditional_analytic_burn_lower_m_s':float(lower_m_s),
        'certified_by_interval_arithmetic':False,
        'warning':'Very weak analytical comparison bound; floating-point Kepler sample minima not interval enclosed; cannot prove global optimality.'}
