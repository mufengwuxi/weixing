"""Physical model and unambiguous input data; all positions km, velocities km/s."""
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from openpyxl import load_workbook

MU = 398600.4418
R_E = 6378.137
T_END = 172800.0
EPOCH = '2027-01-01T00:00:00Z'

@dataclass(frozen=True)
class Scenario:
    observer: np.ndarray
    target: np.ndarray
    excel_path: str
    scenario_id: str = 'r1_xy_vy_vz_sign_flip'

def load_scenario(path):
    path=Path(path)
    wb=load_workbook(path, read_only=True, data_only=True)
    sheet=wb['Sheet1']
    assert sheet.cell(4,1).value=='r1' and sheet.cell(6,1).value=='b1', 'Excel row mismatch'
    r=np.array([sheet.cell(4,j).value for j in range(2,8)], dtype=float)
    b=np.array([sheet.cell(6,j).value for j in range(2,8)], dtype=float)
    assert np.all(np.isfinite(r)) and np.all(np.isfinite(b))
    r[[0,1,4,5]] *= -1  # User-requested sensitivity scenario; do not edit Excel.
    assert abs(r[0]+32195.7228)<1e-7
    assert abs(r[4]+2.35516411)<1e-7
    return Scenario(r,b,str(path))

def orbital_elements(x):
    r=x[:3]; v=x[3:]
    h=np.cross(r,v); en=.5*np.dot(v,v)-MU/np.linalg.norm(r)
    a=-MU/(2*en)
    evec=np.cross(v,h)/MU-r/np.linalg.norm(r)
    e=np.linalg.norm(evec)
    return {'a_km':float(a),'e':float(e),'i_deg':float(np.degrees(np.arccos(np.clip(h[2]/np.linalg.norm(h),-1,1)))),
            'rp_km':float(a*(1-e)), 'ra_km':float(a*(1+e))}
