"""Physics-guided time-grid screening, NOT a rigorous nonlinear lower bound.

For unforced reference orbit compute position STM H_k = C Phi(t,t_k) B
in km per m/s. The linearized distance-only lower cost estimate is
   J_lin >= max(0, ||r_free(t)-r_target(t)||-50) / max(||H1||_2,||H2||_2)
This is valid for that first-order approximation only; it must never be used
as a certified lower bound for the original nonlinear optimization.
"""
import numpy as np
from .dynamics import propagate, propagate_with_stm
from .geometry import angular_windows


def screen_maneuver_times(scenario, center_step_s=900.,burn_step_s=3600.,top_per_center=2):
    windows=angular_windows(scenario)
    t_end=172800.0
    obs_y,obs_phi,obs_dense=propagate_with_stm(scenario.observer,t_end,dt_samples=True)
    tar=propagate(scenario.target,t_end,dense=True)
    B=np.vstack([np.zeros((3,3)),np.eye(3)])*.001
    scores=[]; centers_scanned=0; combos=0
    for a,b in windows:
        centers=np.arange(a+30.,b-30.+1e-7,center_step_s)
        for center in centers:
            if center>t_end-30.:continue
            centers_scanned+=1
            st=obs_dense(center); g0=st[6:].reshape(6,6)
            rfree=st[:3]; rtarget=tar(center)[:3]
            gap=max(0.,np.linalg.norm(rfree-rtarget)-50.)
            endtime=center-30.
            times=np.arange(0.,endtime,burn_step_s)
            # Compute the Jacobian from each burn to the same observation time.
            Hs=[]
            for ti in times:
                if abs(ti)<1e-9:Phi_i=np.eye(6)
                else:Phi_i=obs_dense(ti)[6:].reshape(6,6)
                Hi=(g0@np.linalg.solve(Phi_i,B))[:3,:]
                Hs.append(float(np.linalg.norm(Hi,2)))
            local=[]
            for i,t1 in enumerate(times):
                for j in range(i+1,len(times)):
                    t2=times[j]
                    if t2-t1<3600:continue
                    lin_lower=gap/max(Hs[i],Hs[j],1e-12)
                    local.append((lin_lower,t1,t2))
                    combos+=1
            local.sort(key=lambda x:x[0])
            for score,t1,t2 in local[:top_per_center]:
                scores.append({'t1_s':float(t1),'t2_s':float(t2),
                     'obs_center_s':float(center),
                     'linearized_distance_only_lower_m_s':float(score),
                     'natural_miss_distance_km':float(gap+50.)})
    scores.sort(key=lambda x:x['linearized_distance_only_lower_m_s'])
    return {'type':'heuristic unforced-reference STM screening; NOT a nonlinear global certificate',
            'windows_s':windows,'centers_scanned':centers_scanned,
            'time_pairs_screened':combos,'top_candidates':scores}
