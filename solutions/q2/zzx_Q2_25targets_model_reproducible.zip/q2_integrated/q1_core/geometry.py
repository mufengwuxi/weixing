"""Directional (not unsigned-line) illumination and Earth-target viewing angle."""
import numpy as np
import swisseph as swe
from .dynamics import propagate

JD_UTC=swe.julday(2027,1,1,0)
FLAGS=swe.FLG_MOSEPH|swe.FLG_J2000|swe.FLG_NONUT|swe.FLG_EQUATORIAL|swe.FLG_XYZ|swe.FLG_TRUEPOS
AU=149597870.7
C45=np.cos(np.pi/4)

def sun_position(t):
    """Geocentric geometric Sun J2000-equatorial (km), Swiss Ephemeris Moshier model."""
    return np.array(swe.calc_ut(JD_UTC+float(t)/86400.,swe.SUN,FLAGS)[0][:3])*AU

def directions(target_positions, times):
    target_positions=np.atleast_2d(target_positions)
    times=np.atleast_1d(times)
    ss=np.array([sun_position(t) for t in times])-target_positions
    ss/=np.linalg.norm(ss,axis=1,keepdims=True)
    ee=-target_positions/np.linalg.norm(target_positions,axis=1,keepdims=True)
    return ss,ee

def metrics(r_ob,r_target,solar,earth):
    dr=r_ob-r_target
    dist=np.linalg.norm(dr,axis=-1)
    line=dr/dist[...,None]
    return np.stack([dist, np.degrees(np.arccos(np.clip(np.sum(solar*line,axis=-1),-1,1))),
                    np.degrees(np.arccos(np.clip(np.sum(earth*line,axis=-1),-1,1)))],axis=-1)

def target_at(scenario,times):
    times=np.atleast_1d(times)
    sol=propagate(scenario.target,max(times),dense=True)
    return sol(times)[:3].T

def angular_windows(scenario,spacing=240.,t_start=0.,t_end=172800.):
    """Necessary geometric condition: angle(Sun,Earth directions)<=90 degrees.
    Zero crossings bracketed via Brent root refinement; returns windows of possible look directions.
    """
    from scipy.optimize import brentq
    t_start=float(t_start);t_end=float(t_end)
    if not (0<=t_start<t_end and spacing>0): raise ValueError("Invalid time range")
    tar=propagate(scenario.target,t_end,dense=True)
    def f(t):
        tt=tar(t)[:3]
        ss=sun_position(t)-tt
        return np.dot(ss,-tt)/(np.linalg.norm(ss)*np.linalg.norm(tt))
    ts=np.arange(t_start,t_end,spacing)
    ts=np.r_[ts,t_end] if ts[-1]!=t_end else ts
    fvals=np.array([f(t) for t in ts])
    roots=[]
    for i in range(len(ts)-1):
        if fvals[i]*fvals[i+1]<0:
            roots.append(float(brentq(f,ts[i],ts[i+1],xtol=1e-8)))
    edges=[t_start]+roots+[t_end]
    windows=[(a,b) for a,b in zip(edges[:-1],edges[1:]) if f(.5*(a+b))>=0]
    return windows
