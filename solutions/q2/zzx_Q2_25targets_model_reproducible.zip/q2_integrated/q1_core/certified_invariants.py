"""Rigorous-by-construction two-impulse Kepler invariant enclosure.

All numerical inputs are interpreted as exact decimal numbers (not measured
uncertainties). High precision mpmath interval operations outward-enclose
operations and convert endpoint values to safe floats via nextafter.

For 0 <= u1+u2 <= U, the first burn is applied on the initial Kepler orbit.
For the second burn the preburn orbit belongs to stage-1 enclosure. By an
inductive argument, every intermediate and final orbit belongs to stage-2
bounds even if maneuver times/directions are unrestricted. In particular,
Earth clearance is a *consequence*, not a prerequisite, for the candidate U.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from math import nextafter, inf
from typing import Sequence
from mpmath import iv, mp

iv.dps = 75
mp.dps = 75


def I(x):
    return iv.mpf(str(x))

def lo(x):
    return mp.mpf(x.a)

def hi(x):
    return mp.mpf(x.b)

def high_float(x):
    return nextafter(float(hi(x)), inf)

def low_float(x):
    return nextafter(float(lo(x)), -inf)

def dot(a,b):
    return sum((x*y for x,y in zip(a,b)), iv.mpf('0'))

def cross(a,b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]

def norm(a):
    return iv.sqrt(dot(a,a))

@dataclass
class Stage:
    energy_lower_km2_s2: float
    energy_upper_km2_s2: float
    semimajor_axis_lower_km: float
    semimajor_axis_upper_km: float
    eccentricity_upper: float
    radius_lower_km: float
    radius_upper_km: float
    speed_upper_km_s: float
    angular_momentum_lower_km2_s: float


def certified_enclosure(initial_state: Sequence[float], U_m_s: str = '5.213',
                        mu: str = '398600.4418', earth_radius: str = '6378.137') -> dict:
    st = [I(x) for x in initial_state]
    r,v = st[:3], st[3:]
    M, U = I(mu), I(U_m_s)/1000
    rad = norm(r)
    eps0 = dot(v,v)/2 - M/rad
    a0 = -M/(2*eps0)
    hvec = cross(r,v)
    h0=norm(hvec)
    ev0=[x/M-y/rad for x,y in zip(cross(v,hvec),r)]
    e0=norm(ev0)
    if hi(eps0) >= 0 or hi(e0) >= 1:
        raise ValueError('This envelope requires a bound initial elliptical Kepler orbit')

    a0_lo,a0_hi=lo(a0),hi(a0)
    e0_hi=hi(e0)
    r_lo0=lo(a0*(1-e0))
    r_hi0=hi(a0*(1+e0))
    v_hi0=hi(iv.sqrt(2*(eps0+M/I(r_lo0))))
    h_lo0=lo(h0)

    def wrap(Emin,Emax,emax,rmin,rmax,vmax,hmin):
        return Stage(
            low_float(I(Emin)),high_float(I(Emax)),
            low_float(-M/(2*I(Emin))),high_float(-M/(2*I(Emax))),
            high_float(I(emax)),low_float(I(rmin)),high_float(I(rmax)),
            high_float(I(vmax)),low_float(I(hmin)))

    stage0=wrap(lo(eps0),hi(eps0),e0_hi,r_lo0,r_hi0,v_hi0,h_lo0)

    def next_stage(R,V,E0lo,E0hi,e0upper,h0lower):
        # Use bounds for *all* impulses in total budget U, not full U per burn.
        # This stage encloses any orbit after 0..2 burns if preburn states obey
        # r<=R, |v|<=V throughout earlier arcs.  E and e variation are
        # summed across burns using Σu_k<=U, Σu_k² <= U².
        Emin=I(E0lo)-I(V)*U
        Emax=I(E0hi)+I(V)*U+U*U/2
        em=I(e0upper)+(2*I(R)*I(V)*U+I(R)*U*U)/M
        h_min=I(h0lower)-I(R)*U
        if hi(Emax)>=0 or hi(em)>=1 or lo(h_min)<=0:
            raise ValueError('Unable to certify bounded elliptic orbits')
        a_low=lo(-M/(2*Emin))
        a_high=hi(-M/(2*Emax))
        rmin=lo(I(a_low)*(1-em))
        rmax=hi(I(a_high)*(1+em))
        vmax=hi(iv.sqrt(2*(Emax+M/I(rmin))))
        return wrap(lo(Emin),hi(Emax),hi(em),rmin,rmax,vmax,lo(h_min))

    # Stage 1 includes initial and after first impulse. Since the initial
    # orbit is known, an initial burn state is in (R0,V0) at any first time.
    stage1=next_stage(r_hi0,v_hi0,lo(eps0),hi(eps0),e0_hi,h_lo0)
    # Stage 2 needs R,V valid at *both* burn sites: first on stage0, second
    # on stage1. The same total budget U is used in the envelope, not 2U.
    Rstar=max(stage0.radius_upper_km,stage1.radius_upper_km)
    Vstar=max(stage0.speed_upper_km_s,stage1.speed_upper_km_s)
    stage2=next_stage(Rstar,Vstar,lo(eps0),hi(eps0),e0_hi,h_lo0)
    if stage2.radius_lower_km < float(earth_radius):
        raise ValueError('Earth-clearance cannot be established from this U')
    return {
        'method':'inductive_exact_two_body_invariants_with_interval_arithmetic',
        'units':{'U':'m/s','state_position':'km','state_velocity':'km/s'},
        'budget_U_m_s':float(U_m_s),
        'mu_km3_s2':str(mu),
        'initial':asdict(stage0),'after_first_burn':asdict(stage1),
        'after_at_most_two_burns':asdict(stage2),
        'minimum_geocentric_radius_for_any_considered_trajectory_km':stage2.radius_lower_km,
        'earth_radius_km':float(earth_radius),
        'earth_clearance_proven_within_model':True,
        'assumptions':'exact input decimals; Earth point-mass; at most two instantaneous impulses with sum of norms <= U; no other forces',
        'time_scope':'any nonnegative time while coasting on these bound elliptical orbits; no time-grid dependence',
        'proof_sketch':[
            'Initial Kepler orbit has exact invariant specific energy eps0 and eccentricity vector e0.',
            'At a burn at radius r and speed v, |Delta eps| <= |v| u + u^2/2, |Delta e_vec| <= (2 r |v| u+r u^2)/mu, |Delta h| <= r u.',
            'Bounded eps and e imply a=-mu/(2 eps), radius a(1-e)<=r<=a(1+e), and vis-viva speed bound.',
            'Stage 1 uses the exact initial orbit for the first burn, valid regardless of first burn epoch.',
            'At both burns the pre-burn R,V are <= maxima of initial and stage-1 bounds; sum of burn magnitudes <= U and sum of squares <= U^2.',
            'Stage 2 therefore encloses all coast arcs after zero, one or two burns. Its lower radius proves Earth clearance.'
        ],
        'formal_complete_global_optimum_certified':False
    }
