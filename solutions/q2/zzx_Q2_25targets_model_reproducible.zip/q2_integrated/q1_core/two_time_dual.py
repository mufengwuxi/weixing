"""Two-time support-function dual for the *linearized* Kepler reference model.

WARNING: Neither the numerical reference STM nor its linearization certify an
exact nonlinear Kepler delta-V bound. The explicit nonlinear remainder must be
outward enclosed before any proxy is promoted to a global certificate.

For observation-center time box [a,b] with width w<=60, each possible 60-s
window [c-30,c+30], c in [a,b], contains the *common interval*
[b-30,a+30]. We impose simultaneous observation geometries at its two
endpoints, giving a valid necessary pair for all c in the center-time box.
The underlying LTV proxy neglects nonlinear remainder R(t), so it remains
only a diagnostic for the actual two-body problem.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from .dual_reachability import DualStudy, B, D, C45
from .geometry import sun_position
from .kepler_fast import propagate_ellipse


def cap_intersection_dot_min(lambda_vec, solar, earth, c=C45):
    """Exact min lambda dot u over |u|=1 and s·u>=c, e·u>=c.

    Enumerate the sphere interior, a one-cap boundary stationary point,
    and the intersection of both cone boundaries. Return None if empty.
    """
    lam=np.asarray(lambda_vec, float)
    if np.linalg.norm(lam)<1e-15: return 0.
    a=np.asarray(solar,float);b=np.asarray(earth,float)
    a=a/np.linalg.norm(a);b=b/np.linalg.norm(b)
    z=float(a@b)
    if z<2*c*c-1-1e-12:return None
    if z>1-1e-12:
        aa=float(lam@a)
        if aa<=-c:return float(-np.linalg.norm(lam))
        return float(c*aa-np.sqrt(max(0.,1-c*c))*np.sqrt(max(0.,lam@lam-aa*aa)))
    cand=[]
    v=-lam/np.linalg.norm(lam)
    if v@a>=c-1e-12 and v@b>=c-1e-12:cand.append(float(lam@v))
    for axis,other in ((a,b),(b,a)):
        vperp=lam-(lam@axis)*axis
        nv=np.linalg.norm(vperp)
        if nv>1e-14:
            u=c*axis-np.sqrt(1-c*c)*vperp/nv
            if u@other>=c-2e-12:cand.append(float(lam@u))
    # Both constraints active: u = c(a+b)/(1+a·b) ± zeta*(a×b)/|a×b|.
    um=c*(a+b)/(1+z)
    nd=np.cross(a,b);nd=nd/np.linalg.norm(nd)
    rad=np.sqrt(max(0.,1-um@um))
    cand.extend([float(lam@(um+rad*nd)),float(lam@(um-rad*nd))])
    if not cand:raise RuntimeError('Two-cap feasible set unexpectedly empty')
    return float(min(cand))


def exact_shell_cone_support(lambda_vec,solar,earth,rmin=10.,rmax=50.):
    m=cap_intersection_dot_min(lambda_vec,solar,earth)
    if m is None:return None
    return (rmax if m<0 else rmin)*m

class TwoTimeLTV(DualStudy):
    def __init__(self,scenario,tlimit=172800.,grid_dt=60.):
        super().__init__(scenario,tlimit=tlimit,grid_dt=grid_dt)

    def pair_data(self,tminus,tplus):
        out=[]
        for t in [tminus,tplus]:
            x=self.sol(t)
            r0=x[:3]
            rt=propagate_ellipse(self.el_target,t)[0]
            sun=sun_position(t)-rt;sun=sun/np.linalg.norm(sun)
            earth=-rt/np.linalg.norm(rt)
            out.append((rt-r0,sun,earth))
        return out

    def pair_operators(self,tminus,tplus,impulse_grid_spacing_s=600.):
        taus=np.r_[np.arange(0,tminus,impulse_grid_spacing_s),tminus]
        ys=self.sol(taus)
        invs=np.linalg.inv(ys[6:].T.reshape(-1,6,6))
        pminus=self.sol(tminus)[6:].reshape(6,6)
        pplus=self.sol(tplus)[6:].reshape(6,6)
        return (np.einsum('ij,njk->nik',pminus[:3,:],invs@B),
                np.einsum('ij,njk->nik',pplus[:3,:],invs@B))

    def ratio(self,mu,tminus,tplus,operators=None,pairdata=None):
        lam=mu.reshape(2,3)
        if np.linalg.norm(mu)<1e-13:return -np.inf
        if pairdata is None:pairdata=self.pair_data(tminus,tplus)
        num=0.
        for i,(delta,s,e) in enumerate(pairdata):
            a=exact_shell_cone_support(lam[i],s,e)
            if a is None:return -np.inf
            num += float(lam[i]@delta+a)
        if operators is None:operators=self.pair_operators(tminus,tplus)
        h1,h2=operators
        den=np.max(np.linalg.norm(np.einsum('nij,i->nj',h1,lam[0])+np.einsum('nij,i->nj',h2,lam[1]),axis=1))
        if den<=0:return -np.inf
        return float(num*1000/den)

    def continuum_denominator(self,tminus,tplus,lambdas):
        """Analytical continuous burn-time majorant given exact STM centers.

        Node integrator itself is unvalidated floating-point; this only
        removes the burn-time discretization assumption in the LTV model.
        """
        dt=float(self.grid_dt)
        n=int(np.floor(tminus/dt))
        mid=self.cell_starts[:n]+dt/2
        inv=self.phi_inv[:n]
        radii=np.full(n,dt/2)
        rem=tminus-n*dt
        if rem>1e-10:
            tm=n*dt+rem/2
            yy=self.sol(tm)
            invlast=np.linalg.inv(yy[6:].reshape(6,6))
            mid=np.r_[mid,tm];inv=np.concatenate([inv,invlast[None,:,:]])
            radii=np.r_[radii,rem/2]
        p1=self.sol(tminus)[6:].reshape(6,6)
        p2=self.sol(tplus)[6:].reshape(6,6)
        comb=lambdas[0]@p1[:3,:] + lambdas[1]@p2[:3,:]
        HG=comb@inv
        hh=np.linalg.norm(HG@B,axis=1)
        gg=np.linalg.norm(HG@D,axis=1)
        k=self.k
        den=np.max(hh*np.cosh(k*radii)+gg*np.sinh(k*radii)/k)
        return float(den*(1+1e-8))

    def evaluate_time_box(self,center_box_start_s,center_box_end_s,starts=3,
                          coarse_s=600.):
        a,b=float(center_box_start_s),float(center_box_end_s)
        if not 0<=a<=b<=172800 or b-a>60+1e-9:
            raise ValueError('Time-box width must be <=60s')
        tm=b-30;tplus=a+30
        if tm<=0 or tplus<tm:raise ValueError('Invalid common interval')
        data=self.pair_data(tm,tplus)
        if any(exact_shell_cone_support(np.array([1.,0,0]),s,e) is None for _,s,e in data):
            return {'status':'geometric_cones_disjoint', 'box_start_s':a,'box_end_s':b}
        ops=self.pair_operators(tm,tplus,coarse_s)
        firstdelta=data[0][0];second=data[1][0]
        simple=(firstdelta/np.linalg.norm(firstdelta)+second/np.linalg.norm(second))/2
        seed=[np.r_[simple,simple],np.r_[simple,0*simple],np.r_[0*simple,simple]]
        rng=np.random.default_rng(round((a+b)*8))
        while len(seed)<starts:seed.append(np.r_[simple,simple]+rng.normal(0,.25,size=6))
        best=(-1e9,None)
        for x0 in seed:
            res=minimize(lambda x: -self.ratio(x,tm,tplus,ops,data),x0,method='Nelder-Mead',
                         options={'maxiter':180,'xatol':1e-5,'fatol':1e-6})
            value=self.ratio(res.x,tm,tplus,ops,data)
            if value>best[0]:best=(value,res.x)
        ls=best[1].reshape(2,3)
        ls/=max(1e-16,np.linalg.norm(ls))
        num=sum(ls[i]@d+exact_shell_cone_support(ls[i],s,e)
                for i,(d,s,e) in enumerate(data))
        denom=self.continuum_denominator(tm,tplus,ls)
        proxy=max(0.,1000*num/denom)
        return {
            'status':'linearized_two_time_proxy_not_nonlinear_certificate',
            'box_start_s':a,'box_end_s':b,
            'common_time1_s':tm,'common_time2_s':tplus,
            'separation_of_common_times_s':tplus-tm,
            'two_time_linear_proxy_m_s':float(proxy),
            'sampled_value_m_s':float(best[0]),
            'numerator_km':float(num),'linear_denominator_km_per_m_s':float(denom/1000),
            'lambda_minus':ls[0].tolist(),'lambda_plus':ls[1].tolist(),
            'needed_proven_nonlinear_remainder_km_for_exact_lower_5m_s':float(num-5*denom/1000),
            'nonlinear_remainder_certified':False,
            'actual_global_lower_bound_m_s':None,
            'caution':'nonlinear and STM integration errors not validated; proxy NOT a bound on exact problem'}
