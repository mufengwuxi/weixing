"""Accurate two-body propagation and 6x6 variational state transition matrix."""
import numpy as np
from scipy.integrate import solve_ivp
from .model import MU

ATOL=3e-12
RTOL=3e-12

def rhs(_,x):
    r=x[:3]
    return np.r_[x[3:],-MU*r/np.linalg.norm(r)**3]

def propagate(x,dt, dense=False):
    if abs(dt)<1e-13:
        return np.array(x,copy=True)
    sol=solve_ivp(rhs,(0,float(dt)),np.asarray(x,dtype=float),method='DOP853',rtol=RTOL,atol=ATOL,dense_output=dense)
    if not sol.success: raise RuntimeError(sol.message)
    return sol.sol if dense else sol.y[:,-1]

def jacobian(x):
    r=x[:3]; rn=np.linalg.norm(r)
    A=np.zeros((6,6))
    A[:3,3:]=np.eye(3)
    A[3:,:3]=-MU*(np.eye(3)/rn**3-3*np.outer(r,r)/rn**5)
    return A

def rhs_aug(t,y):
    x=y[:6]
    phi=y[6:].reshape(6,6)
    return np.r_[rhs(t,x), (jacobian(x)@phi).ravel()]

def propagate_with_stm(x,duration,dt_samples=None):
    """Return end state, end Phi; if dt_samples supplied, also dense output (both x and Phi)."""
    y0=np.r_[np.asarray(x,dtype=float),np.eye(6).ravel()]
    sol=solve_ivp(rhs_aug,(0,float(duration)),y0,method='DOP853',rtol=RTOL,atol=ATOL,dense_output=(dt_samples is not None))
    if not sol.success: raise RuntimeError(sol.message)
    y=sol.y[:,-1]
    return (y[:6],y[6:].reshape(6,6),sol.sol) if dt_samples is not None else (y[:6],y[6:].reshape(6,6))

def propagate_burns(scenario,t1,t2,center,dv_ms):
    """Compute states at each burn and solve observer in observation window."""
    s=center-30
    assert 0<=t1 and t2-t1>=3600-1e-6 and t2<=s and s+60<=172800
    u=np.asarray(dv_ms,dtype=float).reshape(2,3)*.001
    x1=propagate(scenario.observer,t1)
    x1_after=x1.copy(); x1_after[3:]+=u[0]
    x2=propagate(x1_after,t2-t1)
    x2_after=x2.copy();x2_after[3:]+=u[1]
    xstart=propagate(x2_after,s-t2)
    return x1_after,x2_after,xstart

def observation_state_linearization(scenario,t1,t2,center,dv_ms,offsets):
    """Return observer states, position Jacobians d(pos_km)/d(burn_m_s) at nodes."""
    s=center-30
    x1=propagate(scenario.observer,t1)
    x1[3:]+=np.asarray(dv_ms[:3])*.001
    x2,phi12=propagate_with_stm(x1,t2-t1)
    x2[3:]+=np.asarray(dv_ms[3:])*.001
    stop=s+max(offsets)
    end,phi_end,dense=propagate_with_stm(x2,stop-t2,dt_samples=True)
    times=s+np.asarray(offsets,dtype=float)
    ys=dense(times-t2)
    B=np.vstack([np.zeros((3,3)), np.eye(3)])
    D=np.column_stack([phi12@B,B])*.001
    obs=ys[:6,:].T
    H=np.stack([ys[6:,i].reshape(6,6)[:3,:]@D for i in range(len(times))],axis=0)
    return obs,H
