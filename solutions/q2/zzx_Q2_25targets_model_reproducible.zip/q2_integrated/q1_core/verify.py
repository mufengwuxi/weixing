"""Independent DOP853 end-to-end numerical verification incl. Lipschitz inter-sample bound.
No formal interval integration certificate is claimed.
"""
import numpy as np
from datetime import datetime,timedelta,timezone
from .dynamics import propagate,propagate_burns
from .geometry import sun_position
from .model import MU,R_E,orbital_elements

EPOCH=datetime(2027,1,1,tzinfo=timezone.utc)

def utc(seconds):return (EPOCH+timedelta(seconds=float(seconds))).isoformat(timespec='milliseconds')

def verify(scenario,t1,t2,center,u_ms,step=.02,save_trace=None):
    start=center-30;end=center+30
    x1,x2,xs=propagate_burns(scenario,t1,t2,center,u_ms)
    obs=propagate(xs,60,dense=True)
    target=propagate(scenario.target,end,dense=True)
    times=start+np.linspace(0,60,max(2,int(np.ceil(60/step))+1))
    ro=obs(times-start)
    rt=target(times)
    rel=ro[:3].T-rt[:3].T
    dd=np.linalg.norm(rel,axis=1)
    lines=rel/dd[:,None]
    ee=-rt[:3].T/np.linalg.norm(rt[:3].T,axis=1)[:,None]
    ss=np.array([sun_position(t) for t in times])-rt[:3].T
    ss=ss/np.linalg.norm(ss,axis=1)[:,None]
    solar=np.degrees(np.arccos(np.clip(np.sum(ss*lines,axis=1),-1,1)))
    detect=np.degrees(np.arccos(np.clip(np.sum(ee*lines,axis=1),-1,1)))
    vrel=np.linalg.norm((ro[3:]-rt[3:]).T,axis=1)
    maxspeed=max(vrel)*1.05+1e-9
    # The angular derivative of normalized relative position bounded by ||vrel||/||rrel||;
    # Earth and Sun reference angular rate upper bounded by 1e-4 rad/s in GEO scenario.
    # Sampling bound does NOT include integration or ephemeris model error.
    spacing=np.max(np.diff(times))
    epsd=maxspeed*spacing/2
    lower_d=dd.min()-epsd
    epsa=(maxspeed/lower_d+1e-4)*180/np.pi*spacing/2 if lower_d>0 else np.inf
    ok=bool(dd.min()-epsd>=10 and dd.max()+epsd<=50 and
            max(solar.max(),detect.max())+epsa<=45 and t2-t1>=3600 and end<=172800
            and np.linalg.norm(u_ms[:3])<=30 and np.linalg.norm(u_ms[3:])<=30
            and x1 is not None and x2 is not None and
            orbital_elements(x1)['rp_km']>R_E and orbital_elements(x2)['rp_km']>R_E)
    result={'feasible_with_sampling_bounds':ok,'J_m_s':float(np.linalg.norm(u_ms[:3])+np.linalg.norm(u_ms[3:])),
            't1_s':float(t1),'t2_s':float(t2),'obs_start_s':float(start),'obs_end_s':float(end),
            'burn1_utc':utc(t1),'burn2_utc':utc(t2),'obs_start_utc':utc(start),'obs_end_utc':utc(end),
            'dv1_m_s':list(map(float,u_ms[:3])),'dv2_m_s':list(map(float,u_ms[3:])),
            'burn1_magnitude':float(np.linalg.norm(u_ms[:3])), 'burn2_magnitude':float(np.linalg.norm(u_ms[3:])),
            'burn_separation_s':float(t2-t1),'postburn_coast_s':float(start-t2),
            'distance_min_km':float(dd.min()),'distance_max_km':float(dd.max()),
            'solar_max_deg':float(solar.max()),'detection_max_deg':float(detect.max()),
            'max_relative_speed_km_s':float(max(vrel)),
            'sampling_dt_s':float(spacing),'distance_between_sample_bound_km':float(epsd),
            'angle_between_sample_bound_deg':float(epsa),
            'burn1_orbit':orbital_elements(x1),'burn2_orbit':orbital_elements(x2),
            'formal_interval_certified':False}
    if save_trace is not None:
        import csv
        with open(save_trace,'w',newline='') as f:
            writer=csv.writer(f);writer.writerow(['elapsed_seconds','distance_km','solar_angle_deg','detection_angle_deg'])
            writer.writerows(zip(times-start,dd,solar,detect))
    return result
