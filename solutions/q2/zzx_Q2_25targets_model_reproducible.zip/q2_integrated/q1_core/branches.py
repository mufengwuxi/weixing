"""0/1 impulse comparison branch. A one-burn run is heuristic, not global."""
import numpy as np
from scipy.optimize import minimize
from .dynamics import propagate
from .geometry import directions,metrics
from .transfer import evaluate_transfer
from .baselines import no_burn_min_distance

NODES=np.linspace(0.,60.,13)

def zero_burn_test(scenario):
    result=no_burn_min_distance(scenario)
    return {'branch':'zero_burn','min_distance_km':result['closest_distance_km'],
            'min_time_s':result['closest_time_s'],
            'excluded_by_distance':bool(result['closest_distance_km']>50),
            'method':'dense scan + bounded minimum search; numerical, not formal interval proof'}

def one_burn_metrics(scenario,z):
    """z=[burn hour, observation center hour, dvx, dvy, dvz] (dv m/s)."""
    tb,tc=z[:2]*3600
    start=tc-30
    if tb<0 or start<tb: raise ValueError('Invalid times')
    x=propagate(scenario.observer,tb)
    x[3:]+=np.asarray(z[2:])*1e-3
    ob=propagate(x,start+60-tb,dense=True)
    tg=propagate(scenario.target,start+60,dense=True)
    tt=start+NODES
    oo=ob(tt-tb)[:3].T; target=tg(tt)[:3].T
    solar,earth=directions(target,tt)
    return metrics(oo,target,solar,earth)

def refine_one_burn(scenario, req, initial,margin_deg=.015,margin_km=.06,max_iter=150):
    """Local 5D minimum-fuel search; independently verify output.

    Returns optimization metadata and TransferResult (may be unverified).
    """
    z0=np.asarray(initial,dtype=float)
    angle=np.cos(np.deg2rad(45-margin_deg))
    def con(z):
        try:
            tb,tc=z[:2]
            m=one_burn_metrics(scenario,z)
            d=m[:,0]
            cos_a=np.cos(np.deg2rad(m[:,1]));cos_t=np.cos(np.deg2rad(m[:,2]))
            return np.r_[d-10-margin_km,50-margin_km-d,
                40*(cos_a-angle),40*(cos_t-angle),tc-tb-.02,30-np.linalg.norm(z[2:])]
        except (ValueError,RuntimeError,FloatingPointError):
            return np.full(4*len(NODES)+2,-1e4)
    fit=minimize(lambda z:np.linalg.norm(z[2:]),z0,method='SLSQP',
         bounds=[(0,47.8),(0.02,47.99)]+[(-30,30)]*3,
         constraints=[{'type':'ineq','fun':con}],
         options={'maxiter':max_iter,'ftol':1e-9,'disp':False})
    plan=None
    if np.isfinite(fit.x).all() and min(con(fit.x))>=-1e-6:
        try:
            plan=evaluate_transfer(req,[fit.x[0]*3600],[fit.x[2:]],
                                   fit.x[1]*3600-30,step=.01)
        except ValueError: pass
    return {'success':bool(fit.success),'message':str(fit.message),
            'sample_min_slack':float(min(con(fit.x))),
            'time_burn_h':float(fit.x[0]),'time_center_h':float(fit.x[1]),
            'dv_m_s':fit.x[2:].tolist(),
            'J_m_s':float(np.linalg.norm(fit.x[2:])),
            'verified':bool(plan.verified) if plan else False}, plan
