"""Constrained 9-variable nonlinear local search with Kepler candidate propagation.
The method only tests local basins, not a global optimality certificate.
"""
import warnings
import numpy as np
from scipy.optimize import minimize
from .kepler_fast import ellipse,propagate_ellipse
from .geometry import sun_position
from .transfer import evaluate_transfer,request_from_scenario

OFFSETS=np.linspace(0.,60.,13)

def sampled_constraints(scenario,z,margin_angle=.009,margin_range=.03):
    """Time variables z[:3] are hours; burn components z[3:] in m/s."""
    t1,t2,tc=np.asarray(z[:3])*3600.
    if t1<0 or t2<t1+3600-1 or tc-30<t2-1:
        return np.full(4*len(OFFSETS)+4,-1e5)
    u1=np.asarray(z[3:6])*.001;u2=np.asarray(z[6:9])*.001
    try:
        x1=propagate_ellipse(ellipse(scenario.observer),t1)
        x2=propagate_ellipse(ellipse(np.r_[x1[0],x1[1]+u1]),t2-t1)
        t=tc-30+OFFSETS
        o=propagate_ellipse(ellipse(np.r_[x2[0],x2[1]+u2]),t-t2)[0]
        tar=propagate_ellipse(ellipse(scenario.target),t)[0]
        dr=o-tar;d=np.linalg.norm(dr,axis=1);look=dr/d[:,None]
        sun=np.array([sun_position(ti) for ti in t])-tar
        sun/=np.linalg.norm(sun,axis=1)[:,None]
        earth=-tar/np.linalg.norm(tar,axis=1)[:,None]
        c=np.cos(np.deg2rad(45-margin_angle))
        return np.r_[d-10-margin_range,50-margin_range-d,
                     40*(np.sum(sun*look,axis=1)-c),
                     40*(np.sum(earth*look,axis=1)-c),
                     z[1]-z[0]-1., z[2]-z[1]-30/3600.,
                     30-np.linalg.norm(z[3:6]),30-np.linalg.norm(z[6:9])]
    except (ValueError,RuntimeError,FloatingPointError):
        return np.full(4*len(OFFSETS)+4,-1e5)

def nonlinear_joint_search(scenario,reference,n_seeds=8,seed=2027,
                           margin_angle=.009,margin_range=.03):
    """Multi-start 9D SLSQP; all candidates verified with independent DOP853."""
    rng=np.random.default_rng(seed)
    ref=np.asarray(reference,dtype=float)
    req=request_from_scenario(scenario)
    history=[];best=None
    cons=[{'type':'ineq','fun':lambda z: sampled_constraints(scenario,z,margin_angle,margin_range)}]
    bnds=[(0,46.9),(1,47.9),(.03,47.98)]+[(-30,30)]*6
    def obj(z):return np.linalg.norm(z[3:6])+np.linalg.norm(z[6:9])
    for k in range(n_seeds):
        z=ref.copy()
        if k:
            z[:3]+=rng.normal(size=3)*np.array([.2,.3,.001])
            z[3:]+=rng.normal(size=6)*.055
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            sol=minimize(obj,z,method='SLSQP',bounds=bnds,constraints=cons,
                   options={'maxiter':140,'ftol':8e-10,'disp':False})
        sl=float(np.min(sampled_constraints(scenario,sol.x,margin_angle,margin_range)))
        result={'seed':k,'cost_m_s':float(obj(sol.x)),'sample_min_slack':sl,
                'optimizer_success':bool(sol.success),'verified':False}
        if sl>-1e-6 and np.isfinite(sol.x).all():
            cand=evaluate_transfer(req,tuple(sol.x[:2]*3600),
                (sol.x[3:6],sol.x[6:9]),sol.x[2]*3600-30,step=.01)
            result['verified']=cand.verified
            if cand.verified and (best is None or cand.cost_m_s<best.cost_m_s):best=cand
        history.append(result)
    return best,history
