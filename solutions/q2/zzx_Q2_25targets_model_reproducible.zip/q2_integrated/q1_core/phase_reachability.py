"""Phase/energy reachability lower bound for Q1 observation-time boxes.

The bound complements the existing orbital-plane angular-momentum bound.
It uses the fact that a target can only be observed if the observer's
projected in-plane longitude is sufficiently close to the target's projected
longitude at a common instant in every candidate 60-s observation window.

For any candidate with total impulse U:
  * each coast arc has specific energy in a conservative interval;
  * hence its Kepler mean motion lies in [n_min(U), n_max(U)];
  * each impulse changes the eccentricity vector by a bounded amount;
  * the difference between mean longitude and true longitude is a smooth
    function q(e, f)=M-f with explicit derivative bounds for e <= 0.01;
  * the orbital plane can rotate only by a bounded amount because
    |Delta h| <= r_max * U.

These facts give an upper bound B_phi(U,t) on the observer's possible
projected-longitude change relative to its unforced reference orbit. If the
unforced observer and target projected longitudes differ by Delta_phi, while
being within d_max permits at most Delta_tol of projected-longitude error,
then any feasible maneuver must satisfy

    B_phi(U,t) >= max(0, Delta_phi_lower - Delta_tol_upper).

The resulting root is a necessary lower bound on total delta-v. It is
combined with the independent orbital-plane lower bound by taking their max.

Scope/limitations:
  * assumes at most two impulses and an Earth-clear observer trajectory;
  * target and unforced observer positions at common instants are enclosed by
    outward-rounded interval Kepler propagation;
  * the global observer orbit envelope uses conservative floating-point
    bootstrap bounds, not a fully interval-certified Taylor model;
  * therefore this is a conditional analytical lower-bound implementation,
    not a complete machine-certified global-optimality proof.
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np
from mpmath import iv, mp
from scipy.optimize import brentq

from .model import MU, orbital_elements
from .interval_kepler import IntervalKeplerOrbit
from .plane_reachability import observer_orbit_envelope, plane_impulse_lower_bound

mp.dps = 50
iv.dps = 50


def _lo(x):
    return mp.mpf(x.a)


def _hi(x):
    return mp.mpf(x.b)


def _dot(a, b):
    out = iv.mpf("0")
    for x, y in zip(a, b):
        out += x * y
    return out


def _cross(a, b):
    return [a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]]


def _norm(a):
    return iv.sqrt(_dot(a, a))


def _abs_lower(x):
    lo, hi = _lo(x), _hi(x)
    if lo > 0:
        return lo
    if hi < 0:
        return -hi
    return mp.mpf("0")


def _interval_reference_basis(observer_state):
    """Return outward-rounded initial-plane basis and angular momentum norm."""
    x = [iv.mpf(str(float(v))) for v in np.asarray(observer_state, dtype=float)]
    r, v = x[:3], x[3:]
    rn = _norm(r)
    hv = _cross(r, v)
    hn = _norm(hv)
    nh = [q / hn for q in hv]
    e1 = [q / rn for q in r]
    e2 = _cross(nh, e1)
    return e1, e2, hn


def projected_phase_geometry_lower_bound(observer_interval: IntervalKeplerOrbit,
                                         target_interval: IntervalKeplerOrbit,
                                         basis_e1, basis_e2,
                                         t_s: float,
                                         d_max_km: float = 50.0) -> dict[str, float]:
    """Lower-bound nominal projected phase gap minus allowed distance error.

    The projected azimuth gap is enclosed using interval x/y coordinates.
    If the interval dot product is positive, atan(|cross|/dot) gives a lower
    bound on the acute phase separation. If it is not sign-definite, return
    zero rather than risk an unsafe prune.
    """
    ro = observer_interval.position_interval(t_s).xyz
    rt = target_interval.position_interval(t_s).xyz
    xo, yo = _dot(ro, basis_e1), _dot(ro, basis_e2)
    xt, yt = _dot(rt, basis_e1), _dot(rt, basis_e2)
    cross_xy = xo * yt - yo * xt
    dot_xy = xo * xt + yo * yt
    dot_lo, dot_hi = _lo(dot_xy), _hi(dot_xy)
    if dot_lo <= 0 or dot_hi <= 0:
        return {
            "phase_gap_lower_rad": 0.0,
            "azimuth_tolerance_upper_rad": math.pi,
            "required_phase_lower_rad": 0.0,
            "target_projected_radius_lower_km": 0.0,
        }

    cross_abs_lo = _abs_lower(cross_xy)
    # For an acute angle, atan(cross_lower / dot_upper) is a conservative
    # lower bound. Round it down one representable float.
    ratio = float(cross_abs_lo / dot_hi)
    phase_gap = math.nextafter(math.atan(ratio), -math.inf)

    projected_radius = iv.sqrt(xt * xt + yt * yt)
    p_lo = float(_lo(projected_radius))
    if p_lo <= d_max_km:
        az_tol = math.pi
        required = 0.0
    else:
        # Detection-angle constraint: rho points within 45 deg of target->Earth.
        # Therefore its component tangent to the target geocentric direction
        # is at most d_max*sin(45 deg). The projected azimuth denominator can
        # decrease by at most d_max, giving this conservative angular bound.
        tangential_offset = d_max_km / math.sqrt(2.0)
        radial_projection_lower = p_lo - d_max_km
        az_tol = math.nextafter(
            math.atan(tangential_offset / radial_projection_lower), math.inf)
        az_tol += 2e-14  # outward guard for float conversion
        required = max(0.0, math.nextafter(phase_gap - az_tol, -math.inf))

    return {
        "phase_gap_lower_rad": float(max(0.0, phase_gap)),
        "azimuth_tolerance_upper_rad": float(az_tol),
        "required_phase_lower_rad": float(required),
        "target_projected_radius_lower_km": float(p_lo),
    }


def _q_derivative_bounds(e_max: float) -> tuple[float, float]:
    """Conservative derivative bounds for q=M-f on e <= 0.01.

    For D=1+e cos(f), direct differentiation gives
      |dq/de| <= sqrt(1-e^2)*(2-e)/(1-e)^2 <= 2/(1-e)^2,
      |(dq/df)/e| <= 2.03  (for 0 <= e <= 0.01).
    Hence the gradient with respect to the two Cartesian components of the
    eccentricity vector is below sqrt(2.041^2+2.03^2) < 3. We use K_e=3
    and K_f=2.03*e_max, both rounded outward.
    """
    e = max(float(e_max), 0.0)
    if e >= 0.01:
        raise ValueError("Phase bound requires eccentricity envelope e_max <= 0.01")
    k_r_upper = 2.0 / ((1.0 - 0.01) ** 2)
    k_t_upper = 2.03
    k_e = math.hypot(k_r_upper, k_t_upper) * (1.0 + 1e-12)
    if k_e >= 3.0:
        raise RuntimeError("The analytic eccentricity-gradient bound is not below 3")
    k_e = 3.0 * (1.0 + 1e-12)
    k_f = 2.03 * e * (1.0 + 1e-12)
    return k_e, k_f


class PhaseReachabilityBound:
    """Precompute constants and evaluate the phase-based delta-v lower bound."""

    def __init__(self, observer_state, incumbent_m_s: float,
                 earth_radius_km: float = 6378.137):
        self.state = np.asarray(observer_state, dtype=float)
        self.incumbent_m_s = float(incumbent_m_s)
        self.envelope = observer_orbit_envelope(
            self.state, self.incumbent_m_s, earth_radius_km=earth_radius_km)
        # Outward guards on the floating-point orbit envelope.
        self.r_max = self.envelope.apoapsis_upper_km * (1.0 + 2e-10)
        self.v_max = self.envelope.speed_upper_km_s * (1.0 + 2e-10)
        self.e0 = orbital_elements(self.state)["e"]
        self.energy0 = 0.5 * float(self.state[3:] @ self.state[3:]) - MU / float(np.linalg.norm(self.state[:3]))
        self.n0 = math.sqrt(MU / orbital_elements(self.state)["a_km"] ** 3)
        self.e1, self.e2, h_iv = _interval_reference_basis(self.state)
        self.h0_lower = float(_lo(h_iv))
        self.observer_interval = IntervalKeplerOrbit(self.state)

    def eccentricity_gradient_bound(self, e_max: float) -> tuple[float, float]:
        """Conservative original Phase-8 eccentricity gradient estimate."""
        return _q_derivative_bounds(e_max)

    def phase_change_upper(self, total_dv_m_s: float, t_s: float) -> dict[str, float]:
        """Upper-bound projected-longitude change for any <=2-pulse plan."""
        U = float(total_dv_m_s) * 1e-3  # km/s
        T = float(t_s)
        if U < 0 or T < 0:
            raise ValueError("U and time must be nonnegative")
        eps_hi = self.energy0 + self.v_max * U + 0.5 * U * U
        eps_lo = self.energy0 - self.v_max * U
        if eps_hi >= 0 or eps_lo >= 0:
            return {"phase_change_upper_rad": math.inf}

        a_max = -MU / (2.0 * eps_hi)
        a_min = -MU / (2.0 * eps_lo)
        n_min = math.sqrt(MU / a_max ** 3)
        n_max = math.sqrt(MU / a_min ** 3)
        delta_n = max(self.n0 - n_min, n_max - self.n0)

        # Impulse-induced eccentricity-vector change. For one impulse u:
        # |Delta e| <= (2 r_max v_max u + r_max u^2)/mu.
        delta_e = (2.0 * self.r_max * self.v_max * U + self.r_max * U * U) / MU
        e_max = self.e0 + delta_e
        k_e, k_f = self.eccentricity_gradient_bound(e_max)

        # The orbital-plane normal can travel by at most this path length
        # under <=2 impulses, using |Delta h| <= r_max |Delta v|.
        h_min = self.h0_lower - self.r_max * U
        if h_min <= 0:
            return {"phase_change_upper_rad": math.inf}
        plane_path = math.asin(min(0.999999999, self.r_max * U / h_min))
        # Difference between in-plane true longitude and its projection onto
        # the initial plane, maximized over argument of latitude.
        eps_proj = math.atan((1.0 - math.cos(plane_path)) /
                             (2.0 * math.sqrt(math.cos(plane_path))))

        numerator = (T * delta_n
                     + 2.0 * k_e * (delta_e + e_max * plane_path)
                     + (5.0 + 6.0 * k_f) * eps_proj)
        phase_upper = numerator / (1.0 - k_f)
        phase_upper = math.nextafter(phase_upper * (1.0 + 2e-12), math.inf)
        return {
            "phase_change_upper_rad": float(phase_upper),
            "mean_motion_term_rad": float(T * delta_n),
            "eccentricity_term_rad": float(2.0 * k_e * delta_e),
            "plane_path_rad": float(plane_path),
            "plane_projection_term_rad": float((5.0 + 6.0 * k_f) * eps_proj),
            "eccentricity_upper": float(e_max),
            "K_e": float(k_e),
            "K_f": float(k_f),
        }

    def lower_bound_at_time(self, target_interval: IntervalKeplerOrbit,
                            t_s: float, d_max_km: float = 50.0) -> dict[str, Any]:
        geom = projected_phase_geometry_lower_bound(
            self.observer_interval, target_interval, self.e1, self.e2,
            t_s, d_max_km=d_max_km)
        required = geom["required_phase_lower_rad"]
        if required <= 0:
            return {**geom, "phase_delta_v_lower_bound_m_s": 0.0,
                    "phase_change_upper_at_incumbent_deg": float(math.degrees(
                        self.phase_change_upper(self.incumbent_m_s, t_s)["phase_change_upper_rad"]))}

        upper_at_inc = self.phase_change_upper(self.incumbent_m_s, t_s)["phase_change_upper_rad"]
        if upper_at_inc < required:
            # No plan with total delta-v <= incumbent can reach the 50-km ball
            # at this common instant; report incumbent as a safe threshold.
            return {**geom, "phase_delta_v_lower_bound_m_s": self.incumbent_m_s,
                    "excluded_at_incumbent": True,
                    "phase_change_upper_at_incumbent_deg": math.degrees(upper_at_inc)}

        def f(U_m_s):
            return self.phase_change_upper(U_m_s, t_s)["phase_change_upper_rad"] - required

        root = brentq(f, 0.0, self.incumbent_m_s, xtol=1e-12, rtol=1e-12)
        # Round the root downward so it remains a lower bound under solver error.
        root = max(0.0, root * (1.0 - 2e-8) - 1e-9)
        return {**geom,
                "phase_delta_v_lower_bound_m_s": float(root),
                "excluded_at_incumbent": False,
                "phase_change_upper_at_incumbent_deg": math.degrees(upper_at_inc)}


def screen_phase_time_boxes(scenario, incumbent_m_s: float,
                             plane_screen: dict | None = None,
                             box_width_s: float = 60.0,
                             d_max_km: float = 50.0,
                             t_end_s: float = 172800.0) -> dict:
    """Combine interval phase and angular-momentum-plane necessary bounds.

    The time boxes are the same common-instant boxes used by
    ``screen_center_time_boxes``. The returned global lower bound is the
    minimum, over all boxes not already excluded by solar geometry or the
    plane bound, of max(phase LB, plane LB).
    """
    from .plane_reachability import screen_center_time_boxes

    if plane_screen is None:
        plane_screen = screen_center_time_boxes(
            scenario, incumbent_m_s=incumbent_m_s,
            box_width_s=box_width_s, d_max_km=d_max_km, t_end_s=t_end_s)
    elif abs(float(plane_screen["incumbent_m_s"]) - float(incumbent_m_s)) > 1e-9:
        raise ValueError("Plane screen incumbent must match phase-screen incumbent")

    phase = PhaseReachabilityBound(scenario.observer, incumbent_m_s)
    target_interval = IntervalKeplerOrbit(scenario.target)
    rows = []
    for box in plane_screen["boxes"]:
        if box["excluded_for_strict_improvement"]:
            continue
        t = float(box["center_box_mid_s"])
        ph = phase.lower_bound_at_time(target_interval, t, d_max_km=d_max_km)
        plane_lb = float(box["delta_v_lower_bound_m_s"])
        phase_lb = float(ph["phase_delta_v_lower_bound_m_s"])
        combined = max(plane_lb, phase_lb)
        rows.append({
            "center_box_start_s": float(box["center_box_start_s"]),
            "center_box_end_s": float(box["center_box_end_s"]),
            "common_instant_s": t,
            "plane_lower_bound_m_s": plane_lb,
            "phase_lower_bound_m_s": phase_lb,
            "combined_lower_bound_m_s": combined,
            "phase_geometry": ph,
        })

    if not rows:
        raise RuntimeError("No retained boxes; verify the incumbent and pruning logic")
    best = min(rows, key=lambda x: x["combined_lower_bound_m_s"])
    global_lb = float(best["combined_lower_bound_m_s"])
    return {
        "method": "combined orbital-plane angular-momentum and mean-longitude phase reachability lower bound",
        "incumbent_m_s": float(incumbent_m_s),
        "time_box_width_s": float(box_width_s),
        "total_time_boxes": int(plane_screen["total_center_boxes"]),
        "geometry_excluded_boxes": int(plane_screen["geometry_excluded_boxes"]),
        "plane_excluded_boxes": int(plane_screen["plane_bound_excluded_boxes"]),
        "retained_boxes": len(rows),
        "global_lower_bound_m_s": global_lb,
        "best_box": best,
        "optimality_gap_absolute_m_s": float(incumbent_m_s - global_lb),
        "optimality_gap_relative_to_upper": float((incumbent_m_s - global_lb) / incumbent_m_s),
        "certified_formal_interval_global_optimum": False,
        "proof_scope": (
            "conditional analytical necessary-condition lower bound for at most two impulses and Earth-clear trajectories; "
            "interval Kepler enclosures are used for target and unforced observer geometry at common instants, "
            "but the observer orbit envelope and ephemeris are not a complete interval/Taylor-model certificate"
        ),
        "rows": rows,
    }
