"""Continue a saved verified-state beam; preserves checkpoint and independent proof gate."""
import argparse,json,time
from pathlib import Path
import numpy as np
from q2lib.catalog import Catalog,DEADLINE,DAY
from q2lib.planner import Node,advance
from q2lib.events import solar_visibility_windows,candidates_for_node_events
from run_strategic_beam import choose
ROOT=Path(__file__).resolve().parent

def node(d):
 return Node(float(d['time_s']),np.array(d['observer_state'],float),float(d['used_m_s']),d['last_burn_s'],tuple(d['visited']),d['history'])

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--infile',default='results/strategy_13.json');ap.add_argument('--save',default='results/strategy_24.json')
 ap.add_argument('--depth',type=int,default=25);ap.add_argument('--width',type=int,default=9);ap.add_argument('--max-calls',type=int,default=22)
 a=ap.parse_args();d=json.load(open(ROOT/a.infile));cat=Catalog(ROOT/'data.xlsx',dt=1200);win=solar_visibility_windows(cat)
 beam=[node(n) for n in d['beam']];best=node(d['best']);calls=0;stats=[];t0=time.perf_counter()
 for depth in range(len(beam[0].visited)+1,a.depth+1):
  children=[];valid=0;failed=0;nc=0;t1=time.perf_counter()
  for n in beam:
   edge,st=candidates_for_node_events(cat,n,win,max_days_ahead=4,
       max_events_per_target=8,max_optimizations=a.max_calls,max_candidates=20,
       cap=65,low_margin=.10,max_edge_seconds=2.0)
   nc+=st.nonlinear_optimizations;valid+=st.verified_edges
   for ca in edge:
    child=advance(n,ca)
    if child.time<=DEADLINE and child.fuel<=300:
     children.append(child)
     if len(child.visited)>len(best.visited) or (len(child.visited)==len(best.visited) and child.fuel<best.fuel):best=child
  calls+=nc
  if not children: print('NO CHILD',depth,flush=True);break
  beam,_=choose(cat,win,children,a.width,max_days_ahead=3)
  stats.append({'depth':depth,'children':len(children),'calls':nc,'valid':valid,'wall_sec':time.perf_counter()-t1})
  out={'best':best.serial(),'beam':[n.serial() for n in beam],'stats':stats,'continuation_calls':calls,'params':vars(a)}
  with open(ROOT/a.save,'w') as f:json.dump(out,f,indent=2,ensure_ascii=False)
  print('DEPTH',depth,'children',len(children),'calls',nc,'best',len(best.visited),'fuel',best.fuel,'day',best.time/DAY,
     'beam',[(n.visited[-1],round(n.time/DAY,2)) for n in beam],flush=True)
 print('FINAL',len(best.visited),best.visited,round(best.time/DAY,3),round(best.fuel,4),'calls',calls,'wall',time.perf_counter()-t0,flush=True)
if __name__=='__main__':main()
