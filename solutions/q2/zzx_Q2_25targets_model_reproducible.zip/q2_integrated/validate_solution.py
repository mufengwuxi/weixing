"""Independent sequential DOP853 replay of full 30-day multi-target observation plan.
Reconstructs from Excel + stored burn times; never trusts beam-search state fields.
"""
from __future__ import annotations
import argparse,json,datetime,csv
from pathlib import Path
import numpy as np
from q2lib.catalog import Catalog,DEADLINE
from q1_core.transfer import TransferRequest,evaluate_transfer
from q1_core.model import orbital_elements
EPOCH=datetime.datetime(2027,1,1,tzinfo=datetime.timezone.utc)

def utc(t):return (EPOCH+datetime.timedelta(seconds=float(t))).isoformat(timespec='milliseconds')

def replay(src,verbose=True):
    base=Path(__file__).resolve().parent
    cat=Catalog(base/'data.xlsx',dt=1200)
    data=json.load(open(src,encoding='utf8'))
    plan=data['best'] if 'best' in data else data
    x=cat.observer.copy();curr=0.;fuel=0.;last=None;visited=set();burns=[];lines=[]
    for step,h in enumerate(plan['history']):
        name=h['target_id'];bt=h['burn_times_s'];bv=h['burn_vectors_m_s'];obs=float(h['observation_start_s'])
        if name in visited:raise ValueError(f'Duplicate target: {name}')
        req=TransferRequest(x,cat.targets[name],curr,DEADLINE,300-fuel,last,name)
        verified=evaluate_transfer(req,bt,bv,obs,step=.0001 if step==0 and len(bt)==2 else .01)
        if not verified.verified:
            raise ValueError(f'Failed replay at target {name}, step {step}: {verified.to_dict()}')
        if np.linalg.norm(verified.terminal_observer_state-np.array(h['terminal_observer_state']))>3e-6:
            raise ValueError(f'State inheritance discrepancy at {name}')
        if any(np.linalg.norm(np.array(v))>30+1e-8 for v in bv):raise AssertionError('Burn limit')
        fuel+=verified.cost_m_s;curr=verified.observation_end_s
        last=verified.last_burn_s
        visited.add(name)
        for t,u in zip(bt,bv):burns.append((t,np.linalg.norm(u),name,u))
        lines.append(dict(order=len(lines)+1,target=name,obs_start_s=obs,obs_end_s=curr,
                obs_start_utc=utc(obs),obs_end_utc=utc(curr),t_burn_utc=';'.join(utc(t) for t in bt),
                burn_count=len(bt),burn_delta_v_m_s=verified.cost_m_s,cumulative_delta_v_m_s=fuel,
                min_dist_km=verified.min_distance_km,max_dist_km=verified.max_distance_km,
                max_solar_deg=verified.max_solar_deg,max_detect_deg=verified.max_detect_deg,
                max_one_burn_m_s=max(map(np.linalg.norm,bv),default=0),
                orbit_rp_km=orbital_elements(verified.terminal_observer_state)['rp_km']))
        if verbose:print(f"{name:>3} : obs {utc(obs)} J_step {verified.cost_m_s:.5f} J_total {fuel:.5f} min_dist {verified.min_distance_km:.3f} max_angles {max(verified.max_solar_deg,verified.max_detect_deg):.4f}",flush=True)
        x=verified.terminal_observer_state.copy()
    assert fuel<=300+1e-8 and curr<=DEADLINE+1e-8
    for b1,b2 in zip(burns,burns[1:]):
        if b2[0]-b1[0]<3600-1e-6:raise AssertionError('Any consecutive burn gap <3600s')
    results={'scenario':'r1_four_components_sign_flip_trial_not_raw_excel',
             'certified_optimality':False,'verified_completed_targets':len(lines),
             'sequence':[r['target'] for r in lines],
             'total_delta_v_m_s':float(fuel),'remaining_budget_m_s':300-fuel,
             'total_burns':len(burns),'mission_end_day':curr/86400,
             'all_burn_gaps_s':[burns[i+1][0]-burns[i][0] for i in range(len(burns)-1)],
             'lines':lines,'final_observer_state':x.tolist(),
             'numerical_verification':'DOP853 independent trajectory and solar ephemeris; 0.0001s for Q1, 0.01s later; inter-sample motion envelope, not formal interval arithmetic'}
    out=base/'results'
    with open(out/'verified_schedule.json','w') as f:json.dump(results,f,ensure_ascii=False,indent=2)
    with open(out/'verified_schedule.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(lines[0]) if lines else [])
        w.writeheader();w.writerows(lines)
    return results

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--plan',default=str(Path(__file__).resolve().parent/'results'/'beam_checkpoint.json'))
    args=ap.parse_args();r=replay(args.plan)
    print('TOTAL',r['verified_completed_targets'],'targets',r['total_delta_v_m_s'],'m/s',r['mission_end_day'],'day')
