"""Controlled same-state/time vs fuel experiments; not global transfer cost frontier."""
import json, time
from pathlib import Path
import numpy as np
from q2lib.catalog import Catalog,DAY
from q2lib.planner import Node,optimize_fixed_oneburn
from q2lib.events import solar_visibility_windows,screen_events
ROOT=Path(__file__).resolve().parent
raw=json.load(open(ROOT/'results/event_warm16.json'))['best']
cat=Catalog(ROOT/'data.xlsx',dt=1200)
win=solar_visibility_windows(cat)
profiles=[]
for prefix,name in [(13,'b10'),(13,'b13'),(15,'b3'),(16,'b10')]:
 h=raw['history'][:prefix]; last=h[-1];n=Node(last['observation_end_s'],np.array(last['terminal_observer_state']),sum(q['cost_m_s'] for q in h),last['last_burn_s'],tuple(q['target_id'] for q in h),h)
 t0=time.perf_counter();rr,st=screen_events(cat,n,win,max_days_ahead=11,cap=60,max_events_per_target=14)
 seeds=rr.get(name,[])
 tb=max(n.time+3600,n.last_burn+3600)
 r=[]
 for j,tc,d,u in seeds[:10]:
  sol=optimize_fixed_oneburn(cat,n,name,tb,tc,u,step=.05,maxiter=120,margin_deg=.12)
  r.append({'center_day':float(tc/DAY),'screen_fuel_m_s':float(j),'optimized_fuel_m_s':float(sol.J) if sol else None,'is_verified':bool(sol)})
 print('profile',prefix,name,'options',len(seeds),'valid',sum(z['is_verified'] for z in r),'data',[(round(z['center_day'],2),round(z['optimized_fuel_m_s'],2) if z['is_verified'] else None) for z in r], 's',round(time.perf_counter()-t0,2),flush=True)
 profiles.append({'prefix':prefix,'last_target':n.visited[-1],'target':name,'current_day':float(n.time/DAY),'candidates':r})
(ROOT/'results/time_fuel_profiles.json').write_text(json.dumps({'profiles':profiles,'note':'same observer state and target, fixed early burn time, SLSQP local candidates only. No claim of optimal cost curve'},indent=2),encoding='utf8')
