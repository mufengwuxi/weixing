"""Unit tests for the new mathematically structured candidate generator.
These are software regression tests, not formal global-optimality proofs.
"""
from pathlib import Path
import json
import numpy as np
import pytest
from q2lib.catalog import Catalog
from q2lib.events import (analytic_distance_minimum,solar_visibility_windows,
                          screen_events,_event_indices)
from q2lib.planner import Node
from run_event_beam import select_labels

BASE=Path(__file__).resolve().parents[1]


def test_exact_analytic_distance_solution():
    rng=np.random.default_rng(2027)
    for _ in range(50):
        u0=rng.normal(size=3)*50
        ud=rng.normal(size=3)*3
        d=float(analytic_distance_minimum(u0,ud))
        values=np.linspace(10.3,49.7,500)
        brute=np.min([np.linalg.norm(u0+x*ud) for x in values])
        assert 10.3<=d<=49.7
        assert np.linalg.norm(u0+d*ud)<=brute+1e-8


def test_target_only_geometry_windows():
    c=Catalog(BASE/'data.xlsx',dt=1200)
    win=solar_visibility_windows(c)
    assert set(win)==set(c.targets)
    assert all(0<=a<b<=30*86400 for rows in win.values() for a,b in rows)
    # A verified midpoint of each solar-only window satisfies gamma<=90 deg.
    from q1_core.kepler_fast import propagate_ellipse
    from q1_core.geometry import sun_position
    for name in ['b1','b2','b18','b30']:
        for a,b in win[name][:4]:
            t=(a+b)/2;r=propagate_ellipse(c.elements[name],t)[0]
            s=sun_position(t)-r
            assert np.dot(s,-r)/(np.linalg.norm(s)*np.linalg.norm(r))>=-1e-8


def test_event_selection_earliest_versus_later_cheap():
    ts=np.arange(8)*86400
    cost=np.array([40.,20.,15.,11.,10.,8.,1.,2.])
    event=_event_indices(ts,cost,np.ones(len(ts),dtype=bool),max_events=4)
    assert 1 in event or 0 in event
    assert 6 in event
    assert len(event)<=4


def test_screened_candidates_keep_real_target_states():
    c=Catalog(BASE/'data.xlsx',dt=1200)
    x=json.load(open(BASE/'results/baseline_21_checkpoint.json'))['best']
    h=x['history'][0]
    n=Node(h['observation_end_s'],np.array(h['terminal_observer_state']),
           h['cost_m_s'],h['last_burn_s'],('b1',),[h])
    window=solar_visibility_windows(c)
    options,st=screen_events(c,n,window,max_days_ahead=8)
    assert st.event_count>0
    assert 'b1' not in options
    assert 'b2' in options
    assert all(10.3-1e-8<=item[2]<=49.7+1e-8 for values in options.values() for item in values)


def test_label_selection_cannot_conflate_different_visited_sets():
    state=np.array([42160.,0.,0.,0.,3.07,0.])
    a=Node(9e5,state.copy(),30,8e5,('b1','b2'),[])
    b=Node(9e5,state.copy(),29,8e5,('b1','b3'),[])
    sel=select_labels([a,b],width=2)
    assert len(sel)==2
    assert {s.visited for s in sel}=={('b1','b2'),('b1','b3')}


def test_verified_incumbent_extension_metadata():
    old=json.load(open(BASE/'results/baseline_21_checkpoint.json'))['best']
    new=json.load(open(BASE/'results/event_warm16.json'))['best']
    assert len(old['visited'])==21
    assert len(new['visited'])==22
    assert new['visited'][:16]==old['visited'][:16]
    assert new['time_s']<=30*86400
    assert new['used_m_s']<=300
    assert len(set(new['visited']))==22
