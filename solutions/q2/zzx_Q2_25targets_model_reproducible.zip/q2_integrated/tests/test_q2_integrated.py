"""Final solution checks. A separate replay verifies nonlinear physics."""
import json
from pathlib import Path
import numpy as np
from q2lib.catalog import Catalog
from q1_core.transfer import TransferRequest,evaluate_transfer
ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'results'

def test_all_25_targets_unique_and_within_budget():
 r=json.loads((RES/'verified_schedule.json').read_text())
 assert r['verified_completed_targets']==25
 assert len(set(r['sequence']))==25
 assert r['total_burns']==27
 assert r['total_delta_v_m_s']<300
 assert r['mission_end_day']<30

def test_all_25_observation_constraints_recorded():
 r=json.loads((RES/'verified_schedule.json').read_text())
 for s in r['lines']:
  assert abs(s['obs_end_s']-s['obs_start_s']-60)<1e-7
  assert 10<=s['min_dist_km']<=s['max_dist_km']<=50
  assert s['max_solar_deg']<=45
  assert s['max_detect_deg']<=45
  assert s['max_one_burn_m_s']<=30+1e-8
  assert s['orbit_rp_km']>=6378.137
 assert min(r['all_burn_gaps_s'])>=3600-1e-8

def test_25_plan_internal_history_consistency():
 d=json.loads((RES/'strategy_25_refined.json').read_text())['best']
 r=json.loads((RES/'verified_schedule.json').read_text())
 assert d['visited']==r['sequence']
 assert abs(d['used_m_s']-r['total_delta_v_m_s'])<1e-7
 assert abs(d['time_s']/86400-r['mission_end_day'])<1e-9
 assert len(d['history'])==25
 assert [len(h['burn_times_s']) for h in d['history']]==[2]+[1]*23+[2]

def test_source_scenario_is_explicit():
 c=Catalog(ROOT/'data.xlsx')
 assert np.allclose(c.observer[[0,1,4,5]],-c.raw_observer[[0,1,4,5]])
 assert c.observer[2]==c.raw_observer[2]
 assert c.observer[3]==c.raw_observer[3]
 assert len(c.targets)==30

def test_b30_pulse_can_occur_before_old_one_hour_wait():
 p=json.loads((RES/'strategy_25_refined.json').read_text())['best']['history']
 old_end=p[-2]['observation_end_s']
 b=p[-1]
 assert b['target_id']=='b30'
 assert 0<=b['burn_times_s'][0]-old_end<3600
 assert b['burn_times_s'][1]-b['burn_times_s'][0]>=3600

def test_terminal_b30_independent_dynamics():
 p=json.loads((RES/'strategy_25_refined.json').read_text())['best']['history']
 cat=Catalog(ROOT/'data.xlsx')
 pre=p[-2]; h=p[-1]
 req=TransferRequest(np.array(pre['terminal_observer_state']),cat.targets['b30'],
      pre['observation_end_s'],30*86400,300-sum(float(g['cost_m_s']) for g in p[:-1]),pre['last_burn_s'],'b30')
 res=evaluate_transfer(req,h['burn_times_s'],h['burn_vectors_m_s'],h['observation_start_s'],step=.01)
 assert res.verified
 assert np.linalg.norm(res.terminal_observer_state-np.array(h['terminal_observer_state']))<3e-6
