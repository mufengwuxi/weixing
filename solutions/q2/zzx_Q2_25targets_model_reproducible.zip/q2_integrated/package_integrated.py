"""Bundle final independently replayable Q2 project, excluding temp/cache artifacts."""
import zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DST=Path('/mnt/data/Q2_25targets_model_reproducible.zip')
files=[]
for name in ['data.xlsx','q1_baseline.json','requirements.txt','Q2_INTEGRATED_PAPER_CN.md',
             'README_FINAL.md','MODEL_AND_BENCHMARK_CN.md','run_strategic_beam.py',
             'extend_strategic_beam.py','attempt_b30_twoburn.py','refine_tail.py',
             'run_robust_tail.py','run_time_fuel_profile.py','make_integrated_figures.py',
             'validate_solution.py','benchmark_nodes.py','run_event_beam.py',
             'summarize_benchmark.py','package_integrated.py']:
 files.append(ROOT/name)
for sub in ['q1_core','q2lib','tests']:
 files+=sorted((ROOT/sub).glob('*.py'))
for n in ['verified_schedule.json','verified_schedule.csv',
          'verified_25_final.json','verified_25_final.csv',
          'verified_25_robust.json','verified_25_robust.csv',
          'verified_24_backup.json','verified_24_backup.csv',
          'verified_23_backup.json','verified_23_backup.csv',
          'verified_22_backup.json','verified_22_backup.csv',
          'baseline_21_checkpoint.json','baseline_21_verified_schedule.json','event_warm16.json',
          'strategy_13.json','strategy_24.json','strategy_25_refined.json',
          'strategy_25_robust.json','strategy_25_candidate.json',
          'ablation_old_labels.json','time_fuel_profiles.json','coast_screen.json',
          'node_benchmark.json','summary.json']:
 p=ROOT/'results'/n
 if p.exists():files.append(p)
for n in ['q2_coverage_vs_fuel.png','q2_cumulative_delta_v.png','q2_improvement_history.png','q2_time_fuel_profiles.png',
          '22_targets_fuel.png','paired_solver_calls.png','paired_wall_time.png']:
 p=ROOT/'figures'/n
 if p.exists():files.append(p)
with zipfile.ZipFile(DST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:
  z.write(p,arcname=str(Path('q2_integrated')/p.relative_to(ROOT)))
with zipfile.ZipFile(DST) as z:
 assert z.testzip() is None
 print('zip',DST,'files',len(z.namelist()),'bytes',DST.stat().st_size)
