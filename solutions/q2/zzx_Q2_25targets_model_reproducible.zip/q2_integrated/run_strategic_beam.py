"""Time-fuel informed beam with geometric event screening and target-diverse labels.
This is a heuristic lower-bound generator, never a proof of optimality.
"""
import argparse,json,time,sys
from pathlib import Path
import numpy as np
from q2lib.catalog import Catalog,DEADLINE,DAY
from q2lib.planner import Node,advance
from q2lib.events import solar_visibility_windows,candidates_for_node_events,screen_events
ROOT=Path(__file__).resolve().parent

def load_node(hist):
 h=hist[-1]
 return Node(float(h['observation_end_s']),np.array(h['terminal_observer_state'],float),
             sum(float(q['cost_m_s']) for q in hist),float(h['last_burn_s']),tuple(q['target_id'] for q in hist),hist)

def rank(node,available,penalty=0.024):
 # smooth lookahead: time and number of remaining reachable targets in a relaxed screen
 return node.time/DAY+penalty*node.fuel-0.15*min(6,available)

def choose(cat,windows,children,width,max_days_ahead,forecast_per_group=1):
 # Cache future 6-day *linearized* reachable target count only for ordering, no proof pruning
 info=[]
 for n in children:
  seeds,_=screen_events(cat,n,windows,max_days_ahead=max_days_ahead,cap=30.,max_events_per_target=1)
  future=len(seeds)
  info.append((rank(n,future),future,n))
 info.sort(key=lambda a:a[0])
 winners=[];last_count={};fingerprints=set()
 # Preserve several time/fuel/phase/target classes
 for pass_ix in (0,1,2):
  arr=info if pass_ix==0 else sorted(info,key=lambda a:a[2].time if pass_ix==1 else a[2].fuel)
  for score,future,n in arr:
   if id(n) in fingerprints:continue
   last=n.visited[-1]
   if pass_ix==0 and last_count.get(last,0)>=max(2,width//4):continue
   if pass_ix==1 and any(z.visited[-1]==last for z in winners):continue
   winners.append(n);fingerprints.add(id(n));last_count[last]=last_count.get(last,0)+1
   if len(winners)>=width:return winners,info
 return winners,info

def main():
 pa=argparse.ArgumentParser()
 pa.add_argument('--warm-prefix',type=int,default=13)
 pa.add_argument('--depth',type=int,default=23)
 pa.add_argument('--width',type=int,default=10)
 pa.add_argument('--max-calls',type=int,default=12)
 pa.add_argument('--max-days',type=float,default=8)
 pa.add_argument('--max-edges',type=int,default=9)
 pa.add_argument('--cap',type=float,default=55)
 pa.add_argument('--save',default='results/strategy_search.json')
 args=pa.parse_args()
 cat=Catalog(ROOT/'data.xlsx',dt=1200)
 windows=solar_visibility_windows(cat)
 hist=json.load(open(ROOT/'results/event_warm16.json'))['best']['history'][:args.warm_prefix]
 start=load_node(hist)
 beam=[start];best=start;stats=[];total_calls=0
 t0=time.perf_counter();destination=ROOT/args.save
 for depth in range(len(start.visited)+1,args.depth+1):
  edges=[];tcalls=0;valid=0;t1=time.perf_counter()
  for parent in beam:
   candidates,st=candidates_for_node_events(cat,parent,windows,max_days_ahead=args.max_days,
                    max_events_per_target=5,max_optimizations=args.max_calls,
                    max_candidates=args.max_edges,step=.05,low_margin=.12,cap=args.cap,max_edge_seconds=1.25)
   tcalls+=st.nonlinear_optimizations;valid+=st.verified_edges
   for ca in candidates:
    child=advance(parent,ca)
    if child.fuel<=300 and child.time<=DEADLINE:edges.append(child)
    if len(child.visited)>len(best.visited) or (len(child.visited)==len(best.visited) and child.fuel<best.fuel):best=child
  total_calls+=tcalls
  if not edges:print('STOP NO EDGES',depth,flush=True);break
  beam,sc=choose(cat,windows,edges,args.width,max_days_ahead=6)
  stats.append({'depth':depth,'parents':len(beam),'children':len(edges),'calls':tcalls,'valid':valid,'elapsed_seconds':round(time.perf_counter()-t1,2),
                'best_count':len(best.visited),'earliest_day':round(min(x.time for x in beam)/DAY,4),'max_future_events':max(z[1] for z in sc)})
  result={'best':best.serial(),'beam':[b.serial() for b in beam],'stats':stats,'total_calls':total_calls,
          'meta':{'algorithm':'time_fuel_future_visibility_label_search','certificate':False,'warm_prefix':args.warm_prefix,'config':vars(args)}}
  destination.parent.mkdir(exist_ok=True,parents=True)
  with destination.open('w') as f:json.dump(result,f,ensure_ascii=False,indent=2)
  print('DEPTH',depth,'calls',tcalls,'valid',valid,'children',len(edges),'secs',round(time.perf_counter()-t1,2),
       'best',len(best.visited),round(best.time/DAY,2),round(best.fuel,1),'beam',
       [(q.visited[-1],round(q.time/DAY,1),round(q.fuel,1)) for q in beam[:5]],flush=True)
 print('END',len(best.visited),best.visited,'time',best.time/DAY,'fuel',best.fuel,'call',total_calls,'wall',time.perf_counter()-t0,flush=True)

if __name__=='__main__':main()
