"""Find alternative that leaves reserves below the single-impulse ceiling."""
from pathlib import Path
import json
import numpy as np
from attempt_b30_twoburn import run,B,ct,ROOT
from q2lib.catalog import DAY
best=None
for cap,ang,dmax in [(29.7,44.82,49.6),(29.5,44.80,49.5),(29.0,44.75,49.4)]:
 for off in (60.,300.,600.):
  for gap in (3600.,5400.,7200.):
   for cent in (29.738,29.7396,29.741,29.743):
    x=run(cent*DAY,ct+off,ct+off+gap,burn_cap=cap,angle_deg=ang,dmax=dmax)
    if x is None or not x[2]:continue
    val,g,valid,u,res=x
    if best is None or (cap<best[1] and val<50) or (cap==best[1] and val<best[0]):
     best=(val,cap,ang,dmax,res)
 print('CAP',cap,'best-so-far',None if best is None else (best[0],best[1]),flush=True)
if best:
 val,cap,ang,dmax,res=best
 plan={'best':B.copy()}
 plan['best']['history']=B['history']+[res.to_dict()]
 plan['best']['visited']=list(B['visited'])+['b30']
 plan['best']['time_s']=res.observation_end_s
 plan['best']['used_m_s']=B['used_m_s']+res.cost_m_s
 plan['best']['observer_state']=res.terminal_observer_state.tolist()
 plan['best']['last_burn_s']=res.last_burn_s
 plan['scenario']='trial'
 plan['robustness']={'per_burn_cap_m_s':cap,'angle_cap_deg':ang,'max_range_cap_km':dmax}
 (ROOT/'results/strategy_25_robust.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False),encoding='utf8')
 print('ROBUST RESULT',val,cap,ang,dmax,[np.linalg.norm(v) for v in res.burn_vectors_m_s],flush=True)
