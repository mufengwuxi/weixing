"""Plot paper figures from independently replayed plans and controlled experiments."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
O=R/'figures'
O.mkdir(exist_ok=True)
files={21:'baseline_21_verified_schedule.json',22:'verified_22_backup.json',23:'verified_23_backup.json',24:'verified_24_backup.json',25:'verified_schedule.json'}
plans={k:json.loads((R/'results'/name).read_text()) for k,name in files.items()}
# Cost/coverage scatter. The points come from different strategies, not an exact frontier.
fig,ax=plt.subplots(figsize=(8.5,5.1))
for k,p in plans.items():
 x=p['total_delta_v_m_s'];y=k
 ax.scatter([x],[y],s=80,zorder=3)
 ax.annotate(f'{k} targets\n{x:.1f} m/s',(x,y),xytext=(7,0),textcoords='offset points',fontsize=9,va='center')
ax.set_xlim(80,250);ax.set_ylim(20,27.5)
ax.set_xlabel('Total impulse budget used (m/s)');ax.set_ylabel('Verified distinct targets')
ax.set_title('Verified coverage vs. fuel: successive model improvements')
ax.grid(alpha=.23);fig.tight_layout();fig.savefig(O/'q2_coverage_vs_fuel.png',dpi=190);plt.close(fig)
# Cumulative fuel trajectories
fig,ax=plt.subplots(figsize=(9.7,5.5))
for k in [21,22,23,24,25]:
 p=plans[k];tt=[0]+[r['obs_end_s']/86400 for r in p['lines']]
 j=[0]+[r['cumulative_delta_v_m_s'] for r in p['lines']]
 ax.step(tt,j,where='post',label=f'{k} targets',linewidth=1.8 if k==25 else 1.2)
ax.axhline(300,color='gray',linestyle='--',label='Budget limit 300 m/s',alpha=.6)
ax.set(xlabel='Mission elapsed time (days)',ylabel='Cumulative delta-V (m/s)',xlim=(0,30),ylim=(0,315),title='Verified resource trajectories over 30 days')
ax.grid(alpha=.2);ax.legend(ncol=3,fontsize=9,loc='upper left')
fig.tight_layout();fig.savefig(O/'q2_cumulative_delta_v.png',dpi=190);plt.close(fig)
# Time-fuel profile for fixed source state/target.
profiles=json.loads((R/'results/time_fuel_profiles.json').read_text())['profiles']
fig,ax=plt.subplots(figsize=(9,5.2))
for pref in profiles:
 pts=sorted([(d['center_day'],d['optimized_fuel_m_s']) for d in pref['candidates'] if d['is_verified']])
 if pts:
  x,y=zip(*pts);ax.plot(x,y,marker='o',markersize=5,label=f"After {pref['prefix']} targets: {pref['target']}")
ax.set(xlabel='Observation center (days from epoch)',ylabel='One-burn candidate delta-V (m/s)',title='Exact-time fuel costs can be nonmonotone')
ax.grid(alpha=.25);ax.legend(fontsize=8)
fig.tight_layout();fig.savefig(O/'q2_time_fuel_profiles.png',dpi=190);plt.close(fig)
# Coverage progress
fig,ax=plt.subplots(figsize=(8.3,4.5))
xx=np.array([21,22,23,24,25]);yy=np.array([102.4925979086,147.2439150761,129.4944213064,150.3146469796,188.2847646496])
ax.plot(xx,yy,marker='o');ax.set_xticks(xx)
ax.set(xlabel='Verified target count',ylabel='Plan fuel (m/s)',title='Coverage gains may require fuel and schedule reallocation')
ax.grid(alpha=.25);fig.tight_layout();fig.savefig(O/'q2_improvement_history.png',dpi=190);plt.close(fig)
print('created',sorted(x.name for x in O.glob('q2_*.png')))
