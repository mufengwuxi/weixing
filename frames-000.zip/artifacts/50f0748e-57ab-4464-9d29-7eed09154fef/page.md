# Refusal 方向 N1–N4 二次分析

<!-- tab: Refusal 方向 N1–N4 二次分析 -->

# Refusal 方向 N1–N4 二次分析

2026-10-22 · @someone

## 一页结论表

推荐组合：一篇冲 B（N5 → N2 + N3-lite + N1-lite 合为一篇机制论文），加一篇保底 C（N4，独立）。两篇的失败风险互不相关，N4 的结果不依赖任何机制实验成功。

| 方向 | 判决 | 新颖性 | 可行性（24GB / 1 人） | 预计贡献等级 | 一句话理由 |
| --- | --- | --- | --- | --- | --- |
| **N2** 判断→执行通路 | **改后做（主线，冲 B）** | 中高【需检索验证】 | 中（工程 3–4 周） | B（与 N5 合并时） | 三环分类可操作化后有可证伪预测；原文的防御适配预测有逻辑错误，必须重写（见 N2 第 5 小节） |
| **N5（新增）** 方向测量在越狱风格下的效度 | **直接做（先行，2 周）** | 中高【需检索验证】 | 很高（<1 GPU·天） | 单独为 C，并入 N2 后撑 B | N2 与 Zhao §4 的结论都建立在未经检验的测量假设上，不做会被一击致命 |
| **N4** 阈值置换 | **改后做（保底 C）** | 中 | 很高（行为层可能近乎零 GPU） | C，好的话 EMNLP Findings | 改写为 IRT 单维性检验；原"跨模型搬阈值"在度量上不成立 |
| **N1** 不可逆点 | **改后做，降为 N2 第二章** | 中低 | 高 | C（单独）/ 为 B 加分（并入） | 与 Qi et al. 2025、DeRTa、Backtracking 高度相邻；"静态检测有上限"的论证方向是反的 |
| **N3** 跨论文向量统一性审计 | **杀（独立成文）** | 低 | 中（复现成本高） | — | 同位置同源数据的 DIM 方向高相关属预期；"同轴即马甲"是过度推论；只保留 0.5 GPU·天的坐标校准并入 N2 |

**目标会议口径需先纠正**：ACL 主会在 CCF 目录中是 A 类，EMNLP、NAACL、COLING 是 B 类。Findings 不在 CCF 目录里，是否算 B 取决于单位认定口径。"冲 B"的实际目标应是 EMNLP 2027 主会，Findings 作退路。

## 文件间矛盾与需先厘清的前提

1. **N2 的防御适配预测与 Latent Guard 原理相反。** 第一部分 §9 N2 写"Latent Guard 只对信源损坏敏感"。但第一部分 §11.9 说明 Latent Guard 依赖越狱后"内部仍保留有害判断"，即 t\_inst 上的 Φ\_harmful。信源损坏时它是**盲的**，只对信道/接收端类有效。这恰是 N2 最有价值的 so-what 来源。
2. **"JBShield 救不了信源损坏"不成立。** JBShield 缓解是在 t\_post-inst 加毒性概念（第一部分 §3.5），按 §5.5 近似拒答方向；Arditi 证明加拒答方向连无害请求都能逼出拒答（§11.1）。真正的区别在**检测召回率**和**选择性**，不在缓解是否有效。
3. **JBShield 的 last token 是否等于 t\_post-inst 未核实。** 第一部分 §4.4 的 2×2 表与 §5.5 的共线性质疑都默认套了 chat template。若没套，它测的是 t\_inst，版图要重画。【需核对 JBShield 原文 §3–4】
4. **两个 61% 可疑。** 第四部分 C3 写"未来时 61%、微调过拒率 3%→61%"，第一部分 §9 N4 引用了后者，可能串号。D 节白名单未覆盖，引用前回原文核对。
5. **算力与"7–13B"冲突。** 第二部分 §三写 7–13B；13B 的 bf16 权重约 26GB，超出 24GB。行为层可用 8-bit，机制实验不能用量化模型，因此限定 ≤9B（Gemma-2-9B 约 18.5GB，patching 时偏紧）。
6. **第二部分 judge 选择自相矛盾。** N1 用本地 SORRY-Bench 7B judge，但第一部分 §3.6 指出它对 Zulu/Base64 的 F1 只有 0–0.4。依赖 judge 的指标须排除编码类或改人工。
7. **"双方对拥挤处判断一致"言过其实。** 第一部分 §9.5 与第三部分 §1.1 列的 steering 干扰工作是不同集合，均未交叉验证。
8. 第五部分的论文标题与第一部分不一致（SORRY-Bench、Overrefusal），以第一部分为准。

## N2 判断→执行通路（主线，改后做）

### 1 混淆变量

- **t\_inst 落点随家族变化（最严重）**：GCG 落在乱码后缀末尾，模板类落在模板结尾，说服类落在改写段末尾。三处读 Φ\_harmful 测的不是同一语义位置。
- **风格污染**：【事实｜第一部分 §5.5、第四部分 D】越狱模板 + 良性内容时检测准确率跌到 0.19。
- **长度**：注意力传输量随上下文变长而稀释，"信道切断"可能只是提示变长。
- **方向提取数据谱系**：【事实｜第一部分 §3.6】方向来自 AdvBench 对 Alpaca 的短祈使句，用在长模板上属分布外测量。
- **只看成功样本**：会把成功的原因与成功样本的共同表面特征混在一起。

### 2 负结果风险

最可能失败的是三类越狱**不形成离散三类**，或通路弥散、找不到稀疏头。退路：S/T/O 能稳定测量即可发表"连续二维刻画 + 家族内异质性大于家族间差异"（约 C）。若"信道切断"类为空，就诚实报告二分法，这是对第一部分 §9 假说的有效证伪。

### 3 审稿人三条反对意见

1. **"只是把 Zhao 与 JailbreakScope 拼起来。"** 拼接本身是空白（第一部分 §9 N2）；贡献落在两者都给不出的位置分辨贡献分解与检测盲区量化。
2. **"归因是线性近似。"** 归因只做筛选，top-k 成分做精确 activation patching，配范数匹配随机基线（C6）。
3. **"三分类是 Zhao 两类换名。"** 用独立操作化定义证明"信道切断"非空、可区分，再用 3×3 修复矩阵检验因果意义；分不出就如实报告。

### 4 撞车风险

最近的潜在撞车是 Zhou et al. 2024《How Alignment and Jailbreak Work》（EMNLP Findings 2024），据我所知论证了"早层伦理判断、越狱破坏中层关联"，接近"信道切断"叙事。另有《On the Biology of a Large Language Model》（2025）的越狱案例、ICLR 2025 的 safety heads 类工作。均【需检索验证】。第一部分 §9.5 不覆盖这类工作，故新颖性只给"中高"。

### 5 推导链的逻辑问题

1. 防御适配预测写反（见矛盾第 1、2 条）。修正后的价值命题：**信源损坏型越狱是所有"以有害性或拒答为锚"的表示检测器的共同盲区**，量化其在成功越狱中的占比，并测试能补上的信号，如 reply inversion 一致性（第一部分 §11.9）。
2. 把信道建模为 t\_inst→t\_post-inst 单边过窄。t\_post-inst 可直接从整个请求片段读取有害性，应改为"请求片段 → 指令后位置"。
3. 第一部分 §4.4 已承认 Zhao 的两个方向同时改变位置与标签，在两处各测一个投影不构成通路证据，必须用 patching 或分解建立联系。

### 6 修正版设计

三个量都用 N5 的风格匹配良性对照做双重差分校正：

- **S（信源）**：Φ\_harmful 在 t\_inst 与嵌入请求片段末 token 两处的投影。
- **T（传输）**：t\_post-inst 拒答投影中来自请求片段的直接贡献（固定注意力模式，按源位置线性分解，跨层求和，以朴素有害为基线归一化）。
- **O（覆盖）**：同一分解中来自后缀、模板、人设等非请求 token 的贡献，显著为负即覆盖。

分类：S 低 = 信源损坏；S 高、T 低、O≈0 = 信道切断；S 高、T 正常、O 显著为负 = 接收端覆盖。

- **RQ1**：S/T/O 能否稳定测量，校正后是否区分攻击家族？
- **RQ2**：同一家族内成功与失败样本是否在 S/T/O 上可分（天然风格匹配对照）？
- **RQ3**：把匹配朴素有害提示的请求片段激活移植进越狱提示，拒答能否恢复？在指令后位置移植头输出呢？
- **RQ4**：Latent Guard 与 JBShield 式检测器在每类上的召回率？

| 编号 | 控制 | 剥离的是什么 |
| --- | --- | --- |
| C1 | 风格匹配良性：同一包装套在良性请求上，报告双重差分 | 越狱风格本身的方向偏移 |
| C2 | 家族内成功 vs 失败 | 家族表面特征 |
| C3 | 朴素有害提示中性填充至同长，并回归掉对数长度 | 长度对 T 的稀释 |
| C4 | 编码类先解码；不依赖 judge 的指标单独报告 | 表层编码 |
| C5 | 一个模型上更换 chat template | 模板依赖 |
| C6 | 范数匹配随机方向与随机头 patching | 干预的非特异效应 |

**判决性实验：3×3"类别 × 修复"选择性矩阵（纯推理）。** 三种修复为请求片段有害性 steering（修信源）、恢复关键头输出（修信道）、t\_post-inst 加拒答方向（修接收端），各取最小有效 α，同时在 C1 良性包装集上测误拒。对角占优则分类有因果意义且可指导选防御；接收端修复处处最优则说明下游是普适瓶颈，难点在检测，与 RQ4 合并成文。两种结果都有信息量。

### 7 简要计划

- **数据**：方向提取用 AdvBench + Alpaca；评测种子改用 JBB 100 条 + HarmBench 子集 200 条，与提取集不相交。家族：说服类（PAP，Zeng et al. 2024）、模板类（Shen et al. CCS'24 或 JBB 模板）、语义改写类（JBB 的 PAIR 产物）、后缀类（GCG）。每家族 ≥150 次尝试，成功失败都保留。良性包装用 Alpaca + XSTest-safe。
- **模型**：Llama-3-8B-Instruct、Qwen2-7B-Instruct、Llama-2-7B-chat（可用 L21H14、L26H04 做健全性检查）、Gemma-2-9B-it（非 Llama 家族，对应第一部分 §9.6-①）。
- **步骤**：N5 风格校正（第 1–2 周）→ S/T/O 分解（第 3 周）→ 归因筛选 + 精确 patching（第 4 周）→ 3×3 矩阵与检测盲区（第 5 周）→ N3-lite 坐标校准（2 天）。
- **GPU**：分析 2–3 GPU·天；GCG 用 nanoGCG 250 步 100 条，单模型约 1 GPU·天，只做 1–2 个模型【需检索验证 HarmBench/JBB 是否覆盖 Llama-3、Qwen2】。合计 4–6 GPU·天。
- **两周试点**（Llama-3-8B，说服类、模板类 + 朴素有害），全部达标才继续：
  - 请求片段贡献解释朴素有害与良性拒答投影差距的 ≥50%，否则信道不在请求片段，需重新定框；
  - 双重差分后两家族在某一维效应量 d ≥ 0.5；
  - 家族内成功与失败在某一维 AUC ≥ 0.7；
  - **放弃标准**：后两条同时不达标，转为 N5 + N4 两篇 C。
- **目标与叙事**：EMNLP 2027（ARR 2027 年 5 月周期【需检索验证】）。*越狱在安全决策链的不同环节得手；其中一类改写判断本身，所有基于表示的检测器都看不见它。*

## N5（新增）：方向测量在越狱风格下的效度

先行做，2 周、不到 0.5 GPU·天；单独可投 C，最好的用法是作为 N2 的 §3。

**支撑它的已证事实**

- 【第一部分 §5.5、第四部分 D】JBShield 在"越狱模板 + 良性内容"下准确率跌到 0.19，方向里混有风格。
- 【第一部分 §4.4】Zhao 的"说服类让 Φ\_harmful 变负"带 *in some cases* 限定，且无风格匹配良性对照。
- 【第一部分 §3.6】几乎所有方向都提取自 AdvBench 对 Alpaca，两者本身风格不同。
- 【第一部分 §5.3】非英语有害/无害分离更差：方向可迁移不等于测量可靠。

**为什么 §9.5 没占掉它**：那些工作都在**使用**投影（检测、steering 组合、学习式 steering、多方向、可迁移性），无一检验投影在风格偏移下是否有效。第三部分 §1.1 的《When Benchmarks Lie》研究的是提示分类器而非内部方向。针对越狱风格的探针效度研究是否已存在【需检索验证】。

**设计**：内容（有害/良性）× 包装（无、说服、模板、后缀、PAIR 式改写、翻译）析因实验，测 Φ\_h、Φ\_r、JBShield 的 v\_t 与 v\_j 投影。包装对良性的主效应 = 风格偏移，交互项才是真实效应。再用风格平衡数据重提"风格鲁棒方向"，在 JBShield Table 6 条件下比较原方向与新方向的检测效果。

**判决性实验**：说服类双重差分。有害说服的 Φ\_h 下降 ≈ 良性说服的下降，则 Zhao 的"说服骗过判断"主要是风格伪影，是反直觉强结论；前者显著更大，则 Zhao 结论在严格对照下成立，N2 获得干净地基。

**计划**：Llama-3-8B 与 Qwen2-7B，每格 100 条，约 2.4k 提示，纯前向。唯一放弃标准：方向 bootstrap 余弦 < 0.9，即测量噪声压过信号。目标 NLPCC、ICONIP，或并入 N2。

## N4 阈值置换 → 改写为 IRT 单维性检验（保底 C）

### 压力测试

- **度量不可通约（致命）**：不同模型的内部投影单位不同，"把 A 的阈值搬到 B"没有定义。必须改用排序与分位数，或直接用行为层潜变量模型。
- **混淆**：judge 是隐藏变量（第一部分 §3.6）；表层词汇触发（kill、explode）决定很多题目难度，可作发现但要报告；同源模型（Vicuna 源自 Llama）造成伪重复，需按家族分层交叉验证。
- **推导链跳跃**：【事实｜第一部分 §11.6】OR-Bench 的 0.89 是 32 个模型间的秩相关，不能推出题目层面共享一个维度。"几何必然"是过度推论：当前模型共享题目排序，不等于更好的区分不可能。用阈值解释 Past Tense 3%→61% 是事后解释，且数字待核。
- **审稿人反对与回应**："OR-Bench 已展示相关"——贡献在题目层面检验与跨基准样本外预测；"IRT 用于 LLM 评测不新"——用于漏拒/过拒双侧并锚定内部表示是新组合；"judge 噪声大"——双 judge + 300 条人工，报告 κ。
- **撞车**：Marshall et al. 2024《Refusal in LLMs is an Affine Function》把拒答写成带偏置的仿射函数，直接相邻；IRT 用于 LLM 评测（如 tinyBenchmarks）。均【需检索验证】。

### 修正版

- **RQ1**：在"安全 + 有害"混合题目上，拒答行为是否单维？比较 1PL、2PL 与二维 MIRT，交叉验证。
- **RQ2**：在一个基准上标定单个 θ\_m，能否预测其他基准的拒答率？
- **RQ3**：题目难度 b\_i 与 t\_inst 的 Φ\_h 还是 t\_post 的拒答投影更一致？把 Zhao 双因素接到行为层。
- **RQ4**：哪些模型偏离单维前沿（区分度 a 不同），对应什么训练差异？

**判决性实验**：单 θ 跨基准预测。平均绝对误差 < 5 个百分点，则过拒与漏拒是同一个旋钮，同时报告两者是冗余的；误差大则定位哪些题目、类别的排序在模型间改变。两种结果都有信息量。

### 计划

- **数据**：XSTest 450、OR-Bench-Hard 抽 500、Toxic-600、SORRY 基础 440，约 2k 题。先查 SORRY-Bench 是否公开 56 个模型的回答或判定，若公开则行为层近乎零 GPU【需检索验证】。
- **模型**：15–20 个开源 7–9B 指令模型（Llama-2/3/3.1、Qwen2/2.5、Mistral、Gemma-2、Yi、OLMo-2、Tulu-3 等），含同底座不同对齐的成对模型；13B 只用 8-bit 做行为层。
- **GPU**：vLLM 生成约 1 GPU·天，judge 0.5，6 个模型内部分数 0.5；IRT 在 CPU 上拟合（py-irt 或 R mirt）。
- **两周试点**：8 模型 × 1k 题，双 judge κ ≥ 0.7 为达标；**κ < 0.6 放弃**。1PL 是否拿下都继续。
- **叙事与目标**：*二十个对齐模型的过拒与漏拒，主要由一个旋钮决定，偶尔不是。* 投 NLPCC 2027 或 EMNLP Findings。

## N1 不可逆点 → 降为 N2 第二章

### 压力测试

- **混淆**："第 t 个 token"在不同样本里内容不同（模板类先有人设铺垫，GCG 以"Sure, here is"开头），改用**语义里程碑**：生成前 m0、肯定前缀后 m1、第一句内容后 m2、第一条有害步骤后 m3。steering 过强输出乱码，judge 判为不有害，制造虚假恢复。编码类 judge 不可用。
- **负结果风险很高**：【事实｜第一部分 §11.1】加拒答方向连无害请求都能逼出拒答，所以"任何位置大 α 都能救回"几乎可预期，曲线可能很平。主指标改为**自然恢复概率 P\_recover(m)**：从 m 起重采样 K 次，看模型自行转向拒答的比例，不受 steering 强度混淆。steering 降为次要，只报告流畅度约束（续写困惑度 ≤ 基线 k 倍）下的最小有效强度 α\*(m)。
- **逻辑问题**："存在承诺点 → 静态检测有理论上限"不成立，二者是两回事。正确的价值是承诺点给出**防御必须行动的截止时刻**：截止在 m0 则流式防御无意义，在 m2 之后中途干预才有窗口。
- **撞车**：Qi et al.《Safety Alignment Should Be Made More Than Just a Few Tokens Deep》（ICLR 2025）已有预填充前缀长度与 ASR 曲线；Backtracking（Zhang et al., ICLR 2025）；《On the Biology of a LLM》的"语法连贯压力"。均【需检索验证】。剩余空间：自然轨迹、分家族比较、与 N2 分类的对应。

### 修正版与计划

- **判决性实验**：第一条有害步骤前 P\_recover 是否已降到 5% 以下？是，则存在硬截止，流式防御窗口很窄；否，则中途纠正始终可行，流式防御的瓶颈在检测而不在干预。
- **加分项**：检验 N2 分类能否预测曲线形状，例如信源损坏型从 m0 起 P\_recover 就很低。
- **计划**：复用 N2 样本与 hook 代码，每里程碑 K = 16，约 2 GPU·天，工程约 2 周。时间不够则只在 Llama-3-8B 上做，作为 N2 的一节。

## N3 → 杀（独立成文）

**杀的理由**

1. 同位置、同源数据提取的 DIM 方向高相关属预期，审稿人会说"显而易见"（第三部分 §5.2 已指出）。
2. ReFAT 的拒答特征就是动态计算的 DIM 拒答方向（第一部分 §11.4），与 Arditi 方向是一回事，放进来是退化比较；RASS 的 steering 向量依赖多模型共识锚点，复现成本高。
3. "投影到同一子空间 → 防御是同一干预的马甲"是过度推论：ReFAT 改变训练分布，JBShield 用向量做检测锚点，用法不同机制就不同。
4. Ball et al. 2024《Understanding Jailbreak Success: A Study of Latent Space Dynamics》据我所知已比较过不同越狱家族向量的余弦【需检索验证】。

**保留部分（N3-lite，0.5 GPU·天）**：在 N2 的 4 个模型上统一提取 Arditi 的 r、Zhao 的 h、JBShield 的 v\_t 与 v\_j、SVA 的 false-refusal 向量，报告两两余弦与 RepInd。N2 必须先确认"t\_post 上的毒性概念 ≈ 拒答方向"是否成立，修正后的推导才站得住。

## 最终组合与时间线

推荐一篇冲 B（N5 → N2 + N3-lite + N1-lite），一篇保底 C（N4），不走"两个 C"路线。总计约 10–12 GPU·天。

- **风险不相关**：N4 不依赖机制实验成败；N2 的负结果风险集中在三分类能否成立。
- **N5 是 N2 必经前置且自带退路**：两周出结果，无论偏向哪边都能单独写成 C。
- **算力人力放得下**：N4 的 IRT 拟合在 CPU 上，可与 N2 的 GPU 任务穿插。
- **单独的 C 对负结果容忍度低**（第三部分 §13 第 5 条），而 N2 + N5 无论判决性实验朝哪边走都能给出正面陈述。

| 时间 | 任务 |
| --- | --- |
| 2026 年 11 月上 | N5 试点；N4 数据整理，查 SORRY 是否公开模型回答 |
| 11 月下–12 月 | N2 试点 → 通过则全量；N4 生成与 judge 穿插 |
| 2027 年 1 月 | N2 修复矩阵 + 检测盲区；N1-lite |
| 2 月 | N4 投稿（NLPCC 2027 或 ARR 2 月周期）【需检索验证日期】 |
| 3–5 月 | N2 写作，投 ARR 5 月周期 → EMNLP 2027 |

**决策点**：N2 试点若在 12 月中旬触发放弃标准，改为 N5 与 N4 各出一篇 C，N1-lite 并入 N5 作为一节。

## 需检索验证清单

以下论文均凭记忆提及，需确认存在性与结论。

**具体论文**

- [ ] Qi et al.《Safety Alignment Should Be Made More Than Just a Few Tokens Deep》（ICLR 2025）：预填充曲线形状
- [ ] Zhang et al.《Backtracking Improves Generation Safety》（ICLR 2025?）
- [ ] Lindsey et al.《On the Biology of a Large Language Model》（Transformer Circuits，2025）：越狱案例一节
- [ ] Zhou et al.《How Alignment and Jailbreak Work: Explain LLM Safety through Intermediate Hidden States》（EMNLP Findings 2024）：与 N2 撞车程度
- [ ] Zhou et al.《On the Role of Attention Heads in Large Language Model Safety》（ICLR 2025）；《Safety Layers in Aligned LLMs》（ICLR 2025?）
- [ ] Ball, Kreuter, Panickssery《Understanding Jailbreak Success: A Study of Latent Space Dynamics in LLMs》（arXiv 2406.09289）
- [ ] Marshall et al.《Refusal in LLMs is an Affine Function》（arXiv 2411.09003）
- [ ] Souly et al. StrongREJECT（2024）：judge 偏差
- [ ] Zeng et al.《How Johnny Can Persuade LLMs to Jailbreak Them》（ACL 2024）：PAP 数据集是否公开
- [ ] Shen et al.《"Do Anything Now"》（CCS 2024）：模板数据集
- [ ] Polo et al. tinyBenchmarks（2024）及其他 IRT 用于 LLM 评测的工作
- [ ] O'Brien et al. 用 SAE 引导拒答；Kissane 等用 SAE 解释拒答
- [ ] 第一部分 §9.5 与第三部分 §1.1 的全部 2026 年编号：2602.11495、2603.24543、2602.02132、2603.13359、2609.07037，以及 ACL Findings 2026 人格特质干扰论文

**数据与事实核对**

- [ ] JBShield 构造提示时是否套用 chat template
- [ ] Past Tense 两个 61% 分别对应什么指标
- [ ] SORRY-Bench 是否公开 56 个模型的回答或判定
- [ ] HarmBench、JBB 的 GCG 产物覆盖哪些模型（是否含 Llama-3、Qwen2）
- [ ] CCF 目录对 Findings 的认定口径；ARR 2027 各周期与 NLPCC 2027 截止日期

**2026 年新文献检索关键词**

`jailbreak point of no return` · `commitment point refusal generation` · `harmfulness refusal pathway attention heads patching` · `persuasion jailbreak harmfulness representation style confound` · `refusal direction distribution shift probe validity` · `item response theory over-refusal safety benchmark` · `over-refusal under-refusal unidimensional` · `jailbreak detector blind spot harmfulness judgment`

