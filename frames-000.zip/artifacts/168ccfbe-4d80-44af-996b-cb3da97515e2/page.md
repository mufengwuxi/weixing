# Private but Not Unsafe · 论文草稿

<!-- tab: Tab 1 -->

# Private but Not Unsafe: Preserving Safety Alignment in Privacy-Preserving Fine-Tuning

2026-11-05 · @someone

Section 3, Problem Statement and Threat Model, second draft (restructured after Cheetah, USENIX Security 2022, and BumbleBee, NDSS 2025).

## 3.1 System Model

We consider fine-tuning as a service between a client C, who owns a private dataset D, and a service provider P, who fine-tunes a public aligned base model M with L layers on D (Figure 1). We split M at layer S: the bottom layers M\_{1..S} stay frozen, and a LoRA adapter θ is attached to the top layers M^θ\_{S+1..L}. For each sample (x\_i, y\_i), where x\_i has m\_i tokens and y\_i marks its target tokens, C computes the split-layer states h\_i = M\_{1..S}(x\_i) locally. C and P then train θ jointly in a two-party computation (2PC) protocol Π, which operates only on secret shares of h\_i and y\_i and which Section 4 constructs. P receives the trained adapter θ\_T and hosts the fine-tuned model, M with θ\_T attached, which C queries through P's API as in current fine-tuning services.

As in existing defenses for fine-tuning services \[Lisa, BackdoorAlign\], P is responsible for the safety of the model it hosts: it fixes the training recipe and adds safety resources of its own, which Π never reveals to C. The first is a moderation probe (w, τ): a linear classifier that reads the state at a sample's last position and flags sample i as harmful when ⟨w, h\_i\[m\_i\]⟩ > τ. The second is a small set R of k safety examples, harmful prompts paired with refusals written by the base model. The third is a secret system prompt σ. Following BackdoorAlign, P attaches σ to the safety examples during training and to every query at serving time, so the learned refusals are tied to a prompt that C cannot reproduce. Section 4 explains how P builds and uses these resources.

## 3.2 Threat Model

We consider two adversaries, one for each property. As in most privacy-preserving machine learning, privacy is analyzed against semi-honest parties. Safety is analyzed against the client's training data, whether that data erodes alignment by accident or is poisoned on purpose.

**Privacy adversary.** As in most privacy-preserving machine learning \[SecureML, CrypTen, Cheetah, BOLT, BumbleBee, SecP-Tuning\], both parties are semi-honest: they follow Π but try to learn the other party's secrets from what they observe. P tries to learn the client's data D. C tries to learn P's resources (w, τ), R, and σ, as well as the adapter θ\_T. A third secret is the moderation outcome, that is, which samples the probe flagged, and it must stay hidden from both parties. For P, a flag reveals that a particular client sample is harmful, which is information about D. For C, the flags show which of its samples were caught, so it could rewrite those samples until none is.

**Safety adversary.** As in the harmful fine-tuning literature \[Qi et al., Lisa, BackdoorAlign\], the safety adversary is the client, which poisons training to obtain a fine-tuned model that answers harmful requests while still performing its declared task. It controls the content of D: how many harmful samples to include, from which source and on which topics, and how large D is. It knows Π but neither R nor σ. Following the practice of evaluating defenses against adaptive attackers \[Tramèr et al., Virus\], we also give it the probe (w, τ), even though Π never reveals it. We distinguish two tiers of the adversary by what it can manipulate.

A **data-poisoning client (Tier I)** controls only its data and submits honest states h\_i = M\_{1..S}(x\_i). It can evade the probe only by choosing harmful texts that the probe happens to score as benign, so its evasion is limited to such texts.

An **activation-poisoning client (Tier II)** can additionally replace the probe's input h\_i\[m\_i\] with an arbitrary state, which Π cannot detect because h\_i is computed on C's machine. Since this position carries no target and, under causal attention, influences no other position, the replacement passes any harmful sample through the probe without changing its gradient. Tier II therefore removes the probe entirely.

## 3.3 Security Goals

As in most privacy-preserving machine learning schemes \[Cheetah, BOLT, BumbleBee\], we state privacy as the secure realization of an ideal functionality and prove it in Section 5. Defenses against harmful fine-tuning carry no provable guarantee and are all evaluated empirically \[Survey\], so we state safety as an attack experiment, scored by the field's standard harmful score and estimated in Section 7.

**Ideal functionality F\_SFT.** C inputs D\_h = {(h\_i, y\_i)}\_{i≤n}, and P inputs (θ\_0, w, τ, R, σ). For each client sample, F\_SFT computes the keep bit b\_i = 1\[⟨w, h\_i\[m\_i\]⟩ ≤ τ\]; each safety example (x^r\_j, y^r\_j) ∈ R enters with state h^r\_j = M\_{1..S}(σ ‖ x^r\_j) and is never gated. F\_SFT then runs T steps of Adam from θ\_0. Step t minimizes the objective f\_t below over the client samples ℬ\_t and safety examples R\_t of its batch, where CE is the token-level cross-entropy and N\_t is the public number of target tokens in the step. A sample whose gradient exceeds a public bound γ in any coordinate is also dropped from that step, which guards against fixed-point overflow. Finally F\_SFT outputs θ\_T to P and nothing to C; both learn μ, the public shape of the computation: the length and target positions of every sequence and the number of training steps.

```latex
f_t(\theta) = \frac{1}{N_t}\Big(\sum_{i \in \mathcal{B}_t} b_i\,\mathrm{CE}\big(M^{\theta}_{S+1..L}(h_i),\,y_i\big) + \sum_{j \in R_t} \mathrm{CE}\big(M^{\theta}_{S+1..L}(h^r_j),\,y^r_j\big)\Big)
```

**Definition 1 (Privacy).** Π securely computes F\_SFT against static semi-honest adversaries if there exist PPT simulators Sim\_C and Sim\_P such that

```latex
\mathrm{Sim}_C(D_h,\ \mu) \;\approx_c\; \mathrm{view}^{\Pi}_C, \qquad \mathrm{Sim}_P(\theta_0, w, \tau, R, \sigma,\ \theta_T,\ \mu) \;\approx_c\; \mathrm{view}^{\Pi}_P .
```

Neither simulator receives the bits b\_i, so Definition 1 covers both requirements of Section 3.2: the moderation outcome stays hidden from both parties, and C learns nothing about the probe, R, σ, or θ\_T. Definition 1 holds for every input D\_h, and an activation-poisoning client changes only its input while sending every message of Π as prescribed, so the guarantee covers Tier II as well as Tier I.

**Definition 2 (ε-safety).** Let Q be a set of harmful prompts and J a moderation model that labels a response harmful or not. As in Lisa, Booster, and the survey, the harmful score HS(θ) is the fraction of q ∈ Q whose response M\_θ(σ ‖ q) J labels harmful. In the experiment Exp^X\_{Π,𝒜}, with X ∈ {I, II}, the adversary 𝒜 is given Π and (w, τ) and outputs a dataset: texts {(x\_i, y\_i)} with h\_i = M\_{1..S}(x\_i) for Tier I, or arbitrary states {(h\_i, y\_i)} for Tier II. Π then runs with P's honest inputs and yields θ\_T. Π is ε-safe against Tier X if, for every efficient 𝒜,

```latex
\mathrm{HS}(\theta_T) \;\le\; \mathrm{HS}(M) + \varepsilon ,
```

where HS(M) is the harmful score of the aligned base model. Because 𝒜 ranges over all strategies, ε cannot be computed exactly; Section 7 estimates it as the largest gap over concrete attacks of both tiers.

