# Cache一致性调研报告

<!-- tab: Tab 1 -->

# 大规模与异构系统中的Cache一致性

2026-11-08 · @someone

## 摘要

Cache一致性协议负责让多个私有缓存中的同一份数据保持一致，是共享存储多处理器能够正确运行的前提。近几年处理器核数持续增加，GPU、网卡等设备也开始通过 CXL 之类的互连直接访问主机内存，传统的 MESI 加目录方案在这些场景下暴露出不少问题。本文以 ISCA、HPCA、ASPLOS 等体系结构会议近年的论文为线索，重点讨论千核处理器上的可扩展目录协议、GPU 上基于时间的轻量协议，以及 CXL 异构系统中的协议桥接与形式化验证，并结合论文内容谈谈笔者对这些方案局限性的看法。

**关键词**：Cache一致性；目录协议；GPU；CXL；异构计算

## 1 引言

处理器的每个核都有自己的私有缓存。两个核同时缓存了同一个内存块，其中一个核把它改写之后，另一个核手里的副本就过时了，如果继续读这个旧副本，程序就会出错，一致性协议要解决的就是这个问题。按照 Sorin 等人所编教材中的定义，一致性协议需要维持两条不变量：同一时刻对某个地址要么只有一个核在写，要么只有若干个核在读，通常简称 SWMR（Single-Writer-Multiple-Reader）；另外，每次读都应当读到最近一次写入的值。

单芯片多核刚普及时，这个问题已经被研究得比较充分，近几年它又重新受到关注，主要原因是系统形态变了。数据中心处理器的核数已经到了一两百，例如 AMD Bergamo 有 128 核，Intel Sierra Forest 有 288 核，已有研究开始讨论在上千个核之间维持硬件一致性。同时，越来越多的加速器希望和 CPU 直接共享内存。规模和异构带来的变化使目录开销、协议互操作和正确性验证都更难处理，下文围绕这几点展开。

## 2 一致性基础与经典方案

主流 CPU 普遍使用基于失效（invalidation）的写回协议，MESI 是其中最常见的一种。缓存行处于修改（M）、独占（E）、共享（S）、无效（I）四种稳定状态之一：M 表示本核独占且已改写，对应 SWMR 里的唯一写者；S 表示可能有多个只读副本；E 是对 MSI 的优化，独占读入的行之后再写就不必发请求。一个核要写处于 S 或 I 状态的行，必须先让其他副本全部失效，一致性开销主要就来自这一步。

监听（snooping）协议把每个请求广播出去，所有缓存各自检查是否持有该行，实现简单，但广播流量随核数增长，核数一多就难以承受。目录（directory）协议改为给每个内存块记录有哪些核缓存了它，请求先发给该块所在的主目录（home），再由目录有针对性地发出失效消息。图1是目录协议处理一次写缺失的过程。

[Embedded widget: 图1 目录协议中的一次写缺失（作者自绘，编号表示消息先后，虚线为失效应答）](node/aee93da6-02cf)

这个流程里的开销主要有两处。请求要先绕到主目录，写缺失的关键路径上至少有三次消息传递，主目录离请求者越远，延迟越大。另外，最简单的全映射位向量要为每个目录项准备和核数一样多的位，核数上千时目录本身的面积就很可观。下一节介绍的千核方案，主要就是在处理这两处开销。

## 3 千核处理器上的目录协议

核数上千之后，一个自然的想法是把核分成若干簇，希望大部分共享发生在簇内。麻烦在于每个内存行的主目录是按地址固定分配的，即使共享这行数据的两个核在同一个簇里，只要它的主目录在别的簇，请求照样要跨簇。此外总有一小部分数据会被大量核同时读取，为它们记录共享者需要很大的目录项。

伊利诺伊大学 Torrellas 团队与 Intel 合作的 Dorado（ISCA 2026）针对的就是这两个问题。它让每一行除了全局主目录之外，还可以在访问它的簇里分配一个临时主目录，簇内请求先查临时主目录，能在本地完成就不再访问远端，全局主目录仍然作为事务的串行化点（图2）。存储方面，Dorado 把不同类型的目录项放进同一个硬件结构按需竞争空间，作者称为 Dynamic Apportioning；被很多核共享的行则可以借用所在目录组（set）里的一块公共指针区，这一机制叫 SetOverflow。

[Embedded widget: 图2 Dorado 的簇式目录组织示意（作者根据 Dorado 论文描述重绘）](node/8847ced5-1fec)

论文在 1024 核（32 个簇，每簇 32 核）的模拟环境中评估，Dorado 相比同等面积的有限指针目录平均加速 1.36 倍，平均读延迟下降 46.1%；与全映射位向量相比性能差距在 1% 以内，而后者需要 2.75 倍的目录存储。笔者认为这项工作比较有说服力的地方在于负载分析：每簇 32 核时，主目录在远端、数据却就在本簇的读缺失平均超过九成，临时主目录的设计有实际依据。它的局限也比较明显，评估全部基于模拟，作者用 TLA+ 做的模型检验只覆盖了 4 个簇、每簇 4 核的小规模配置，而目前还很难说清哪类产品真正需要上千核的单一一致性域。

## 4 GPU 上基于时间的一致性

在 GPU 上直接套用 CPU 的目录协议代价很高。Singh 等人（HPCA 2013）指出，大多数 GPU 程序本身用不到一致性，加上目录协议只会白白增加流量，而成千上万个线程同时在途的一致性请求也需要大量缓冲。因此商用 GPU 一般让 L1 采用写穿策略，只在同步操作处整体刷新或失效 L1，由软件保证正确性，代价是一些本可以复用的数据也被一并丢掉。

这一方向上有代表性的思路是给缓存行加上时间期限。Singh 等人提出的时间一致性（Temporal Coherence）利用片上全局同步的计数器，为每个读入 L1 的行分配一个租期，租期一到副本自动失效，写操作因此不必再给共享者发失效消息（图3）。其中 TC-Weak 版本用时间戳实现内存栅栏来支持释放一致性，据作者报告，对需要一致性的程序比直接关闭 L1 快 85%。这类方案依赖全局同步时钟，线程还可能要等租期结束才能继续。Tabbakh 等人的 G-TSC（HPCA 2018）借鉴 CPU 上的 Tardis 协议改用逻辑时间戳，去掉了对全局时钟的依赖，在 GPGPU-Sim 上比基于物理时间的方案快 38%。

[Embedded widget: 图3 基于租期的 GPU 一致性示意（作者根据 Temporal Coherence 思路自绘，非等比例）](node/363c35af-9fd4)

到了多 GPU 系统，GPU 之间的链路带宽有限，问题更突出。NVIDIA 的 HMG（HPCA 2020）利用 GPU 编程模型中带作用域（scope）的内存模型，只保留 V、I 两种状态，按层次记录共享者，省掉了失效应答和瞬态。在 4-GPU 系统上，它比软件控制的批量失效方案快 26%，达到理想缓存系统性能的 97%。Puthoor 和 Lipasti 发表在 ACM TACO 2023 的时空一致性（STC）把写权限按地址带和轮次（epoch）分配，处理单元只看当前轮次就能判断能否写入，几乎没有一致性流量，不过在跨内核复用读数据的负载上，它相比软件方案的加速只有 7.13%。笔者注意到，这些方案都要求程序员在同步点上正确使用弱内存模型，漏写栅栏或标错作用域造成的错误往往很难定位，而论文对这部分成本讨论得较少。

## 5 CXL 与异构系统中的一致性

在异构芯片上，CPU、GPU 和加速器往往各有一套为自己定制的一致性协议和内存模型，把它们拼在一起时，首先要回答组合后的协议如何设计、程序员最终看到的是什么内存模型。爱丁堡大学和杜克大学的 Oswald 等人先在 ISCA 2018 提出 ProtoGen，可以从只描述稳定状态的原子规格自动生成包含全部瞬态的目录协议。随后的 HeteroGen（HPCA 2022）沿用这一思路，把各簇的协议自动组合起来，并说明组合结果满足他们定义的复合一致性模型，与公开的手工设计异构协议相比，性能基本持平。

CXL 把这个问题带到了板级。它在 PCIe 物理层上定义了 CXL.io、CXL.cache 和 CXL.mem 三个子协议，其中 CXL.cache 让加速器可以像 CPU 核一样一致地缓存主机内存。帝国理工学院的 Tan 等人（ASPLOS 2025）用 Isabelle 定理证明器为 CXL.cache 建立了形式化模型，建模过程中找出了标准文本里 5 处可以改进的地方，其中 4 处已确认会写入后续版本，另一处仍在讨论。他们还机械化地证明了模型满足 SWMR 性质，证明涉及五万多个引理，作者为此专门开发了自动化工具。不过这个证明只考虑两个设备、一个地址，数据值不变量也留作后续工作，离完整证明 CXL.cache 的正确性还有不小距离。代尔夫特理工大学等单位的 C3（HPCA 2026）更关注工程实现，给出了一套设计 CXL 一致性控制器的方法，核心做法是跨一致性域委托内存操作，并在域边界上保证原子性，从而让各单元保留原生的内存一致性模型（图4）。

[Embedded widget: 图4 CXL 异构一致性域的桥接与验证（作者根据 C3 与《Formalising CXL Cache Coherence》描述自绘）](node/0d09e557-58d2)

硬件一致性的成本也让一些工作选择绕开它。面向 CXL 共享内存的 MPI 实现 cMPI 认为，在很大的 CXL 内存池上逐行跟踪状态难以扩展，于是只在通信双方之间按需维护软件一致性。另有一些工作反过来主动利用一致性协议，例如 Schuh 等人的 CC-NIC（ASPLOS 2024）把主机与网卡之间的接口重新设计成适合一致性互连的形式，用来替代基于 PCIe 的传统接口。

## 6 方案对比

表1 汇总了前文提到的几项代表性工作。

| 方案（会议/年份） | 目标场景 | 核心思路 | 论文报告的效果 | 主要代价 |
| --- | --- | --- | --- | --- |
| Dorado（ISCA 2026） | 千核 CPU | 簇内临时主目录，目录存储动态分配 | 比同面积有限指针目录平均快 1.36 倍，性能距全映射不到 1% | 新增状态和指针类型，验证更难 |
| Temporal Coherence（HPCA 2013） | 单芯片 GPU | 全局同步计数器 + 租期自失效 | 比关闭 L1 快 85% | 依赖全局同步时钟 |
| G-TSC（HPCA 2018） | 单芯片 GPU | 逻辑时间戳 | 比基于物理时间的方案快 38% | 时间戳存储与管理开销 |
| HMG（HPCA 2020） | 多 GPU | 作用域内存模型 + 类 VI 协议 + 层次化共享者跟踪 | 达到理想缓存性能的 97% | 依赖作用域编程模型 |
| STC（TACO 2023） | GPU | 按地址带和轮次分配写权限 | 几乎无一致性流量，部分负载快 7.13% | 写入需等待所属轮次 |
| HeteroGen（HPCA 2022） | 异构多簇 | 自动组合各簇协议 | 性能与手工设计的异构协议相当 | 程序员需理解复合一致性模型 |
| 形式化 CXL（ASPLOS 2025） | CXL 设备互连 | Isabelle 建模并证明 SWMR | 找出标准中 5 处问题，4 处将被采纳 | 仅覆盖两个设备、一个地址 |
| C3（HPCA 2026） | CXL 异构系统 | 跨域委托操作 + 边界原子性 | 保留各方原生内存模型语义 | 需要额外的桥接控制器 |

放在一起看，GPU 方案能把协议做得很简单，靠的是放松内存模型，把一部分正确性交给程序员；千核 CPU 要在 TSO 这类较强的模型下保持完整的硬件一致性，只能在目录组织上想办法，协议反而变得更复杂，Dorado 就为此新增了 MS 状态和三种共享者指针。协议越复杂，越需要形式化工具兜底，Dorado 用了 TLA+ 模型检验，CXL 那项工作则完全建立在定理证明之上。

需要说明的是，表中各方案的实验平台、基线和负载都不相同，表里的加速比只能说明各自相对基线的改进，彼此之间不能直接比较。

## 7 总结

一致性协议要维护的两条不变量几十年来没有变化，变化的是维护它们的代价落在了哪里。从本文梳理的几项工作看，千核处理器和多 GPU 系统的主要矛盾是目录开销和跨芯片通信，研究者普遍借助数据访问的局部性来缓解；CXL 把一致性扩展到不同厂商的设备之间以后，标准本身是否正确、各方内存模型能否兼容成了新的难点。

笔者认为接下来比较值得关注的是芯粒（chiplet）。芯粒之间链路的延迟和带宽与片上网络差别很大，Dorado 的评估中跨簇往返就按跨芯粒的 60 个周期设定，现有协议的分层方式可能需要按芯粒边界重新考虑。另一个现实问题是验证能否跟上协议的复杂度，CXL 那项工作只覆盖两个设备、一个地址，就已经投入了大约 12 人月。

## 参考文献

1. D. J. Sorin, M. D. Hill, D. A. Wood. A Primer on Memory Consistency and Cache Coherence. Morgan & Claypool, 2011.
2. J. Stojkovic, A. Farrell, G. Gerogiannis, Z. Gong, C. J. Hughes, J. Torrellas. [Dorado: Clustered Hardware Cache Coherence for 1,000+ Cores](https://jovans2.github.io/files/dorado_isca_camera_ready.pdf). ISCA 2026.
3. I. Singh, A. Shriraman, W. W. L. Fung, M. O'Connor, T. M. Aamodt. [Cache Coherence for GPU Architectures](https://people.ece.ubc.ca/aamodt/papers/isingh.hpca2013.pdf). HPCA 2013.
4. A. Tabbakh, X. Qian, M. Annavaram. [G-TSC: Timestamp Based Coherence for GPUs](https://pure.kfupm.edu.sa/en/publications/g-tsc-timestamp-based-coherence-for-gpus/). HPCA 2018.
5. X. Ren, D. Lustig, E. Bolotin, A. Jaleel, O. Villa, D. Nellans. [HMG: Extending Cache Coherence Protocols Across Modern Hierarchical Multi-GPU Systems](https://research.nvidia.com/publication/2020-02_hmg-extending-cache-coherence-protocols-across-modern-hierarchical-multi-gpu). HPCA 2020.
6. S. Puthoor, M. H. Lipasti. [Turn-based Spatiotemporal Coherence for GPUs](https://par.nsf.gov/biblio/10433360). ACM TACO, 20(3), 2023.
7. N. Oswald, V. Nagarajan, D. J. Sorin. ProtoGen: Automatically Generating Directory Cache Coherence Protocols from Atomic Specifications. ISCA 2018, pp. 247–260.
8. N. Oswald, V. Nagarajan, D. J. Sorin, V. Gavrielatos, T. Olausson, R. Carr. [HeteroGen: Automatic Synthesis of Heterogeneous Cache Coherence Protocols](https://scholars.duke.edu/publication/1524248). HPCA 2022, pp. 756–771.
9. C. Tan, A. F. Donaldson, J. Wickerson. [Formalising CXL Cache Coherence](https://www.doc.ic.ac.uk/~afd/papers/2025/ASPLOS-CXL.pdf). ASPLOS 2025.
10. A. Lefort, D. Schall, N. Carpentieri, J. Pritzi, S. Chakraborty 等. [C3: CXL Coherence Controllers for Heterogeneous Architectures](https://research.tudelft.nl/en/publications/c3-cxl-coherence-controllers-for-heterogeneous-architectures/). HPCA 2026.
11. [cMPI: MPI over CXL shared memory](https://arxiv.org/html/2510.05476v1). arXiv:2510.05476, 2025.
12. H. N. Schuh, A. Krishnamurthy, D. Culler, H. M. Levy, L. Rizzo, S. Khan, B. E. Stephens. [CC-NIC: a Cache-Coherent Interface to the NIC](https://par.nsf.gov/servlets/purl/10562006). ASPLOS 2024.

> 说明：图1–图4 均为作者依据上述论文的文字描述自行绘制的示意图，并非原文插图。

