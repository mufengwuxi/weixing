# Class Game Time: Host Guide

<!-- tab: Class Game Time: Host Guide -->

# Class Game Time: Host Guide

2026-10-30 · @someone

## Overview

Two games for 24 people (6 groups of 4) in 20 minutes. Lines marked **SAY** are your host script. Read them slowly and clearly.

| Time | Part | What happens |
| --- | --- | --- |
| 0:00–1:00 | Opening | Welcome, groups sit together |
| 1:00–13:00 | Game 1: Who Is the Spy | 3 rounds, 2 groups on stage each round, others watch |
| 13:00–14:00 | Change | Hand out sticky notes |
| 14:00–19:00 | Game 2: Who Am I? | Everyone walks and asks questions |
| 19:00–20:00 | Closing | Winners and thank you |

## Opening (1 minute)

**SAY:** Hello everyone! Today we will play two games. Game one is "Who Is the Spy." Game two is "Who Am I." Please speak only English. Have fun!

**SAY:** First, we have six groups. Four people in each group. Please sit with your group.

**DO:** Write the group numbers 1 to 6 on the board.

## Game 1: Who Is the Spy (12 minutes)

Play 3 rounds. In each round, 2 groups (8 players) come up to the front and play; the other groups are the audience. Among the 8 players, 7 get the same word and 1, the spy, gets a similar word. Nobody knows who the spy is — not the audience, not even the spy. The audience guesses too.

| Round | Players on stage |
| --- | --- |
| Round 1 | Group 1 + Group 2 |
| Round 2 | Group 3 + Group 4 |
| Round 3 | Group 5 + Group 6 |

**Rules**

1. The 8 players stand in a line at the front, facing the class. They are number 1 to 8, from left to right.
2. Each player takes one paper and reads it alone. Do not show it.
3. From left to right, each player says one English sentence about the word. Do not say the word. No Chinese.
4. Vote: on "three, two, one," each player points at one person. The person with the most votes is out. They give the paper to the host face down and do not say the word. The host only says "spy" or "not the spy."
5. Only two votes per round. Spy is out: the players win. Spy is still in after the second vote: the spy wins.
6. Audience: listen and guess. Before each player vote, the audience shouts the number of the spy.

**Points:** Players win → each player gets 1 point. Spy wins → the spy gets 3 points.

**Script**

**SAY:** Game one is "Who Is the Spy." We play three rounds. In each round, two groups come up and play. The other groups are the audience.

**SAY:** Round one! Group 1 and Group 2, please come up. Stand in a line and face the class.

**DO:** Hold out the envelope. Each player takes one paper.

**SAY (to the audience):** Audience, you play too! Listen carefully and find the spy.

**SAY (to the players):** Take one paper. Read it. Don't show it. Seven of you have the same word. One of you is the spy. Maybe *you* are the spy!

**SAY:** From left to right, say one sentence about your word. Don't say the word. Don't speak Chinese.

**SAY (after everyone speaks):** Audience first! Who is the spy? Shout the number! Three, two, one! … Now, players, time to vote! Three, two, one — point!

**SAY:** You have the most votes. You are out. Please give me your paper. Don't say your word!

- Spy → **SAY:** Yes! This is the spy! Great job, players!
- Not the spy, first vote → **SAY:** This is not the spy! The spy is still here. One more sentence each. Then we vote again.
- Not the spy, second vote → **SAY:** Not the spy again! The spy wins!

**SAY:** Spy, please step forward and show your paper. The words were \_\_\_ and \_\_\_. Let's give them a big hand! Please go back to your seats.

**SAY:** Round two! Group 3 and Group 4, please come up.

**SAY:** Last round! Group 5 and Group 6, please come up.

**Timing tips**

- Each round takes about 4 minutes. Have the papers ready before the groups walk up.
- Stop at 13:00 even if a round is not finished; the spy shows the paper.
- If someone is stuck, help them: "You can say: It is… / People use it to… / You can find it in…"

## Game 2: Who Am I? (5 minutes)

Everyone has a famous name on their back and must guess it by asking yes/no questions. The first 3 people to guess win.

**Rules**

1. A partner sticks a name on your back. Don't look at it!
2. Walk around. Ask other people yes/no questions in English.
3. Ask one person only one question. Then find a new person.
4. Guess anytime: "Am I \_\_\_?"
5. Guessed right? Move the note to your chest and keep answering others.

**Script**

**SAY:** Game two! Everyone, stand up, please. Find a partner. Put a sticky note on your partner's back. Don't look at your own note!

**SAY:** On your back is a famous person or character. You want to know: who am I?

**SAY:** Walk around and ask questions. Only yes or no questions. One question, then change people.

**SAY:** If you know the answer, ask: "Am I…?" If you are right, put the note on your chest. Then help other people.

**SAY:** You have five minutes. Ready? Go!

**SAY (at 17:00):** Two minutes left! Hint time! You can ask someone: "Give me a hint, please."

**SAY (at 19:00):** Stop! Time is up!

**Question starters** (write these on the board or a slide)

- Am I a real person? / Am I a cartoon?
- Am I a man? / Am I a woman?
- Am I alive?
- Am I Chinese? / Am I American? / Am I British?
- Am I a singer? / an actor? / an athlete? / a writer?
- Am I old? / Am I young?
- Am I in a movie?

**Tips**

- Write down who guesses first, second and third.
- If a pair is chatting too long, say: "Change people, please!"

## Closing (1 minute)

**SAY:** Now, the winners! In "Who Is the Spy," the top player is \_\_\_. In "Who Am I," first place is \_\_\_, second is \_\_\_, and third is \_\_\_. Let's give them a big hand!

**SAY:** Thank you, everyone. You did a great job. That's all for today!

**DO:** Give out prizes (optional).

## Printables and materials

**Who Is the Spy words.** Rounds go from easy to fun; spares are for a word that turns out too easy or extra time. Keep this page to yourself until the end of each round.

| Round | Player word (×7) | Spy word (×1) | Why it works | Safe hint if a player is stuck |
| --- | --- | --- | --- | --- |
| Round 1 (warm-up) | Coffee | Milk tea | Two everyday drinks; easy to talk about | "Many students drink it in the afternoon." |
| Round 2 | Hot pot | Barbecue | Both are spicy dinners with friends | "You eat it with a group of friends." |
| Round 3 (finale) | Supervisor | Boss | Very close meaning, and funny for PhD students | "This person tells you what to do." |
| Spare | Elevator | Escalator | Both take you up and down | "You use it in a shopping mall." |
| Spare | Dumplings | Wontons | Both are wrapped food | "You can eat it with vinegar." |
| Spare | Subway | Bus | Both are city transport | "You need a card to take it." |
| Spare | Sunrise | Sunset | Same sky, different time | "It is very beautiful at the beach." |
| Spare | Library | Bookstore | Both are full of books | "It is very quiet there." |

**Cut-out slips.** Print this part, cut along the lines, and fold each slip twice. Put each round's 8 slips in its own envelope and mix them. For a spare pair, write 7 + 1 slips by hand.

Round 1

|  |  |  |  |
| --- | --- | --- | --- |
| Coffee | Coffee | Coffee | Coffee |
| Coffee | Coffee | Milk tea | Coffee |

Round 2

|  |  |  |  |
| --- | --- | --- | --- |
| Hot pot | Barbecue | Hot pot | Hot pot |
| Hot pot | Hot pot | Hot pot | Hot pot |

Round 3

|  |  |  |  |
| --- | --- | --- | --- |
| Supervisor | Supervisor | Supervisor | Supervisor |
| Boss | Supervisor | Supervisor | Supervisor |

**Who Am I? name cards.** Write one name per sticky note: 24 names plus 3 spares.

|  |  |  |  |
| --- | --- | --- | --- |
| Taylor Swift | Albert Einstein | Elon Musk | Harry Potter |
| Sun Wukong | Pikachu | Lionel Messi | Yao Ming |
| Jay Chou | Steve Jobs | Confucius | Spider-Man |
| William Shakespeare | Michael Jackson | Mr. Bean | Iron Man |
| Doraemon | Li Bai | Eileen Gu | Leonardo da Vinci |
| Jackie Chan | SpongeBob | Snow White | Cristiano Ronaldo |
| Spare: Batman | Spare: Mickey Mouse | Spare: Isaac Newton |  |

**Materials checklist**

- [ ] 24 word papers in 3 envelopes, labeled "Round 1", "Round 2" and "Round 3"
- [ ] 27 sticky notes with names, using strong-sticky notes
- [ ] Timer, such as a phone
- [ ] Slide or board with the question starters
- [ ] Paper and pen to record points and winners
- [ ] Small prizes, such as candy (optional)

